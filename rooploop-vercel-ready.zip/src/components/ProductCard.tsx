import Link from 'next/link';
import { Img } from './Img';
import { WishlistButton } from './WishlistButton';
import { getProductImages } from '@/lib/images';
import { inr } from '@/lib/format';
import type { Product } from '@/data/products';
import { isAvailable } from '@/lib/catalog';

export function ProductCard({ p }: { p: Product }) {
  const img = getProductImages(p.slug, p.name, p.images)[0];
  const avail = isAvailable(p);
  return (
    <article className="group relative">
      <Link href={`/shop/${p.slug}`} className="block" aria-label={`${p.name}, view details`}>
        <Img image={img} fit="contain" ratio="4/5" sizes="(min-width:1024px) 25vw, 50vw" className="transition-opacity group-hover:opacity-95" />
      </Link>
      <WishlistButton slug={p.slug} name={p.name} className="absolute right-2 top-2" />
      {p.draft && <span className="absolute left-2 top-2 bg-ivory/95 px-2 py-1 label text-charcoal">Draft listing</span>}
      <div className="mt-3">
        <p className="label text-charcoal/75">{p.category}</p>
        <h3 className="mt-1 font-serif text-[1.35rem] leading-tight"><Link href={`/shop/${p.slug}`} className="hover:underline">{p.name}</Link></h3>
        <p className="mt-1 text-[0.95rem]">{inr(p.price)}{p.draft && <span className="text-charcoal/70"> (draft price)</span>}</p>
        <p className="mt-1 text-[0.85rem] text-charcoal/80">
          {avail ? `Sizes: ${p.sizes.filter((s) => (p.stock[s] ?? 0) > 0).join(', ')}` : 'Sold out'}
        </p>
        <Link href={`/shop/${p.slug}`} className="mt-3 inline-block label text-maroon border-b border-maroon pb-0.5">{avail ? 'View and buy' : 'View details'}</Link>
      </div>
    </article>
  );
}
