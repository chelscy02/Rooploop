import Link from 'next/link';
import { Img } from './Img';
import { getProductImages } from '@/lib/images';
import { inr } from '@/lib/format';
import type { RentalItem } from '@/data/rentals';

export function RentalCard({ r }: { r: RentalItem }) {
  const img = getProductImages(r.slug, r.name)[0];
  return (
    <article className="group relative">
      <Link href={`/rent/${r.slug}`} aria-label={`${r.name}, view and book`} className="block">
        <Img image={img} fit="contain" ratio="4/5" sizes="(min-width:1024px) 33vw, 50vw" />
      </Link>
      {r.draft && <span className="absolute left-2 top-2 bg-ivory/95 px-2 py-1 label text-charcoal">Draft listing</span>}
      <div className="mt-3">
        <p className="label text-charcoal/75">{r.occasion}</p>
        <h3 className="mt-1 font-serif text-[1.35rem] leading-tight"><Link href={`/rent/${r.slug}`} className="hover:underline">{r.name}</Link></h3>
        <p className="mt-1 text-[0.95rem]">{inr(r.fee)} rental{r.draft && <span className="text-charcoal/70"> (draft)</span>} · {inr(r.deposit)} refundable deposit</p>
        <p className="mt-1 text-[0.85rem] text-charcoal/80">Sizes: {r.sizes.join(', ')}</p>
        <Link href={`/rent/${r.slug}`} className="mt-3 inline-block label text-maroon border-b border-maroon pb-0.5">Check dates</Link>
      </div>
    </article>
  );
}
