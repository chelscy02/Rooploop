import 'server-only';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { sampleProducts, type Product } from '@/data/products';
import { sampleRentals, type RentalItem } from '@/data/rentals';

/**
 * DEVELOPMENT DATA STORE.
 *
 * A single JSON file at .data/db.json with an in-process write queue. It exists
 * so every flow can be exercised locally without credentials. It is NOT a
 * production database: it is single-process, not horizontally scalable and
 * will not survive ephemeral hosts (e.g. Vercel). For production, apply
 * supabase/migrations/*.sql and replace this module with a Supabase-backed
 * implementation exposing the same functions. See README.
 */

export type Role = 'customer' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  passwordHash: string;
  role: Role;
  createdAt: string;
}

export interface StoredFile {
  id: string;
  ownerId: string;
  name: string;
  mime: string;
  size: number;
  /** relative to .data/uploads */
  path: string;
  createdAt: string;
}

export type ReworkStatus =
  | 'Submitted' | 'Under Review' | 'Quote Sent' | 'Approved'
  | 'In Production' | 'Ready to Ship' | 'Completed' | 'Cancelled';
export const reworkStatuses: ReworkStatus[] = [
  'Submitted', 'Under Review', 'Quote Sent', 'Approved',
  'In Production', 'Ready to Ship', 'Completed', 'Cancelled',
];

export interface ReworkQuote {
  design: string;
  price: number;
  timeline: string;
  notes: string;
  sentAt: string;
  customerResponse: 'pending' | 'accepted' | 'declined';
  respondedAt?: string;
}

export interface ReworkRequest {
  id: string;
  ref: string;
  userId: string;
  fullName: string;
  email: string;
  phone: string;
  category: string;
  condition: string;
  transformation: string;
  stylePreferences: string;
  colourPreferences: string;
  budget: string;
  instructions: string;
  fulfilment: string;
  fileIds: string[];
  status: ReworkStatus;
  quote: ReworkQuote | null;
  adminNotes: string;
  createdAt: string;
  updatedAt: string;
}

export type GiveBackStatus =
  | 'Submitted' | 'Under Assessment' | 'Accepted' | 'Collection Scheduled'
  | 'Received' | 'Routed for Reuse/Donation/Recycling' | 'Completed' | 'Not Accepted';
export const giveBackStatuses: GiveBackStatus[] = [
  'Submitted', 'Under Assessment', 'Accepted', 'Collection Scheduled',
  'Received', 'Routed for Reuse/Donation/Recycling', 'Completed', 'Not Accepted',
];
export const giveBackOutcomes = [
  'Not yet assessed',
  'Suitable for donation',
  'Suitable for redesign or reuse',
  'Suitable for resale',
  'Suitable for textile recycling',
  'Not accepted',
] as const;

export interface GiveBackSubmission {
  id: string;
  ref: string;
  userId: string;
  fullName: string;
  email: string;
  phone: string;
  category: string;
  condition: string;
  count: number;
  logistics: string;
  address: string;
  preference: string;
  notes: string;
  fileIds: string[];
  status: GiveBackStatus;
  outcome: (typeof giveBackOutcomes)[number];
  adminNotes: string;
  createdAt: string;
  updatedAt: string;
}

export type BookingStatus = 'Requested' | 'Confirmed' | 'Out for Rental' | 'Returned' | 'Completed' | 'Cancelled' | 'Expired';
export const bookingStatuses: BookingStatus[] = [
  'Requested', 'Confirmed', 'Out for Rental', 'Returned', 'Completed', 'Cancelled', 'Expired',
];
export type DepositStatus = 'Not collected (payments disabled)' | 'Held' | 'Refunded' | 'Partially retained' | 'Retained';

export interface RentalBooking {
  id: string;
  ref: string;
  userId: string;
  itemId: string;
  itemName: string;
  unitId: string;
  size: string;
  /** inclusive ISO dates YYYY-MM-DD */
  start: string;
  end: string;
  fee: number;
  deposit: number;
  status: BookingStatus;
  depositStatus: DepositStatus;
  /** Requested bookings hold the dates until this time unless confirmed. */
  holdExpiresAt: string;
  adminNotes: string;
  createdAt: string;
  updatedAt: string;
}

export type OrderStatus = 'Pending Payment' | 'Paid' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Payment Failed';
export const orderStatuses: OrderStatus[] = [
  'Pending Payment', 'Paid', 'Processing', 'Shipped', 'Delivered', 'Cancelled', 'Payment Failed',
];

export interface OrderItem {
  productId: string;
  slug: string;
  name: string;
  size: string;
  qty: number;
  unitPrice: number;
}

export interface Order {
  id: string;
  ref: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  items: OrderItem[];
  total: number;
  currency: 'INR';
  status: OrderStatus;
  /** How payment was handled. 'test' = no money moved. */
  paymentMode: 'test' | 'razorpay';
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  idempotencyKey: string;
  /** Stock has been reserved/decremented for this order. */
  stockCommitted: boolean;
  draftCatalogue: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Enquiry {
  id: string; name: string; email: string; message: string; createdAt: string; handled: boolean;
}
export interface Subscriber { id: string; email: string; createdAt: string; }
export interface OutboxMessage {
  id: string; to: string; subject: string; body: string; createdAt: string;
  delivery: 'not_sent_email_not_configured';
}

interface DbShape {
  users: User[];
  products: Product[];
  rentals: RentalItem[];
  orders: Order[];
  reworks: ReworkRequest[];
  giveBacks: GiveBackSubmission[];
  bookings: RentalBooking[];
  enquiries: Enquiry[];
  subscribers: Subscriber[];
  outbox: OutboxMessage[];
  files: StoredFile[];
}

/** Vercel's filesystem is read-only except /tmp, and /tmp is per-instance and ephemeral. */
const ON_VERCEL = !!process.env.VERCEL;
const DATA_DIR = ON_VERCEL ? path.join(os.tmpdir(), 'rooploop-data') : path.join(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

function emptyDb(): DbShape {
  return {
    users: [], products: structuredClone(sampleProducts), rentals: structuredClone(sampleRentals),
    orders: [], reworks: [], giveBacks: [], bookings: [], enquiries: [], subscribers: [], outbox: [], files: [],
  };
}

let cache: DbShape | null = null;
let queue: Promise<unknown> = Promise.resolve();

function load(): DbShape {
  if (cache) return cache;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) as Partial<DbShape>;
    cache = { ...emptyDb(), ...parsed };
  } else {
    cache = emptyDb();
    persist(cache);
  }
  return cache;
}

function persist(db: DbShape) {
  const tmp = `${DB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

/** Read-only snapshot. Do not mutate the result. */
export function readDb(): Readonly<DbShape> {
  return load();
}

/**
 * Run a mutation serially. All writes (including availability checks and
 * stock decrements) go through here so check-then-write is atomic within the
 * process. A real database must use transactions / constraints instead.
 */
export function mutate<T>(fn: (db: DbShape) => T): Promise<T> {
  const run = queue.then(() => {
    const db = load();
    const result = fn(db);
    persist(db);
    return result;
  });
  queue = run.catch(() => undefined);
  return run;
}

export function newId(): string {
  return crypto.randomUUID();
}

const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function newRef(prefix: string): string {
  const bytes = crypto.randomBytes(6);
  let s = '';
  for (const b of bytes) s += REF_ALPHABET[b % REF_ALPHABET.length];
  return `${prefix}-${s}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function queueEmail(db: DbShape, to: string, subject: string, body: string) {
  db.outbox.push({
    id: newId(), to, subject, body, createdAt: nowIso(), delivery: 'not_sent_email_not_configured',
  });
}
