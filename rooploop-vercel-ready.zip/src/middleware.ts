import { NextResponse, type NextRequest } from 'next/server';

/**
 * On Vercel the local dev data store is ephemeral, so saving anything would silently lose it.
 * Until a real database (Supabase) is connected, every write request is refused with a clear message.
 * Set ALLOW_EPHEMERAL_STORE=1 on Vercel ONLY to try the flows knowing the data will not be kept.
 */
export function middleware(req: NextRequest) {
  const unsafe = process.env.VERCEL && !process.env.ALLOW_EPHEMERAL_STORE;
  if (unsafe && req.method !== 'GET' && req.method !== 'HEAD' && req.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.json(
      { ok: false, error: 'Saving is not switched on for this preview yet, because no database is connected. Nothing you submit would be kept.' },
      { status: 503 },
    );
  }
  return NextResponse.next();
}
export const config = { matcher: '/api/:path*' };
