/**
 * ROOPLOOP central image manifest.
 *
 * Every image on the site is referenced by KEY from here. To place or replace a
 * photograph, drop the file into public/assets/<folder>/ and set `file` below.
 * No component needs editing.
 *
 * While `file` is null (or the file is missing on disk) the site renders a
 * clearly labelled empty slot. It never substitutes stock or generated imagery.
 *
 * kind:
 *   brand       official logo / wordmark files
 *   product     official ROOPLOOP product photography
 *   campaign    editorial / lifestyle photography supplied by the brand
 *   inspiration reference only. Never presented as a ROOPLOOP product.
 */
export type ImageKind = 'brand' | 'product' | 'campaign' | 'inspiration';

export interface ImageSlot {
  /** Filename inside public/assets/<folder>/ , or null until supplied. */
  file: string | null;
  folder: 'brand' | 'products' | 'sections' | 'inspiration';
  kind: ImageKind;
  /** Where on the site the slot is used. */
  section: string;
  /** Desktop / mobile usage note. */
  usage: string;
  /** CSS object-position focal point, e.g. "50% 20%". */
  focal: string;
  /** Intended aspect ratio of the slot (width / height). Photos are never stretched. */
  aspect: string;
  alt: string;
}

export const siteImages = {
  // ---- Brand ------------------------------------------------------------
  'logo-primary': {
    file: 'logo-wordmark-crop.png', folder: 'brand', kind: 'brand',
    section: 'Header, footer, mobile drawer',
    usage: 'Desktop and mobile. Original proportions preserved.',
    focal: '50% 50%', aspect: '1300/590',
    alt: 'ROOPLOOP, a circular fashion house',
  },
  'logo-light': {
    file: null, folder: 'brand', kind: 'brand',
    section: 'Footer and any dark maroon backgrounds',
    usage: 'Light-on-dark variant of the official logo, if supplied.',
    focal: '50% 50%', aspect: '4/1',
    alt: 'ROOPLOOP, a circular fashion house',
  },

  // ---- Homepage ---------------------------------------------------------
  'hero-main': {
    file: 'patchwork-kantha-corset.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Hero',
    usage: 'Desktop: right half. Mobile: full width above headline.',
    focal: '50% 35%', aspect: '925/980',
    alt: 'Patchwork kantha corset worn with a floral skirt and ruched printed gloves',
  },
  'vertical-rework': {
    file: 'denim-vest-patchwork-back.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Four verticals / Rework My Wardrobe',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 45%', aspect: '4/5',
    alt: 'Denim vest with an embroidered, mirror-work and shell-fringe patchwork back panel',
  },
  'vertical-shop': {
    file: 'brown-mirrorwork-trousers.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Four verticals / Shop the Loop',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 40%', aspect: '4/5',
    alt: 'Brown flared trousers with mirror work and side lace-up detail',
  },
  'vertical-rent': {
    file: 'denim-patchwork-saree-set.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Four verticals / Rent the Look',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 55%', aspect: '4/5',
    alt: 'Denim patchwork saree drape with a denim blouse and skirt',
  },
  'vertical-giveback': {
    file: 'olive-corduroy-trousers.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Four verticals / Give It Another Life',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 40%', aspect: '4/5',
    alt: 'Olive corduroy wide-leg trousers with woven pattern inserts',
  },

  // ---- Transformations (genuine before/after pairs only) ---------------
  'transformation-1-before': {
    file: null, folder: 'sections', kind: 'product',
    section: 'Home / Transformations / Pair 1 (before)',
    usage: 'Only fill with a genuine "before" photo.',
    focal: '50% 50%', aspect: '4/5', alt: 'Original garment before rework',
  },
  'transformation-1-after': {
    file: null, folder: 'sections', kind: 'product',
    section: 'Home / Transformations / Pair 1 (after)',
    usage: 'Only fill with the matching finished piece.',
    focal: '50% 50%', aspect: '4/5', alt: 'The same garment after rework',
  },
  'inspiration-1': {
    file: 'gold-embroidered-mini-skirt.jpg', folder: 'products', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/5', alt: 'Gold embroidered mirror-work mini skirt with a beaded clutch',
  },
  'inspiration-2': {
    file: 'blockprint-patchwork-shirt.jpg', folder: 'products', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/5', alt: 'Block-print patchwork shirt with appliqued Devanagari lettering',
  },
  'inspiration-3': {
    file: 'patchwork-embroidered-boots.jpg', folder: 'products', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/5', alt: 'Knee-high boots covered in patchwork embroidery and beadwork',
  },

  // ---- Craft stories ----------------------------------------------------
  'craft-embroidery': {
    file: 'patchwork-embroidered-boots.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Craft stories / Embroidery',
    usage: 'Close-up textile detail. Do not crop away stitching.',
    focal: '50% 40%', aspect: '4/5', alt: 'Knee-high boots covered in patchwork embroidery, sequins and beadwork',
  },
  'craft-patchwork': {
    file: 'denim-vest-collage-full.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Craft stories / Patchwork',
    usage: 'Close-up textile detail.',
    focal: '25% 50%', aspect: '1/1', alt: 'Close views of embroidered patchwork squares, mirror work and shell fringe on a denim vest',
  },
  'craft-stitching': {
    file: 'blockprint-patchwork-shirt.jpg', folder: 'products', kind: 'campaign',
    section: 'Home / Craft stories / Stitching',
    usage: 'Close-up textile detail.',
    focal: '50% 55%', aspect: '1/1', alt: 'Block-print patchwork panels joined with applique lettering',
  },

  // ---- Our Story / service pages ---------------------------------------
  'story-main': {
    file: 'gold-embroidered-mini-skirt.jpg', folder: 'products', kind: 'campaign',
    section: 'Our Story / Header image',
    usage: 'Desktop wide, mobile cropped to focal point.',
    focal: '50% 55%', aspect: '16/9', alt: 'Embroidered mirror-work skirt photographed in a stone colonnade',
  },
  'rework-header': {
    file: 'denim-vest-patchwork-back.jpg', folder: 'products', kind: 'campaign',
    section: 'Rework page / Header image',
    usage: 'Side image next to intro copy.',
    focal: '50% 45%', aspect: '4/5', alt: 'Denim vest reworked with embroidered patchwork',
  },
  'giveback-header': {
    file: 'olive-corduroy-trousers.jpg', folder: 'products', kind: 'campaign',
    section: 'Give Back page / Header image',
    usage: 'Side image next to intro copy.',
    focal: '50% 40%', aspect: '4/5', alt: 'Olive corduroy trousers with woven inserts',
  },
} satisfies Record<string, ImageSlot>;

export type SiteImageKey = keyof typeof siteImages;

/**
 * Product / rental photographs. Keyed by product slug. Add filenames in
 * public/assets/products/. First entry is the main image.
 * Leave empty until real photographs are supplied.
 */
export const productImageFiles: Record<string, string[]> = {
  'patchwork-kantha-corset': ['patchwork-kantha-corset.jpg'],
  'brown-mirrorwork-trousers': ['brown-mirrorwork-trousers.jpg'],
  'patchwork-embroidered-boots': ['patchwork-embroidered-boots.jpg'],
  'denim-patchwork-vest': ['denim-vest-patchwork-back.jpg', 'denim-vest-collage-full.jpg'],
  'blockprint-patchwork-shirt': ['blockprint-patchwork-shirt.jpg'],
  'olive-corduroy-trousers': ['olive-corduroy-trousers.jpg'],
  // rentals
  'gold-embroidered-mini-skirt': ['gold-embroidered-mini-skirt.jpg'],
  'denim-patchwork-saree-set': ['denim-patchwork-saree-set.jpg'],
};
