import type { Metadata } from 'next';
import Link from 'next/link';
import { Img } from '@/components/Img';
import { getImage } from '@/lib/images';

export const metadata: Metadata = { title: 'Our Story', description: 'ROOPLOOP is a circular fashion house. Old stories. New forms.' };

export default function Story() {
  return (
    <>
      <section className="container-x pt-12 sm:pt-20">
        <p className="label text-maroon">Our story</p>
        <h1 className="mt-3 text-5xl sm:text-7xl max-w-3xl">Old stories. New forms.</h1>
        <div className="mt-12"><Img image={getImage('story-main')} ratio="16/9" sizes="100vw" /></div>
      </section>
      <section className="container-x section grid gap-12 md:grid-cols-2">
        <div>
          <h2 className="text-4xl">Roop + Loop</h2>
          <p className="mt-5 text-charcoal/90"><strong>Roop</strong> is form, beauty, appearance and transformation. <strong>Loop</strong> is circularity: reuse, and giving a garment another life. In our wordmark the two O&apos;s of LOOP are drawn as an infinity.</p>
        </div>
        <div>
          <p className="text-charcoal/90">ROOPLOOP transforms existing clothing, Indian textiles and discarded garments into contemporary designer fashion. We do this in four ways: reworking garments you already own, selling redesigned pieces, renting designer outfits, and taking clothing back through our give-back programme.</p>
          <p className="mt-4 text-charcoal/90">We are a contemporary Indian label, rooted in craft and curious about form.</p>
        </div>
      </section>
      <section className="bg-sand/60 section">
        <div className="container-x grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[['Rework', '/rework', 'Redesign a garment you own.'], ['Shop', '/shop', 'Buy a one-of-a-kind piece.'], ['Rent', '/rent', 'Wear a designer outfit for the moment.'], ['Give Back', '/give-back', 'Pass clothing on for assessment.']].map(([t, h, d]) => (
            <Link key={h} href={h} className="block border border-maroon/30 p-6 hover:bg-ivory"><h3 className="text-3xl">{t}</h3><p className="mt-2 text-[0.95rem]">{d}</p><span className="label mt-4 inline-block text-maroon">Explore</span></Link>
          ))}
        </div>
      </section>
    </>
  );
}
