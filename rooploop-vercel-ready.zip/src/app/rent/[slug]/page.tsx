import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Img } from '@/components/Img';
import { RentBooking } from './RentBooking';
import { getRental } from '@/lib/catalog';
import { getProductImages } from '@/lib/images';
import { getUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const r = getRental((await params).slug);
  return r ? { title: `Rent: ${r.name}` } : { title: 'Not found' };
}

export default async function RentalPage({ params }: Props) {
  const r = getRental((await params).slug);
  if (!r) notFound();
  const images = getProductImages(r.slug, r.name);
  const user = await getUser();
  return (
    <div className="container-x py-10 sm:py-16">
      <nav aria-label="Breadcrumb" className="text-[0.85rem]"><Link href="/rent" className="underline">Rent</Link> <span aria-hidden="true">/</span> {r.occasion}</nav>
      <div className="mt-6 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
        <div className="space-y-4">
          {images.map((im, i) => <Img key={i} image={im} fit="contain" priority={i === 0} sizes="(min-width:1024px) 55vw, 100vw" />)}
          <p className="text-[0.8rem] text-charcoal/75">Photographs are shown in full, uncropped and unedited.</p>
        </div>
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="label text-charcoal/75">{r.occasion}</p>
          <h1 className="mt-2 text-4xl sm:text-5xl">{r.name}</h1>
          {r.draft && <p className="mt-3 inline-block bg-sand px-3 py-1.5 text-[0.8rem]">Draft listing: description, fee and deposit are placeholders.</p>}
          <p className="mt-5 text-charcoal/90">{r.description}</p>
          <RentBooking item={{ slug: r.slug, name: r.name, sizes: r.sizes, fee: r.fee, deposit: r.deposit, minDays: r.minDays, maxDays: r.maxDays }} signedIn={!!user} />
          <div className="mt-10 divide-y divide-sand border-y border-sand text-[0.95rem]">
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Delivery and return</summary><p className="mt-3">Delivery and return arrangements will be confirmed with your booking. Return is due on the end date you select.</p></details>
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Late returns and damage</summary><p className="mt-3">Late-return and damage terms are drafts and will be confirmed. See the <Link className="underline" href="/rental-policy">rental policy</Link>.</p></details>
          </div>
        </div>
      </div>
    </div>
  );
}
