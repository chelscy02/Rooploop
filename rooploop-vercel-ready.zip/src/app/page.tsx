import Link from 'next/link';
import { Img } from '@/components/Img';
import { ProductCard } from '@/components/ProductCard';
import { NewsletterForm } from '@/components/NewsletterForm';
import { getImage } from '@/lib/images';
import { listProducts } from '@/lib/catalog';
import type { SiteImageKey } from '@/data/siteImages';

const verticals: { title: string; line: string; body: string; cta: string; href: string; img: SiteImageKey }[] = [
  { title: 'Rework My Wardrobe', line: 'Your clothes. Our creativity.', body: 'Send us a garment you already own and we propose a redesign. You see a quote before anything is made.', cta: 'Start my rework', href: '/rework', img: 'vertical-rework' },
  { title: 'Shop the Loop', line: 'Unique pieces. Real stories.', body: 'Redesigned garments, each one a single piece, ready to buy.', cta: 'Shop collection', href: '/shop', img: 'vertical-shop' },
  { title: 'Rent the Look', line: 'Wear the moment. Return the magic.', body: 'Designer outfits from ROOPLOOP, booked for the dates you need.', cta: 'Explore rentals', href: '/rent', img: 'vertical-rent' },
  { title: 'Give It Another Life', line: 'Pass it forward.', body: 'Submit clothing you no longer wear. We assess every submission and tell you where it can go.', cta: 'Give back', href: '/give-back', img: 'vertical-giveback' },
];

export default function Home() {
  const hero = getImage('hero-main');
  const featured = listProducts().filter((p) => p.featured).slice(0, 4);
  const insp: SiteImageKey[] = ['inspiration-1', 'inspiration-2', 'inspiration-3'];
  const craft: { key: SiteImageKey; title: string; text: string }[] = [
    { key: 'craft-embroidery', title: 'Embroidery and beadwork', text: 'Sequins, thread and beads set into patchwork.' },
    { key: 'craft-patchwork', title: 'Patchwork', text: 'Embroidered squares and mirror work, pieced together.' },
    { key: 'craft-stitching', title: 'Stitch and applique', text: 'Printed panels joined with lettering cut in cloth.' },
  ];

  return (
    <>
      {/* HERO */}
      <section aria-labelledby="hero-h" className="bg-ivory">
        <div className="container-x grid items-center gap-10 py-10 sm:py-16 lg:grid-cols-2 lg:gap-16">
          <div className="order-2 lg:order-1">
            <p className="label text-maroon">A Circular Fashion House</p>
            <span className="rule-gold mt-4" />
            <h1 id="hero-h" className="mt-6 text-[2.7rem] sm:text-6xl lg:text-[4.25rem]">Your Wardrobe Deserves Another Life.</h1>
            <p className="mt-6 max-w-md text-[1.05rem] text-charcoal/90">Reimagine what you own. Discover one-of-a-kind creations. Keep fashion moving.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/shop" className="btn-primary">Explore the loop</Link>
              <Link href="/rework" className="btn-outline">Rework your wardrobe</Link>
            </div>
          </div>
          <div className="order-1 lg:order-2"><Img image={hero} priority fit="contain" sizes="(min-width:1024px) 45vw, 100vw" /></div>
        </div>
      </section>

      {/* FOUR VERTICALS */}
      <section aria-labelledby="verticals-h" className="section bg-sand/50">
        <div className="container-x">
          <p className="label text-maroon">Four ways into the loop</p>
          <h2 id="verticals-h" className="mt-3 text-4xl sm:text-5xl max-w-2xl">Rework it. Wear it. Rent it. Pass it on.</h2>
          <ul className="mt-12 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
            {verticals.map((v) => (
              <li key={v.title}>
                <Link href={v.href} className="group block">
                  <Img image={getImage(v.img)} ratio="4/5" fit="contain" sizes="(min-width:1024px) 25vw, (min-width:640px) 50vw, 100vw" />
                  <p className="label mt-5 text-charcoal/75">{v.line}</p>
                  <h3 className="mt-2 text-[1.9rem]">{v.title}</h3>
                  <p className="mt-2 text-[0.95rem] text-charcoal/90">{v.body}</p>
                  <span className="mt-4 inline-block label text-maroon border-b border-maroon pb-0.5 group-hover:border-gold">{v.cta}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* FEATURED */}
      <section aria-labelledby="featured-h" className="section">
        <div className="container-x">
          <div className="flex items-end justify-between gap-6">
            <div>
              <p className="label text-maroon">Shop the loop</p>
              <h2 id="featured-h" className="mt-3 text-4xl sm:text-5xl">Featured pieces</h2>
            </div>
            <Link href="/shop" className="label text-maroon border-b border-maroon pb-0.5 shrink-0">View all</Link>
          </div>
          <p className="mt-4 max-w-xl text-[0.9rem] text-charcoal/80">Names, prices and stock shown here are draft values until the final catalogue is confirmed.</p>
          <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-4 lg:gap-x-6">
            {featured.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </section>

      {/* TRANSFORMATIONS */}
      <section aria-labelledby="transform-h" className="section bg-maroon text-ivory on-dark">
        <div className="container-x">
          <p className="label text-ivory/85">Transformations</p>
          <h2 id="transform-h" className="mt-3 text-4xl sm:text-5xl text-ivory max-w-2xl">Old stories. New forms.</h2>
          <p className="mt-5 max-w-xl text-ivory/90">A look at the kind of work ROOPLOOP is built around: panelled denim, mirror work, patchwork and woven inserts. Genuine before-and-after pairs will appear here as completed reworks are photographed.</p>
          <ul className="mt-12 grid gap-6 sm:grid-cols-3">
            {insp.map((k) => (
              <li key={k}>
                <Img image={getImage(k)} ratio="4/5" fit="contain" sizes="(min-width:640px) 33vw, 100vw" className="!bg-ivory/10" />
                <p className="label mt-3 text-ivory/80">Design inspiration</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CRAFT */}
      <section aria-labelledby="craft-h" className="section">
        <div className="container-x">
          <p className="label text-maroon">Craft stories</p>
          <h2 id="craft-h" className="mt-3 text-4xl sm:text-5xl max-w-2xl">Textile detail, up close</h2>
          <ul className="mt-12 grid gap-8 sm:grid-cols-3">
            {craft.map((c) => (
              <li key={c.key}>
                <Img image={getImage(c.key)} ratio="1/1" fit="contain" sizes="(min-width:640px) 33vw, 100vw" />
                <h3 className="mt-4 text-2xl">{c.title}</h3>
                <p className="mt-1 text-[0.95rem] text-charcoal/90">{c.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* PHILOSOPHY */}
      <section aria-labelledby="phil-h" className="section bg-sand/60">
        <div className="container-x">
          <h2 id="phil-h" className="text-4xl sm:text-5xl max-w-xl">The idea behind the loop</h2>
          <div className="mt-12 grid gap-10 md:grid-cols-3">
            {[
              ['Reimagine existing garments', 'Clothing you already own can become something new, shaped around you.'],
              ['Celebrate textile craftsmanship', 'Indian textiles and techniques sit at the centre of every redesign.'],
              ['Give clothing another life', 'Wear it, rent it, rework it or pass it on, so fewer garments are left unused.'],
            ].map(([t, d], i) => (
              <div key={t}>
                <p className="font-serif text-5xl text-gold" aria-hidden="true">0{i + 1}</p>
                <h3 className="mt-3 text-2xl">{t}</h3>
                <p className="mt-2 text-charcoal/90">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section aria-labelledby="nl-h" className="section">
        <div className="container-x max-w-2xl text-center">
          <h2 id="nl-h" className="text-4xl sm:text-5xl">Join the loop</h2>
          <p className="mt-4 text-charcoal/90">New pieces, rental drops and rework stories, sent occasionally.</p>
          <div className="mt-8 text-left"><NewsletterForm /></div>
        </div>
      </section>
    </>
  );
}
