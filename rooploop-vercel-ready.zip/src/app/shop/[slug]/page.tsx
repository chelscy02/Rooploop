import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Img } from '@/components/Img';
import { AddToBag } from '@/components/AddToBag';
import { WishlistButton } from '@/components/WishlistButton';
import { getProduct, isAvailable } from '@/lib/catalog';
import { getProductImages } from '@/lib/images';
import { inr } from '@/lib/format';

export const dynamic = 'force-dynamic';
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = getProduct((await params).slug);
  return p ? { title: p.name, description: p.description.slice(0, 150) } : { title: 'Not found' };
}

export default async function ProductPage({ params }: Props) {
  const p = getProduct((await params).slug);
  if (!p) notFound();
  const images = getProductImages(p.slug, p.name, p.images);
  const rows: [string, string][] = [['Materials', p.materials], ['Craft details', p.craftNotes], ['Care', p.care]];
  return (
    <div className="container-x py-10 sm:py-16">
      <nav aria-label="Breadcrumb" className="text-[0.85rem]"><Link href="/shop" className="underline">Shop</Link> <span aria-hidden="true">/</span> {p.category}</nav>
      <div className="mt-6 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
        <div className="space-y-4">
          {images.map((im, i) => (
            <Img key={i} image={im} fit="contain" priority={i === 0} sizes="(min-width:1024px) 55vw, 100vw" />
          ))}
          <p className="text-[0.8rem] text-charcoal/75">Photographs are shown in full, uncropped and unedited.</p>
        </div>
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="label text-charcoal/75">{p.category}</p>
          <div className="mt-2 flex items-start justify-between gap-4">
            <h1 className="text-4xl sm:text-5xl">{p.name}</h1>
            <WishlistButton slug={p.slug} name={p.name} className="border border-sand shrink-0" />
          </div>
          <p className="mt-4 text-2xl">{inr(p.price)}</p>
          {p.draft && <p className="mt-2 inline-block bg-sand px-3 py-1.5 text-[0.8rem]">Draft listing: price, description and stock are placeholders.</p>}
          <p className="mt-6 text-charcoal/90">{p.description}</p>
          <div className="mt-8">
            <AddToBag p={{ id: p.id, slug: p.slug, name: p.name, price: p.price, sizes: p.sizes, stock: p.stock, available: isAvailable(p), image: images[0].src, draft: p.draft }} />
          </div>
          <div className="mt-10 divide-y divide-sand border-y border-sand">
            {rows.map(([t, v]) => (
              <details key={t} className="py-4" open={t === 'Materials'}><summary className="label cursor-pointer text-maroon">{t}</summary><p className="mt-3 text-[0.95rem]">{v}</p></details>
            ))}
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Size guide</summary>
              <p className="mt-3 text-[0.95rem]">Measurements for this piece are to be added. Please <Link href="/contact" className="underline">contact us</Link> for exact dimensions before buying.</p></details>
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Shipping and returns</summary>
              <p className="mt-3 text-[0.95rem]">See our <Link href="/shipping-returns" className="underline">shipping and returns</Link> page. Terms are drafts until confirmed.</p></details>
          </div>
        </div>
      </div>
    </div>
  );
}
