import type { Metadata } from 'next';
import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { paymentsMode } from '@/lib/payments';
import { CheckoutForm } from './CheckoutForm';

export const metadata: Metadata = { title: 'Checkout' };
export const dynamic = 'force-dynamic';

export default async function Checkout() {
  const user = await getUser();
  const mode = paymentsMode();
  return (
    <div className="container-x py-12 sm:py-16 max-w-3xl">
      <h1 className="text-5xl">Checkout</h1>
      {mode === 'off' && (
        <div role="alert" className="mt-6 border border-maroon bg-sand/60 p-5">
          <p className="font-semibold">Checkout is not enabled yet.</p>
          <p className="mt-1 text-[0.95rem]">Payments have not been configured, so orders cannot be placed. Your bag is saved on this device.</p>
        </div>
      )}
      {mode === 'test' && (
        <div role="note" className="mt-6 border border-terracotta bg-sand/60 p-5">
          <p className="font-semibold">TEST MODE: no payment is taken.</p>
          <p className="mt-1 text-[0.95rem]">Orders placed here exercise the flow only. This mode is disabled in production.</p>
        </div>
      )}
      {!user ? (
        <div className="mt-8"><p>Please sign in to place an order.</p><Link className="btn-primary mt-4" href="/account/login?next=/checkout">Sign in or register</Link></div>
      ) : (
        <CheckoutForm mode={mode} defaults={{ name: user.name, phone: user.phone }} />
      )}
    </div>
  );
}
