'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useShop } from '@/components/Providers';
import { inr } from '@/lib/format';

declare global { interface Window { Razorpay?: new (o: Record<string, unknown>) => { open: () => void; on: (e: string, cb: (r: unknown) => void) => void } } }

export function CheckoutForm({ mode, defaults }: { mode: 'off' | 'test' | 'razorpay'; defaults: { name: string; phone: string } }) {
  const { lines, subtotal, clear, ready } = useShop();
  const key = useRef<string>('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [fe, setFe] = useState<Record<string, string>>({});
  const [done, setDone] = useState<{ ref: string; test: boolean } | null>(null);

  useEffect(() => { key.current = crypto.randomUUID(); }, []);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return; // duplicate-submission guard
    setBusy(true); setErr(''); setFe({});
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    try {
      const r = await fetch('/api/checkout', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...f, idempotencyKey: key.current, items: lines.map((l) => ({ productId: l.productId, size: l.size, qty: l.qty })) }),
      });
      const d = await r.json();
      if (!r.ok) { setErr(d.error ?? 'Could not place the order.'); setFe(d.fields ?? {}); setBusy(false); return; }
      if (d.mode === 'test') { clear(); setDone({ ref: d.ref, test: true }); setBusy(false); return; }
      await openRazorpay(d, f);
    } catch {
      setErr('Could not reach the server. Please try again.'); setBusy(false);
    }
  }

  async function openRazorpay(d: { razorpayOrderId: string; amount: number; keyId: string; ref: string }, f: Record<string, string>) {
    if (!window.Razorpay) {
      await new Promise<void>((res, rej) => { const s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js'; s.onload = () => res(); s.onerror = () => rej(); document.body.appendChild(s); });
    }
    const rz = new window.Razorpay!({
      key: d.keyId, amount: d.amount * 100, currency: 'INR', name: 'ROOPLOOP', order_id: d.razorpayOrderId,
      prefill: { name: f.name, contact: f.phone },
      handler: async (resp: Record<string, string>) => {
        const v = await fetch('/api/checkout/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(resp) });
        const vd = await v.json();
        if (v.ok) { clear(); setDone({ ref: vd.ref, test: false }); } else setErr(vd.error ?? 'Payment could not be verified.');
        setBusy(false);
      },
      modal: { ondismiss: () => { setBusy(false); setErr('Payment was not completed. You have not been charged.'); } },
    });
    rz.on('payment.failed', () => { setBusy(false); setErr('Payment failed. Please try again.'); });
    rz.open();
  }

  if (done) return (
    <div className="mt-8 border border-sand bg-sand/40 p-8" role="status">
      <h2 className="text-3xl">{done.test ? 'Test order placed' : 'Thank you'}</h2>
      <p className="mt-3">Order reference: <strong>{done.ref}</strong></p>
      {done.test && <p className="mt-2">This was a test order. No payment was taken.</p>}
      <Link href="/account/orders" className="btn-primary mt-6">View my orders</Link>
    </div>
  );
  if (!ready) return <p className="mt-8" role="status">Loading…</p>;
  if (lines.length === 0) return <p className="mt-8">Your bag is empty. <Link href="/shop" className="underline">Shop the loop</Link></p>;

  const Field = ({ id, label, area = false, v = '' }: { id: string; label: string; area?: boolean; v?: string }) => (
    <div>
      <label htmlFor={id} className="field-label">{label}</label>
      {area ? <textarea id={id} name={id} rows={3} required className="field" aria-invalid={!!fe[id]} /> : <input id={id} name={id} defaultValue={v} required className="field" aria-invalid={!!fe[id]} />}
      {fe[id] && <p className="field-error">{fe[id]}</p>}
    </div>
  );
  return (
    <form onSubmit={submit} noValidate className="mt-8 grid gap-10 md:grid-cols-[1.3fr_1fr]">
      <div className="space-y-5">
        <Field id="name" label="Full name" v={defaults.name} />
        <Field id="phone" label="Phone number" v={defaults.phone} />
        <Field id="address" label="Delivery address" area />
        {err && <p role="alert" className="field-error">{err}</p>}
      </div>
      <aside className="h-fit bg-sand/50 p-6">
        <h2 className="text-2xl">Your order</h2>
        <ul className="mt-4 space-y-2 text-[0.95rem]">{lines.map((l) => <li key={l.productId + l.size} className="flex justify-between gap-3"><span>{l.name} ({l.size}) × {l.qty}</span><span>{inr((l.price ?? 0) * l.qty)}</span></li>)}</ul>
        <p className="mt-4 flex justify-between border-t border-charcoal/20 pt-4 font-semibold"><span>Total</span><span>{inr(subtotal)}</span></p>
        <button className="btn-primary mt-6 w-full" disabled={busy || mode === 'off'} type="submit">{busy ? 'Processing…' : mode === 'test' ? 'Place test order' : 'Pay now'}</button>
      </aside>
    </form>
  );
}
