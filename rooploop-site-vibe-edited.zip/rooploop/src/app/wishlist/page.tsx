import type { Metadata } from 'next';
import { WishlistClient } from './WishlistClient';
import { listProducts, listRentals } from '@/lib/catalog';

export const metadata: Metadata = { title: 'Wishlist' };
export const dynamic = 'force-dynamic';

export default function Wishlist() {
  return (
    <div className="container-x py-12 sm:py-16">
      <h1 className="text-5xl">Wishlist</h1>
      <p className="mt-3 text-[0.9rem] text-charcoal/80">Saved on this device. Sign-in is not needed.</p>
      <WishlistClient products={listProducts().map((p) => ({ slug: p.slug, name: p.name, category: p.category, price: p.price }))} rentals={listRentals().map((r) => ({ slug: r.slug, name: r.name }))} />
    </div>
  );
}
