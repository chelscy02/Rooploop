'use client';
import Link from 'next/link';
import { useShop } from '@/components/Providers';
import { inr } from '@/lib/format';

export function WishlistClient({ products }: { products: { slug: string; name: string; category: string; price: number | null }[]; rentals: { slug: string; name: string }[] }) {
  const { wishlist, toggleWish, ready } = useShop();
  const items = products.filter((p) => wishlist.includes(p.slug));
  if (!ready) return <p className="mt-8" role="status">Loading…</p>;
  if (items.length === 0)
    return (
      <div className="mt-8 border border-sand bg-sand/40 p-10 text-center">
        <p className="font-serif text-3xl text-maroon">Your wishlist is empty.</p>
        <Link href="/shop" className="btn-primary mt-6">Browse the shop</Link>
      </div>
    );
  return (
    <ul className="mt-8 divide-y divide-sand border-y border-sand">
      {items.map((p) => (
        <li key={p.slug} className="flex flex-wrap items-center justify-between gap-4 py-5">
          <div><p className="label text-charcoal/75">{p.category}</p><Link href={`/shop/${p.slug}`} className="font-serif text-2xl text-maroon hover:underline">{p.name}</Link><p>{inr(p.price)}</p></div>
          <button className="btn-outline" onClick={() => toggleWish(p.slug)}>Remove</button>
        </li>
      ))}
    </ul>
  );
}
