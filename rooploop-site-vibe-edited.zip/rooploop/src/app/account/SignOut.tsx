'use client';
import { useRouter } from 'next/navigation';

export function SignOut() {
  const router = useRouter();
  return (
    <button className="label px-4 py-3 text-left underline" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); router.push('/'); router.refresh(); }}>Sign out</button>
  );
}
