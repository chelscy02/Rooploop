import { notFound, redirect } from 'next/navigation';
import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { readDb } from '@/lib/db';
import { fmtDate, inr } from '@/lib/format';
import { ActionButton } from '@/components/ActionButton';

export const dynamic = 'force-dynamic';

function Empty({ text, href, cta }: { text: string; href: string; cta: string }) {
  return <div className="border border-sand bg-sand/40 p-10 text-center"><p className="font-serif text-3xl text-maroon">{text}</p><Link href={href} className="btn-primary mt-6">{cta}</Link></div>;
}
const Badge = ({ children }: { children: React.ReactNode }) => <span className="inline-block bg-sand px-3 py-1 label text-charcoal">{children}</span>;

export default async function Section({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params;
  const user = await getUser();
  if (!user) redirect(`/account/login?next=/account/${section}`);
  const db = readDb();
  const uid = user.id;

  if (section === 'orders') {
    const rows = db.orders.filter((o) => o.userId === uid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">My orders</h2>
        {rows.length === 0 ? <Empty text="No orders yet." href="/shop" cta="Shop the loop" /> : rows.map((o) => (
          <article key={o.id} className="border border-sand p-5">
            <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-semibold">{o.ref}</p><Badge>{o.status}</Badge></div>
            <p className="mt-1 text-[0.85rem]">{fmtDate(o.createdAt)}{o.paymentMode === 'test' && ' · TEST ORDER, no payment taken'}</p>
            <ul className="mt-3 text-[0.95rem]">{o.items.map((i) => <li key={i.productId + i.size}>{i.name} ({i.size}) × {i.qty}</li>)}</ul>
            <p className="mt-3 font-medium">{inr(o.total)}</p>
          </article>))}
      </div>
    );
  }
  if (section === 'reworks') {
    const rows = db.reworks.filter((r) => r.userId === uid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">My reworks</h2>
        {rows.length === 0 ? <Empty text="No rework requests yet." href="/rework" cta="Start my rework" /> : rows.map((r) => (
          <article key={r.id} className="border border-sand p-5">
            <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-semibold">{r.ref} · {r.category}</p><Badge>{r.status}</Badge></div>
            <p className="mt-1 text-[0.85rem]">Submitted {fmtDate(r.createdAt)}</p>
            <p className="mt-3 text-[0.95rem]">{r.transformation}</p>
            <ul className="mt-3 flex flex-wrap gap-2">{r.fileIds.map((f, i) => <li key={f}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={`/api/files/${f}`} alt={`Your photo ${i + 1} for ${r.ref}`} className="h-20 w-20 object-cover" /></li>)}</ul>
            {r.quote ? (
              <div className="mt-4 bg-sand/50 p-4">
                <p className="label text-maroon">Quotation</p>
                <p className="mt-2 whitespace-pre-line text-[0.95rem]">{r.quote.design}</p>
                <p className="mt-2 font-medium">{inr(r.quote.price)} · {r.quote.timeline}</p>
                {r.quote.notes && <p className="mt-1 text-[0.9rem]">{r.quote.notes}</p>}
                {r.status === 'Quote Sent' && r.quote.customerResponse === 'pending' ? (
                  <div className="mt-4 flex flex-wrap gap-3">
                    <ActionButton url={`/api/reworks/${r.id}/respond`} body={{ action: 'accept' }} label="Accept quotation" variant="primary" confirm="Accept this quotation? Production can begin after you accept." />
                    <ActionButton url={`/api/reworks/${r.id}/respond`} body={{ action: 'decline' }} label="Decline" confirm="Decline this quotation? The request will be closed." />
                  </div>
                ) : <p className="mt-3 text-[0.9rem]">Your response: {r.quote.customerResponse}</p>}
              </div>
            ) : <p className="mt-4 text-[0.9rem] text-charcoal/80">Awaiting review. A quotation will appear here. Email notifications are not yet connected.</p>}
          </article>))}
      </div>
    );
  }
  if (section === 'rentals') {
    const rows = db.bookings.filter((b) => b.userId === uid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">My rentals</h2>
        {rows.length === 0 ? <Empty text="No rental bookings yet." href="/rent" cta="Explore rentals" /> : rows.map((b) => (
          <article key={b.id} className="border border-sand p-5">
            <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-semibold">{b.ref} · {b.itemName} ({b.size})</p><Badge>{b.status}</Badge></div>
            <p className="mt-2 text-[0.95rem]">{fmtDate(b.start)} to {fmtDate(b.end)} · return due {fmtDate(b.end)}</p>
            <p className="mt-1 text-[0.9rem]">Fee {inr(b.fee)} · Deposit {inr(b.deposit)} ({b.depositStatus})</p>
            {b.status === 'Requested' && <p className="mt-1 text-[0.85rem]">Dates held until {fmtDate(b.holdExpiresAt)} while we review.</p>}
            <p className="mt-1 text-[0.85rem] text-charcoal/80">Delivery and return instructions will be added once your booking is confirmed.</p>
            {(b.status === 'Requested' || b.status === 'Confirmed') && <div className="mt-4"><ActionButton url={`/api/rentals/${b.id}/cancel`} label="Cancel booking" confirm="Cancel this booking?" /></div>}
          </article>))}
      </div>
    );
  }
  if (section === 'give-back') {
    const rows = db.giveBacks.filter((g) => g.userId === uid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">My give back submissions</h2>
        {rows.length === 0 ? <Empty text="No submissions yet." href="/give-back" cta="Give back" /> : rows.map((g) => (
          <article key={g.id} className="border border-sand p-5">
            <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-semibold">{g.ref} · {g.count} item{g.count > 1 ? 's' : ''}</p><Badge>{g.status}</Badge></div>
            <p className="mt-1 text-[0.85rem]">Submitted {fmtDate(g.createdAt)}</p>
            <p className="mt-2 text-[0.95rem]">Assessment: {g.outcome}</p>
          </article>))}
      </div>
    );
  }
  if (section === 'wishlist') return <div><h2 className="text-3xl">Wishlist</h2><p className="mt-3">Your wishlist is saved on this device. <Link className="underline" href="/wishlist">Open wishlist</Link></p></div>;
  if (section === 'settings') {
    return (
      <div><h2 className="text-3xl">Account settings</h2>
        <dl className="mt-6 grid max-w-md grid-cols-[120px_1fr] gap-y-3 text-[0.95rem]"><dt className="label">Name</dt><dd>{user.name}</dd><dt className="label">Email</dt><dd>{user.email}</dd><dt className="label">Phone</dt><dd>{user.phone || 'Not set'}</dd></dl>
        <p className="mt-6 text-[0.85rem] text-charcoal/75">Editing profile details and changing your password are not built yet.</p>
      </div>
    );
  }
  notFound();
}
