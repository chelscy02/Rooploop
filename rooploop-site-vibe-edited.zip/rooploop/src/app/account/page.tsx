import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { readDb } from '@/lib/db';

export const dynamic = 'force-dynamic';
export default async function Account() {
  const user = await getUser();
  if (!user) redirect('/account/login');
  const db = readDb();
  const mine = <T extends { userId: string }>(a: T[]) => a.filter((x) => x.userId === user.id).length;
  const cards: [string, string, number][] = [
    ['Orders', '/account/orders', mine(db.orders)], ['Reworks', '/account/reworks', mine(db.reworks)],
    ['Rentals', '/account/rentals', mine(db.bookings)], ['Give Back', '/account/give-back', mine(db.giveBacks)],
  ];
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {cards.map(([t, h, n]) => <Link key={h} href={h} className="block border border-sand p-6 hover:bg-sand/40"><p className="font-serif text-5xl text-maroon">{n}</p><p className="label mt-2">{t}</p></Link>)}
    </div>
  );
}
