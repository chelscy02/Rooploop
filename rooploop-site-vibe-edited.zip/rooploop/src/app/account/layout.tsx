import Link from 'next/link';
import type { ReactNode } from 'react';
import { getUser } from '@/lib/auth';
import { SignOut } from './SignOut';

export const dynamic = 'force-dynamic';
const sections = [
  ['orders', 'My Orders'], ['reworks', 'My Reworks'], ['rentals', 'My Rentals'], ['give-back', 'My Give Back'], ['wishlist', 'Wishlist'], ['settings', 'Account Settings'],
] as const;

export default async function AccountLayout({ children }: { children: ReactNode }) {
  const user = await getUser();
  if (!user) return <>{children}</>; // login page renders itself; section pages redirect individually
  return (
    <div className="container-x py-10 sm:py-16">
      <p className="label text-maroon">Hello, {user.name.split(' ')[0]}</p>
      <h1 className="mt-2 text-5xl">My account</h1>
      <div className="mt-10 grid gap-10 lg:grid-cols-[240px_1fr]">
        <nav aria-label="Account" className="flex flex-wrap gap-2 lg:flex-col lg:gap-0 lg:border-t lg:border-sand">
          {sections.map(([s, l]) => <Link key={s} href={`/account/${s}`} className="label border border-sand px-4 py-3 hover:bg-sand/60 lg:border-0 lg:border-b">{l}</Link>)}
          <SignOut />
        </nav>
        <div>{children}</div>
      </div>
    </div>
  );
}
