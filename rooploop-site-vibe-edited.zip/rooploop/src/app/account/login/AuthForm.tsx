'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export function AuthForm({ next }: { next: string }) {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [fe, setFe] = useState<Record<string, string>>({});

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErr(''); setFe({});
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    try {
      const r = await fetch(`/api/auth/${mode}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
      const d = await r.json();
      if (!r.ok) { setErr(d.error ?? 'Something went wrong.'); setFe(d.fields ?? {}); setBusy(false); return; }
      router.push(d.role === 'admin' && next === '/account' ? '/admin' : next);
      router.refresh();
    } catch {
      setErr('Could not reach the server. Please try again.'); setBusy(false);
    }
  }
  const F = ({ id, label, type = 'text', auto }: { id: string; label: string; type?: string; auto?: string }) => (
    <div>
      <label htmlFor={id} className="field-label">{label}</label>
      <input id={id} name={id} type={type} autoComplete={auto} required className="field" aria-invalid={!!fe[id]} aria-describedby={fe[id] ? `${id}-e` : undefined} />
      {fe[id] && <p id={`${id}-e`} className="field-error">{fe[id]}</p>}
    </div>
  );
  return (
    <div className="mt-8">
      <div role="tablist" className="flex border-b border-sand">
        {(['login', 'register'] as const).map((m) => (
          <button key={m} role="tab" aria-selected={mode === m} onClick={() => { setMode(m); setErr(''); setFe({}); }}
            className={`label px-5 py-3 border-b-2 -mb-px ${mode === m ? 'border-maroon text-maroon' : 'border-transparent text-charcoal/70'}`}>{m === 'login' ? 'Sign in' : 'Create account'}</button>
        ))}
      </div>
      <form onSubmit={submit} noValidate className="mt-8 space-y-5">
        {mode === 'register' && <><F id="name" label="Full name" auto="name" /><F id="phone" label="Phone number" type="tel" auto="tel" /></>}
        <F id="email" label="Email" type="email" auto="email" />
        <F id="password" label={mode === 'register' ? 'Password (10+ characters)' : 'Password'} type="password" auto={mode === 'register' ? 'new-password' : 'current-password'} />
        {err && <p role="alert" className="field-error">{err}</p>}
        <button className="btn-primary w-full" disabled={busy} type="submit">{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
      </form>
    </div>
  );
}
