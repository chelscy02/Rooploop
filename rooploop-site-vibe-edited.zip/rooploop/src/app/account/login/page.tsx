import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import { AuthForm } from './AuthForm';

export const metadata: Metadata = { title: 'Sign in' };
export const dynamic = 'force-dynamic';

export default async function Login({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const sp = await searchParams;
  const next = sp.next && sp.next.startsWith('/') && !sp.next.startsWith('//') ? sp.next : '/account';
  if (await getUser()) redirect(next);
  return (
    <div className="container-x py-12 sm:py-20 max-w-xl">
      <h1 className="text-5xl">Your account</h1>
      <p className="mt-3 text-charcoal/90">Sign in to submit a rework, book a rental, give clothing back, or check out.</p>
      <AuthForm next={next} />
    </div>
  );
}
