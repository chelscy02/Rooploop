import type { Metadata } from 'next';
import { ServiceForm, type FieldDef } from '@/components/ServiceForm';
import { getUser } from '@/lib/auth';

export const metadata: Metadata = { title: 'Give It Another Life', description: 'Submit clothing for assessment under the ROOPLOOP give-back programme.' };
export const dynamic = 'force-dynamic';

const fields: FieldDef[] = [
  { name: 'fullName', label: 'Full name', required: true },
  { name: 'email', label: 'Email', type: 'email', required: true },
  { name: 'phone', label: 'Phone number', type: 'tel', required: true },
  { name: 'category', label: 'Garment category', type: 'select', required: true, options: ['Everyday wear', 'Occasion wear', 'Denim', 'Ethnic wear', 'Mixed items', 'Textiles / fabric', 'Other'] },
  { name: 'count', label: 'Number of garments', type: 'number', required: true, min: 1, max: 50 },
  { name: 'preference', label: 'Programme preference', type: 'select', options: ['No preference', 'Prefer donation', 'Prefer redesign or reuse', 'Prefer recycling'], hint: 'A preference only. We decide the outcome after assessment.' },
  { name: 'condition', label: 'Garment condition', type: 'textarea', required: true },
  { name: 'logistics', label: 'Collection or drop-off', type: 'select', required: true, options: ['Collection from my address', 'I will drop off', 'Undecided'], hint: 'Availability will be confirmed after review.' },
  { name: 'address', label: 'Collection address', type: 'textarea', hint: 'Required for collection.' },
  { name: 'notes', label: 'Anything else we should know', type: 'textarea' },
];

export default async function GiveBack() {
  const user = await getUser();
  return (
    <div className="container-x py-12 sm:py-20">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr] lg:gap-20">
        <div>
          <p className="label text-maroon">Pass it forward.</p>
          <h1 className="mt-3 text-5xl sm:text-6xl">Give it another life</h1>
          <p className="mt-5 text-charcoal/90">Submit clothing you no longer wear. We assess each submission and tell you the outcome: donation, redesign or reuse, resale, textile recycling, or not accepted.</p>
          <p className="mt-4 text-[0.95rem] text-charcoal/90">Not every item can be accepted, and we do not promise a specific destination in advance. Give Back is separate from paid Rework requests.</p>
        </div>
        <ServiceForm
          endpoint="/api/give-back" fields={fields} signedIn={!!user} loginNext="/give-back"
          defaults={{ fullName: user?.name ?? '', email: user?.email ?? '', phone: user?.phone ?? '' }}
          photoLabel="Garment photos" submitLabel="Submit for assessment"
          success={{ title: 'Submission received', body: 'We will assess your submission and update its status in your account. Email notifications are not yet connected, so please check your dashboard.', dashboard: '/account/give-back', dashboardLabel: 'View my submissions' }}
        />
      </div>
    </div>
  );
}
