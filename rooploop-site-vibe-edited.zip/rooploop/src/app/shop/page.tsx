import type { Metadata } from 'next';
import Link from 'next/link';
import { ProductCard } from '@/components/ProductCard';
import { listProducts } from '@/lib/catalog';
import { productCategories } from '@/data/products';

export const metadata: Metadata = { title: 'Shop the Loop', description: 'One-of-a-kind redesigned garments from ROOPLOOP.' };
export const dynamic = 'force-dynamic';

type SP = Record<string, string | string[] | undefined>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? '';

export default async function Shop({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = one(sp.q).trim().toLowerCase();
  const category = one(sp.category);
  const size = one(sp.size);
  const colour = one(sp.colour);
  const min = Number(one(sp.min)) || 0;
  const max = Number(one(sp.max)) || Infinity;
  const sort = one(sp.sort) || 'featured';

  const all = listProducts();
  const sizes = [...new Set(all.flatMap((p) => p.sizes))];
  const colours = [...new Set(all.map((p) => p.colour))];

  let items = all.filter((p) =>
    (!q || `${p.name} ${p.category} ${p.colour} ${p.description}`.toLowerCase().includes(q)) &&
    (!category || p.category === category) &&
    (!size || (p.stock[size] ?? 0) > 0) &&
    (!colour || p.colour === colour) &&
    (p.price === null ? min === 0 && max === Infinity : p.price >= min && p.price <= max));
  if (sort === 'price-asc') items = [...items].sort((a, b) => (a.price ?? 0) - (b.price ?? 0));
  if (sort === 'price-desc') items = [...items].sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
  if (sort === 'name') items = [...items].sort((a, b) => a.name.localeCompare(b.name));
  if (sort === 'featured') items = [...items].sort((a, b) => Number(b.featured) - Number(a.featured));

  const filtered = !!(q || category || size || colour || min || max !== Infinity);

  return (
    <div className="container-x py-12 sm:py-16">
      <p className="label text-maroon">Shop the loop</p>
      <h1 className="mt-3 text-5xl sm:text-6xl">Unique pieces. Real stories.</h1>
      <p className="mt-4 max-w-xl text-[0.9rem] text-charcoal/80">Product names, prices and stock are draft values until the final catalogue is confirmed.</p>

      <form method="get" className="mt-10 grid gap-4 border-y border-sand py-6 sm:grid-cols-2 lg:grid-cols-6" aria-label="Filter products">
        <div className="lg:col-span-2"><label className="field-label" htmlFor="q">Search</label><input id="q" name="q" defaultValue={one(sp.q)} className="field" placeholder="Name, colour, category" /></div>
        <div><label className="field-label" htmlFor="category">Category</label>
          <select id="category" name="category" defaultValue={category} className="field"><option value="">All</option>{productCategories.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="field-label" htmlFor="size">Size in stock</label>
          <select id="size" name="size" defaultValue={size} className="field"><option value="">Any</option>{sizes.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div><label className="field-label" htmlFor="colour">Colour</label>
          <select id="colour" name="colour" defaultValue={colour} className="field"><option value="">Any</option>{colours.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div><label className="field-label" htmlFor="sort">Sort</label>
          <select id="sort" name="sort" defaultValue={sort} className="field">
            <option value="featured">Featured</option><option value="price-asc">Price, low to high</option><option value="price-desc">Price, high to low</option><option value="name">Name</option></select></div>
        <div><label className="field-label" htmlFor="min">Min price (₹)</label><input id="min" name="min" type="number" min={0} inputMode="numeric" defaultValue={min || ''} className="field" /></div>
        <div><label className="field-label" htmlFor="max">Max price (₹)</label><input id="max" name="max" type="number" min={0} inputMode="numeric" defaultValue={max === Infinity ? '' : max} className="field" /></div>
        <div className="flex items-end gap-3 lg:col-span-2"><button className="btn-primary" type="submit">Apply</button>{filtered && <Link href="/shop" className="btn-outline">Clear</Link>}</div>
      </form>

      <p className="mt-6 text-[0.9rem]" role="status">{items.length} {items.length === 1 ? 'piece' : 'pieces'}</p>
      {items.length === 0 ? (
        <div className="mt-6 border border-sand bg-sand/40 p-10 text-center">
          <p className="font-serif text-3xl text-maroon">Nothing matches those filters.</p>
          <Link href="/shop" className="btn-primary mt-6">Clear filters</Link>
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-4 lg:gap-x-6">{items.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      )}
    </div>
  );
}
