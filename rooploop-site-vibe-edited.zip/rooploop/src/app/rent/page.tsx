import type { Metadata } from 'next';
import { RentalCard } from '@/components/RentalCard';
import { listRentals } from '@/lib/catalog';

export const metadata: Metadata = { title: 'Rent the Look', description: 'Designer outfits from ROOPLOOP, available to rent.' };
export const dynamic = 'force-dynamic';

export default function Rent() {
  const items = listRentals();
  return (
    <div className="container-x py-12 sm:py-16">
      <p className="label text-maroon">Wear the moment. Return the magic.</p>
      <h1 className="mt-3 text-5xl sm:text-6xl">Rent the look</h1>
      <p className="mt-5 max-w-xl text-charcoal/90">Every outfit here belongs to ROOPLOOP. Pick a size and dates and we check availability for the whole period before you request a booking.</p>
      <p className="mt-3 max-w-xl text-[0.9rem] text-charcoal/80">Fees, deposits and rental lengths shown are draft values. Online payment is not enabled yet; deposits are not collected through the site.</p>
      {items.length === 0 ? <p className="mt-10">No rental outfits are listed right now.</p> : (
        <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-3 lg:gap-x-6">{items.map((r) => <RentalCard key={r.id} r={r} />)}</div>
      )}
    </div>
  );
}
