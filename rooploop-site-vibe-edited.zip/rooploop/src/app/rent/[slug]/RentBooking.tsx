'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { inr, fmtDate } from '@/lib/format';

interface Item { slug: string; name: string; sizes: string[]; fee: number; deposit: number; minDays: number; maxDays: number }
type Check = { state: 'idle' } | { state: 'busy' } | { state: 'error'; msg: string } | { state: 'result'; available: boolean; days: number };

export function RentBooking({ item, signedIn }: { item: Item; signedIn: boolean }) {
  const today = new Date().toISOString().slice(0, 10);
  const [size, setSize] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [terms, setTerms] = useState(false);
  const [check, setCheck] = useState<Check>({ state: 'idle' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [ref, setRef] = useState<string | null>(null);

  useEffect(() => {
    setErr('');
    if (!size || !start || !end) { setCheck({ state: 'idle' }); return; }
    const ctl = new AbortController();
    setCheck({ state: 'busy' });
    fetch(`/api/rentals/availability?${new URLSearchParams({ slug: item.slug, size, start, end })}`, { signal: ctl.signal })
      .then((r) => r.json())
      .then((d) => setCheck(d.ok ? { state: 'result', available: d.available, days: d.days } : { state: 'error', msg: d.error }))
      .catch((e) => { if (e.name !== 'AbortError') setCheck({ state: 'error', msg: 'Could not check availability.' }); });
    return () => ctl.abort();
  }, [size, start, end, item.slug]);

  async function book() {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/rentals/book', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: item.slug, size, start, end, acceptTerms: terms }) });
      const d = await r.json();
      if (!r.ok) setErr(d.error ?? 'Could not create the booking.'); else setRef(d.ref);
    } catch { setErr('Could not reach the server. No booking was created.'); }
    setBusy(false);
  }

  if (ref) return (
    <div role="status" className="mt-8 border border-sand bg-sand/40 p-6">
      <h2 className="text-3xl">Booking requested</h2>
      <p className="mt-3">Reference: <strong>{ref}</strong></p>
      <p className="mt-2 text-[0.95rem]">{item.name}, size {size}, {fmtDate(start)} to {fmtDate(end)}. Your dates are held while we review. This is a request, not yet a confirmed booking.</p>
      <Link href="/account/rentals" className="btn-primary mt-5">View my rentals</Link>
    </div>
  );

  const canBook = check.state === 'result' && check.available && terms && signedIn;
  return (
    <div className="mt-8">
      <fieldset>
        <legend className="field-label">Size</legend>
        <div className="flex flex-wrap gap-2">{item.sizes.map((s) => (
          <button key={s} type="button" aria-pressed={size === s} onClick={() => setSize(s)} className={`min-w-[52px] border px-4 py-3 text-sm ${size === s ? 'border-maroon bg-maroon text-ivory' : 'border-charcoal/40 hover:border-maroon'}`}>{s}</button>
        ))}</div>
      </fieldset>
      <div className="mt-5 grid grid-cols-2 gap-4">
        <div><label className="field-label" htmlFor="rs">Start date</label><input id="rs" type="date" min={today} value={start} onChange={(e) => { setStart(e.target.value); if (end && e.target.value > end) setEnd(''); }} className="field" /></div>
        <div><label className="field-label" htmlFor="re">End (return) date</label><input id="re" type="date" min={start || today} value={end} onChange={(e) => setEnd(e.target.value)} className="field" /></div>
      </div>
      <p className="mt-2 text-[0.82rem] text-charcoal/75">Rentals run {item.minDays} to {item.maxDays} days, counting both dates.</p>

      <div className="mt-5 min-h-[3.5rem]" aria-live="polite" role="status">
        {check.state === 'idle' && <p className="text-[0.9rem]">Select a size and dates to check availability.</p>}
        {check.state === 'busy' && <p className="text-[0.9rem]">Checking availability…</p>}
        {check.state === 'error' && <p className="field-error">{check.msg}</p>}
        {check.state === 'result' && (check.available
          ? <p className="font-medium text-maroon">Available for all {check.days} days.</p>
          : <p className="field-error">Not available for the whole period. Please try other dates or size.</p>)}
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-y-1 bg-sand/50 p-4 text-[0.95rem]">
        <dt>Rental fee</dt><dd className="text-right">{inr(item.fee)}</dd>
        <dt>Refundable deposit</dt><dd className="text-right">{inr(item.deposit)}</dd>
      </dl>
      <p className="mt-2 text-[0.82rem] text-charcoal/75">Online payment and deposit handling are not enabled yet. Nothing is charged by this request.</p>

      <label className="mt-5 flex items-start gap-3 text-[0.9rem]">
        <input type="checkbox" checked={terms} onChange={(e) => setTerms(e.target.checked)} className="mt-1 h-5 w-5 accent-[#581E2A]" />
        <span>I have read the <Link href="/rental-policy" className="underline" target="_blank">rental terms</Link> (draft) and understand the return date and damage policy.</span>
      </label>
      {err && <p role="alert" className="field-error mt-3">{err}</p>}
      {!signedIn && <p className="mt-4 text-[0.9rem]"><Link className="underline font-semibold" href={`/account/login?next=/rent/${item.slug}`}>Sign in or register</Link> to request a booking.</p>}
      <button type="button" className="btn-primary mt-5 w-full sm:w-auto sm:min-w-[260px]" disabled={!canBook || busy} onClick={book}>{busy ? 'Requesting…' : 'Request booking'}</button>
    </div>
  );
}
