import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { RentBooking } from './RentBooking';
import { getRental } from '@/lib/catalog';
import { getUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const r = getRental((await params).slug);
  return r ? { title: `Rent: ${r.name}` } : { title: 'Not found' };
}

export default async function RentalPage({ params }: Props) {
  const r = getRental((await params).slug);
  if (!r) notFound();
  const user = await getUser();
  return (
    <div className="container-x py-10 sm:py-16">
      <nav aria-label="Breadcrumb" className="text-[0.85rem]"><Link href="/rent" className="underline">Rent</Link> <span aria-hidden="true">/</span> {r.occasion}</nav>
      <div className="mt-6 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
        <div className="border-y border-sand py-8 lg:sticky lg:top-28 lg:self-start">
          <p className="label text-charcoal/70">ROOPLOOP · Rental wardrobe</p>
          <p className="mt-4 font-serif text-3xl text-maroon">Wear the moment. Return the magic.</p>
          <p className="mt-3 text-[0.95rem] text-charcoal/80">Rental photography will be added once the available inventory is confirmed. Inspiration images elsewhere are references, not rental listings.</p>
        </div>
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="label text-charcoal/75">{r.occasion}</p>
          <h1 className="mt-2 text-4xl sm:text-5xl">{r.name}</h1>
          {r.draft && <p className="mt-3 inline-block bg-sand px-3 py-1.5 text-[0.8rem]">Draft listing: description, fee and deposit are placeholders.</p>}
          <p className="mt-5 text-charcoal/90">{r.description}</p>
          <RentBooking item={{ slug: r.slug, name: r.name, sizes: r.sizes, fee: r.fee, deposit: r.deposit, minDays: r.minDays, maxDays: r.maxDays }} signedIn={!!user} />
          <div className="mt-10 divide-y divide-sand border-y border-sand text-[0.95rem]">
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Delivery and return</summary><p className="mt-3">Delivery and return arrangements will be confirmed with your booking. Return is due on the end date you select.</p></details>
            <details className="py-4"><summary className="label cursor-pointer text-maroon">Late returns and damage</summary><p className="mt-3">Late-return and damage terms are drafts and will be confirmed. See the <Link className="underline" href="/rental-policy">rental policy</Link>.</p></details>
          </div>
        </div>
      </div>
    </div>
  );
}
