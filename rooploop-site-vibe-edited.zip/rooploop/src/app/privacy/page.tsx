import type { Metadata } from 'next';
import { PolicyPage } from '@/components/Prose';
export const metadata: Metadata = { title: 'Privacy Policy' };
export default function Page() {
  return (
    <PolicyPage title="Privacy Policy" intro="Placeholder structure. Have this reviewed and completed before launch.">
      <div><h2>What we collect</h2><p>Account details, contact details, photographs you upload for Rework and Give Back, orders, bookings and messages you send us.</p></div>
      <div><h2>How it is used</h2><p>To provide the services you request. Your photos and requests are visible only to you and ROOPLOOP staff.</p></div>
      <div><h2>Your rights and contact</h2><p>Business contact and grievance details: to be confirmed.</p></div>
    </PolicyPage>
  );
}
