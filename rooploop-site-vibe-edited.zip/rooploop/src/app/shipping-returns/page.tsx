import type { Metadata } from 'next';
import { PolicyPage } from '@/components/Prose';
export const metadata: Metadata = { title: 'Shipping and Returns' };
export default function Page() {
  return (
    <PolicyPage title="Shipping and Returns" intro="Placeholder structure. Delivery areas, timelines, charges and the return window are to be confirmed by ROOPLOOP.">
      <div><h2>Shipping</h2><ul><li>Delivery areas: to be confirmed</li><li>Dispatch time: to be confirmed</li><li>Shipping charges: to be confirmed</li></ul></div>
      <div><h2>Returns and exchanges</h2><ul><li>Return window: to be confirmed</li><li>Condition required: to be confirmed</li><li>Refund method: to be confirmed</li></ul></div>
      <div><h2>Rework and rentals</h2><p>Custom Rework pieces and rentals follow their own terms. See the <a className="underline" href="/rental-policy">rental policy</a>.</p></div>
    </PolicyPage>
  );
}
