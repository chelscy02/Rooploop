import type { Metadata } from 'next';
import { PolicyPage } from '@/components/Prose';
export const metadata: Metadata = { title: 'Terms and Conditions' };
export default function Page() {
  return (
    <PolicyPage title="Terms and Conditions" intro="Placeholder structure. Have this reviewed and completed before launch.">
      <div><h2>Using the site</h2><p>General terms of use: to be confirmed.</p></div>
      <div><h2>Rework quotations</h2><p>Rework pricing is quote-based. Work begins only after you accept a quotation.</p></div>
      <div><h2>Give Back</h2><p>Submissions are assessed and are not guaranteed to be accepted.</p></div>
      <div><h2>Governing law</h2><p>To be confirmed.</p></div>
    </PolicyPage>
  );
}
