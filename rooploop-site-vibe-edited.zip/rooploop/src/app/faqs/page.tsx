import type { Metadata } from 'next';
import { PolicyPage } from '@/components/Prose';

export const metadata: Metadata = { title: 'FAQs' };
const faqs: [string, string][] = [
  ['How does Rework work?', 'You submit photos and your idea. We review and send a quotation with a proposed design, price and timeline. Nothing is made or charged until you accept.'],
  ['Is a Rework request free to submit?', 'Yes. Submitting a request does not charge you.'],
  ['Are the shop pieces one-of-a-kind?', 'Pieces are redesigned from existing garments, so stock per size is limited. What is shown is what is available.'],
  ['How does renting work?', 'Choose a size and dates. We check that the outfit is free for the whole period, then you request a booking. We review and confirm it.'],
  ['Will you accept everything in Give Back?', 'No. We assess each submission and tell you whether it can be donated, reused or redesigned, resold, recycled, or not accepted.'],
  ['When will payments be available?', 'Online payment is not enabled yet. This page will be updated when it is.'],
];
export default function Faqs() {
  return (
    <PolicyPage title="FAQs">
      {faqs.map(([q, a]) => <div key={q}><h2>{q}</h2><p>{a}</p></div>)}
    </PolicyPage>
  );
}
