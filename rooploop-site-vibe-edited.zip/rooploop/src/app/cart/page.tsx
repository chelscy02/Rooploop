'use client';
import Link from 'next/link';
import Image from 'next/image';
import { useShop } from '@/components/Providers';
import { inr } from '@/lib/format';

export default function Cart() {
  const { lines, setQty, remove, subtotal, ready } = useShop();
  return (
    <div className="container-x py-12 sm:py-16">
      <h1 className="text-5xl">Shopping bag</h1>
      {!ready ? <p className="mt-8" role="status">Loading…</p> : lines.length === 0 ? (
        <div className="mt-8 border border-sand bg-sand/40 p-10 text-center">
          <p className="font-serif text-3xl text-maroon">Your bag is empty.</p>
          <Link href="/shop" className="btn-primary mt-6">Shop the loop</Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <ul className="divide-y divide-sand border-y border-sand">
            {lines.map((l) => (
              <li key={l.productId + l.size} className="flex gap-4 py-5">
                <div className="relative h-28 w-24 shrink-0 bg-sand">{l.image && <Image src={l.image} alt={l.name} fill sizes="96px" style={{ objectFit: 'cover', objectPosition: '50% 30%' }} />}</div>
                <div className="flex-1">
                  <Link href={`/shop/${l.slug}`} className="font-serif text-xl text-maroon hover:underline">{l.name}</Link>
                  <p className="text-[0.9rem]">Size {l.size} · {inr(l.price)}</p>
                  <div className="mt-3 flex items-center gap-4">
                    <div className="flex items-center border border-charcoal/40" role="group" aria-label={`Quantity for ${l.name}`}>
                      <button className="h-10 w-10" aria-label="Decrease quantity" onClick={() => setQty(l.productId, l.size, l.qty - 1)} disabled={l.qty <= 1}>−</button>
                      <span className="w-8 text-center" aria-live="polite">{l.qty}</span>
                      <button className="h-10 w-10" aria-label="Increase quantity" onClick={() => setQty(l.productId, l.size, l.qty + 1)} disabled={l.qty >= l.max}>+</button>
                    </div>
                    <button className="text-[0.85rem] underline" onClick={() => remove(l.productId, l.size)}>Remove</button>
                  </div>
                  {l.qty >= l.max && <p className="mt-2 text-[0.8rem] text-charcoal/80">Maximum available in this size.</p>}
                </div>
                <p className="font-medium">{inr((l.price ?? 0) * l.qty)}</p>
              </li>
            ))}
          </ul>
          <aside className="h-fit bg-sand/50 p-6" aria-label="Order summary">
            <h2 className="text-2xl">Summary</h2>
            <p className="mt-4 flex justify-between"><span>Subtotal</span><span>{inr(subtotal)}</span></p>
            <p className="mt-1 text-[0.85rem] text-charcoal/80">Shipping and taxes: to be confirmed. Stock and prices are re-checked at checkout.</p>
            <Link href="/checkout" className="btn-primary mt-6 w-full">Checkout</Link>
          </aside>
        </div>
      )}
    </div>
  );
}
