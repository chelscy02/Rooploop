import type { Metadata } from 'next';
import { ContactForm } from './ContactForm';

export const metadata: Metadata = { title: 'Contact' };

export default function Contact() {
  return (
    <div className="container-x py-12 sm:py-20 max-w-2xl">
      <h1 className="text-5xl sm:text-6xl">Contact</h1>
      <p className="mt-4 text-charcoal/90">Questions about a piece, a rental or a rework? Send us a message.</p>
      <p className="mt-2 text-[0.85rem] text-charcoal/75">Messages are saved for the team to read. Replies are not automated yet.</p>
      <ContactForm />
    </div>
  );
}
