'use client';
import { useState } from 'react';

export function ContactForm() {
  const [state, setState] = useState<'idle' | 'busy' | 'ok'>('idle');
  const [err, setErr] = useState('');
  const [fe, setFe] = useState<Record<string, string>>({});
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setState('busy'); setErr(''); setFe({});
    try {
      const r = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))) });
      const d = await r.json();
      if (!r.ok) { setErr(d.error ?? 'Something went wrong.'); setFe(d.fields ?? {}); setState('idle'); return; }
      setState('ok');
    } catch { setErr('Could not reach the server. Your message was not sent.'); setState('idle'); }
  }
  if (state === 'ok') return <div role="status" className="mt-8 border border-sand bg-sand/40 p-8"><h2 className="text-3xl">Message received</h2><p className="mt-2">Thank you. We have saved your message.</p></div>;
  return (
    <form onSubmit={submit} noValidate className="mt-8 space-y-5">
      {[['name', 'Name', 'text'], ['email', 'Email', 'email']].map(([id, l, t]) => (
        <div key={id}><label className="field-label" htmlFor={id}>{l}</label><input id={id} name={id} type={t} required className="field" aria-invalid={!!fe[id]} />{fe[id] && <p className="field-error">{fe[id]}</p>}</div>
      ))}
      <div><label className="field-label" htmlFor="message">Message</label><textarea id="message" name="message" rows={6} required className="field" aria-invalid={!!fe.message} />{fe.message && <p className="field-error">{fe.message}</p>}</div>
      {err && <p role="alert" className="field-error">{err}</p>}
      <button className="btn-primary" disabled={state === 'busy'} type="submit">{state === 'busy' ? 'Sending…' : 'Send message'}</button>
    </form>
  );
}
