import { fail, guardUser, json } from '@/lib/api';
import { mutate, newId, newRef, nowIso, queueEmail } from '@/lib/db';
import { saveUploads, validateUploads } from '@/lib/uploads';
import { EMAIL_RE, normalisePhone, str } from '@/lib/validation';

export async function POST(req: Request) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  let form: FormData;
  try { form = await req.formData(); } catch { return fail('Invalid form submission.'); }
  const v = (k: string, max = 2000) => str(form.get(k), max);
  const d = {
    fullName: v('fullName', 120), email: v('email', 200).toLowerCase(), phone: v('phone', 30), category: v('category', 80), condition: v('condition', 600),
    logistics: v('logistics', 80), address: v('address', 600), preference: v('preference', 80), notes: v('notes'),
  };
  const count = Math.floor(Number(v('count', 5)));
  const fields: Record<string, string> = {};
  if (d.fullName.length < 2) fields.fullName = 'Enter your full name.';
  if (!EMAIL_RE.test(d.email)) fields.email = 'Enter a valid email address.';
  const phone = normalisePhone(d.phone);
  if (!phone) fields.phone = 'Enter a valid phone number.';
  if (!d.category) fields.category = 'Choose a garment category.';
  if (d.condition.length < 5) fields.condition = 'Describe the condition of the garment(s).';
  if (!(count >= 1 && count <= 50)) fields.count = 'Enter a number between 1 and 50.';
  if (!d.logistics) fields.logistics = 'Choose a collection or drop-off preference.';
  if (d.logistics === 'Collection from my address' && d.address.length < 10) fields.address = 'Enter your collection address.';
  if (Object.keys(fields).length) return fail('Please correct the highlighted fields.', 422, fields);

  const up = await validateUploads(form.getAll('photos').filter((x): x is File => x instanceof File));
  if ('error' in up) return json({ ok: false, error: 'Please check your photos.', fileError: up.error }, 422);
  const fileIds = await saveUploads(g.user.id, up.files);

  const ref = newRef('GVB');
  await mutate((db) => {
    const now = nowIso();
    db.giveBacks.push({ id: newId(), ref, userId: g.user.id, ...d, phone: phone!, count, fileIds, status: 'Submitted', outcome: 'Not yet assessed', adminNotes: '', createdAt: now, updatedAt: now });
    queueEmail(db, d.email, `Give Back submission ${ref} received`, 'Thank you. We will assess your submission and let you know the outcome. Not every item can be accepted.');
  });
  return json({ ok: true, ref });
}
