import { fail, json } from '@/lib/api';
import { endSession, sameOrigin } from '@/lib/auth';

export async function POST() {
  if (!(await sameOrigin())) return fail('Cross-origin request blocked.', 403);
  await endSession();
  return json({ ok: true });
}
