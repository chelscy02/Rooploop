import { fail, json, readJson } from '@/lib/api';
import { hashPassword, sameOrigin, startSession, throttled } from '@/lib/auth';
import { mutate, newId, nowIso } from '@/lib/db';
import { EMAIL_RE, normalisePhone, str } from '@/lib/validation';
import { headers } from 'next/headers';

export async function POST(req: Request) {
  if (!(await sameOrigin())) return fail('Cross-origin request blocked.', 403);
  const ip = (await headers()).get('x-forwarded-for') ?? 'local';
  if (throttled(`reg:${ip}`, 10)) return fail('Too many attempts. Please try again later.', 429);
  const b = await readJson(req);
  const name = str(b?.name, 100), email = str(b?.email, 200).toLowerCase(), password = typeof b?.password === 'string' ? b.password : '';
  const phone = normalisePhone(str(b?.phone, 30));
  const fields: Record<string, string> = {};
  if (name.length < 2) fields.name = 'Enter your name.';
  if (!EMAIL_RE.test(email)) fields.email = 'Enter a valid email address.';
  if (!phone) fields.phone = 'Enter a valid phone number.';
  if (password.length < 10) fields.password = 'Use at least 10 characters.';
  if (Object.keys(fields).length) return fail('Please correct the highlighted fields.', 422, fields);
  const id = await mutate((db) => {
    if (db.users.some((u) => u.email === email)) return null;
    const uid = newId();
    db.users.push({ id: uid, email, name, phone: phone!, passwordHash: hashPassword(password), role: 'customer', createdAt: nowIso() });
    return uid;
  });
  if (!id) return fail('An account with this email already exists. Please sign in.', 409, { email: 'Already registered' });
  await startSession(id);
  return json({ ok: true });
}
