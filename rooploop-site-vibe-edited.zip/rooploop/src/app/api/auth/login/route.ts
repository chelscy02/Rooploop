import { fail, json, readJson } from '@/lib/api';
import { sameOrigin, startSession, throttled, verifyPassword, hashPassword } from '@/lib/auth';
import { readDb } from '@/lib/db';
import { str } from '@/lib/validation';
import { headers } from 'next/headers';

const DUMMY = hashPassword('dummy-password-for-timing');

export async function POST(req: Request) {
  if (!(await sameOrigin())) return fail('Cross-origin request blocked.', 403);
  const ip = (await headers()).get('x-forwarded-for') ?? 'local';
  const b = await readJson(req);
  const email = str(b?.email, 200).toLowerCase();
  const password = typeof b?.password === 'string' ? b.password : '';
  if (throttled(`login:${ip}:${email}`)) return fail('Too many attempts. Please try again in a few minutes.', 429);
  const u = readDb().users.find((x) => x.email === email);
  const ok = verifyPassword(password, u ? u.passwordHash : DUMMY);
  if (!u || !ok) return fail('Email or password is incorrect.', 401);
  await startSession(u.id);
  return json({ ok: true, role: u.role });
}
