import fs from 'node:fs';
import path from 'node:path';
import { fail, guardAdmin, json } from '@/lib/api';
import { mutate } from '@/lib/db';
import { MAX_FILE_BYTES, sniffImage, str } from '@/lib/validation';

/**
 * Admin product image upload. Writes into public/assets/products, so it only
 * persists on a host with a writable disk. For production use Supabase Storage.
 */
export async function POST(req: Request) {
  const g = await guardAdmin();
  if ('res' in g) return g.res;
  const form = await req.formData().catch(() => null);
  if (!form) return fail('Invalid form submission.');
  const id = str(form.get('id'), 80);
  const files = form.getAll('images').filter((x): x is File => x instanceof File && x.size > 0);
  if (!id || files.length === 0) return fail('Choose a product and at least one image.');
  const saved: string[] = [];
  for (const f of files) {
    if (f.size > MAX_FILE_BYTES) return fail(`"${f.name}" is larger than 8 MB.`);
    const buf = Buffer.from(await f.arrayBuffer());
    const mime = sniffImage(buf); if (!mime) return fail(`"${f.name}" is not a JPG, PNG or WebP image.`);
    const base = path.basename(f.name, path.extname(f.name)).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50) || 'image';
    const name = `${base}-${Date.now().toString(36)}.${mime === 'image/jpeg' ? 'jpg' : mime === 'image/png' ? 'png' : 'webp'}`;
    fs.mkdirSync(path.join(process.cwd(), 'public', 'assets', 'products'), { recursive: true });
    fs.writeFileSync(path.join(process.cwd(), 'public', 'assets', 'products', name), buf);
    saved.push(name);
  }
  try {
    await mutate((db) => { const p = db.products.find((x) => x.id === id); if (!p) throw new Error('Product not found.'); p.images = [...(p.images ?? []), ...saved]; });
  } catch (e) { return fail(e instanceof Error ? e.message : 'Failed.', 404); }
  return json({ ok: true, saved });
}
