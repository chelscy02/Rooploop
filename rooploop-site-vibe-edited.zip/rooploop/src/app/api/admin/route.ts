import { fail, guardAdmin, json, readJson } from '@/lib/api';
import {
  mutate, newId, nowIso, queueEmail, reworkStatuses, giveBackStatuses, giveBackOutcomes, orderStatuses, bookingStatuses,
  type ReworkStatus, type GiveBackStatus, type OrderStatus, type BookingStatus, type DepositStatus,
} from '@/lib/db';
import { unitFree } from '@/lib/rentals';
import { productCategories, type Product, type ProductCategory } from '@/data/products';
import { str } from '@/lib/validation';

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);

function parseSizes(raw: string): { sizes: string[]; stock: Record<string, number> } {
  const sizes: string[] = []; const stock: Record<string, number> = {};
  for (const part of raw.split(',')) {
    const [s, q] = part.split(':').map((x) => x.trim());
    if (!s) continue;
    const n = Math.max(0, Math.floor(Number(q ?? 0)) || 0);
    if (!sizes.includes(s)) sizes.push(s);
    stock[s] = n;
  }
  return { sizes, stock };
}

/**
 * Single admin mutation endpoint. EVERY request re-checks the admin role on the
 * server (guardAdmin); hiding buttons in the UI is not what protects this.
 */
export async function POST(req: Request) {
  const g = await guardAdmin();
  if ('res' in g) return g.res;
  const b = await readJson(req);
  if (!b) return fail('Invalid request.');
  const action = str(b.action, 40);
  const id = str(b.id, 80);

  try {
    const result = await mutate((db) => {
      switch (action) {
        case 'order.status': {
          const o = db.orders.find((x) => x.id === id); if (!o) throw new Error('Order not found.');
          const st = str(b.status, 40) as OrderStatus; if (!orderStatuses.includes(st)) throw new Error('Invalid status.');
          if (st === 'Cancelled' && o.stockCommitted) {
            for (const i of o.items) { const p = db.products.find((x) => x.id === i.productId); if (p) p.stock[i.size] = (p.stock[i.size] ?? 0) + i.qty; }
            o.stockCommitted = false;
          }
          o.status = st; o.updatedAt = nowIso(); return;
        }
        case 'product.save': {
          const name = str(b.name, 140); if (name.length < 2) throw new Error('Name is required.');
          const category = str(b.category, 60) as ProductCategory; if (!productCategories.includes(category)) throw new Error('Choose a category.');
          const { sizes, stock } = parseSizes(str(b.sizes, 300)); if (sizes.length === 0) throw new Error('Enter sizes like "S:2, M:1".');
          const priceRaw = str(b.price, 12); const price = priceRaw === '' ? null : Math.round(Number(priceRaw));
          if (price !== null && (!Number.isFinite(price) || price < 0)) throw new Error('Price must be a positive number or blank.');
          const status = (['available', 'sold_out', 'archived'].includes(str(b.status, 20)) ? str(b.status, 20) : 'available') as Product['status'];
          const base = {
            name, category, colour: str(b.colour, 40) || 'Multi', price, sizes, stock, status, description: str(b.description, 3000),
            materials: str(b.materials, 500) || 'To be confirmed', craftNotes: str(b.craftNotes, 800) || 'To be confirmed', care: str(b.care, 800) || 'To be confirmed',
            featured: b.featured === true, draft: b.draft === true,
          };
          if (id) {
            const p = db.products.find((x) => x.id === id); if (!p) throw new Error('Product not found.');
            Object.assign(p, base); return { id: p.id };
          }
          let slug = slugify(str(b.slug, 80) || name); if (!slug) throw new Error('Invalid slug.');
          while (db.products.some((x) => x.slug === slug)) slug += '-2';
          const np: Product = { id: newId(), slug, currency: 'INR', productType: 'ready-to-buy', ...base };
          db.products.push(np); return { id: np.id };
        }
        case 'product.archive': {
          const p = db.products.find((x) => x.id === id); if (!p) throw new Error('Product not found.');
          p.status = b.restore === true ? 'available' : 'archived'; return;
        }
        case 'rework.update': {
          const r = db.reworks.find((x) => x.id === id); if (!r) throw new Error('Request not found.');
          const st = str(b.status, 30) as ReworkStatus; if (!reworkStatuses.includes(st)) throw new Error('Invalid status.');
          r.adminNotes = str(b.adminNotes, 4000);
          const design = str(b.design, 4000), priceRaw = str(b.price, 12), timeline = str(b.timeline, 200);
          if (design || priceRaw || timeline) {
            const price = Math.round(Number(priceRaw));
            if (!design || !timeline || !Number.isFinite(price) || price <= 0) throw new Error('A quotation needs a proposed design, a price and a timeline.');
            if (r.quote?.customerResponse === 'accepted' && (r.quote.price !== price || r.quote.design !== design)) throw new Error('The customer has already accepted the quotation. It cannot be changed.');
            if (!r.quote || r.quote.price !== price || r.quote.design !== design || r.quote.timeline !== timeline || r.quote.notes !== str(b.quoteNotes, 2000)) {
              r.quote = { design, price, timeline, notes: str(b.quoteNotes, 2000), sentAt: nowIso(), customerResponse: 'pending' };
              r.status = 'Quote Sent';
              queueEmail(db, r.email, `Quotation for ${r.ref}`, `${design}\nPrice: INR ${price}\nTimeline: ${timeline}`);
              r.updatedAt = nowIso(); return;
            }
          }
          // No paid production before the customer has approved a quotation.
          if (['Approved', 'In Production', 'Ready to Ship', 'Completed'].includes(st) && r.quote?.customerResponse !== 'accepted')
            throw new Error('The customer has not accepted a quotation yet, so this status cannot be set.');
          r.status = st; r.updatedAt = nowIso(); return;
        }
        case 'rework.recordApproval': {
          const r = db.reworks.find((x) => x.id === id); if (!r || !r.quote) throw new Error('No quotation to approve.');
          r.quote.customerResponse = 'accepted'; r.quote.respondedAt = nowIso(); r.status = 'Approved'; r.adminNotes += `\n[${nowIso()}] Approval recorded by admin on customer's behalf.`; r.updatedAt = nowIso(); return;
        }
        case 'giveback.update': {
          const x = db.giveBacks.find((y) => y.id === id); if (!x) throw new Error('Submission not found.');
          const st = str(b.status, 50) as GiveBackStatus; if (!giveBackStatuses.includes(st)) throw new Error('Invalid status.');
          const out = str(b.outcome, 50); if (!(giveBackOutcomes as readonly string[]).includes(out)) throw new Error('Invalid outcome.');
          x.status = st; x.outcome = out as typeof x.outcome; x.adminNotes = str(b.adminNotes, 4000); x.updatedAt = nowIso(); return;
        }
        case 'booking.update': {
          const k = db.bookings.find((y) => y.id === id); if (!k) throw new Error('Booking not found.');
          const st = str(b.status, 30) as BookingStatus; if (!bookingStatuses.includes(st)) throw new Error('Invalid status.');
          if ((st === 'Confirmed' || st === 'Out for Rental') && !unitFree(db.bookings, k.unitId, k.start, k.end, k.id))
            throw new Error('Conflict: another active booking overlaps these dates for this garment.');
          if (st === 'Confirmed') k.holdExpiresAt = '9999-12-31T00:00:00.000Z';
          k.status = st; k.depositStatus = str(b.depositStatus, 60) as DepositStatus || k.depositStatus; k.adminNotes = str(b.adminNotes, 2000); k.updatedAt = nowIso(); return;
        }
        case 'rental.save': {
          const r = db.rentals.find((x) => x.id === id); if (!r) throw new Error('Rental item not found.');
          const fee = Math.round(Number(b.fee)), deposit = Math.round(Number(b.deposit));
          if (![fee, deposit].every((n) => Number.isFinite(n) && n >= 0)) throw new Error('Fee and deposit must be numbers.');
          r.fee = fee; r.deposit = deposit; r.status = b.archived === true ? 'archived' : 'active'; r.draft = b.draft === true;
          r.name = str(b.name, 140) || r.name; r.description = str(b.description, 3000) || r.description; return;
        }
        case 'enquiry.handled': {
          const e = db.enquiries.find((x) => x.id === id); if (!e) throw new Error('Enquiry not found.'); e.handled = b.handled === true; return;
        }
        default: throw new Error('Unknown action.');
      }
    });
    return json({ ok: true, ...(result ?? {}) });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Action failed.', 422);
  }
}
