import { fail, guardUser, json } from '@/lib/api';
import { mutate, nowIso } from '@/lib/db';

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  const id = (await params).id;
  try {
    await mutate((db) => {
      const b = db.bookings.find((x) => x.id === id && x.userId === g.user.id);
      if (!b) throw new Error('Booking not found.');
      if (b.status !== 'Requested' && b.status !== 'Confirmed') throw new Error('This booking can no longer be cancelled online.');
      b.status = 'Cancelled'; b.updatedAt = nowIso();
    });
    return json({ ok: true });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Could not cancel.', 409);
  }
}
