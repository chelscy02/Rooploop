import { fail, json } from '@/lib/api';
import { readDb } from '@/lib/db';
import { findFreeUnit } from '@/lib/rentals';
import { daysBetweenInclusive, isIsoDate, todayIso } from '@/lib/validation';

/** Public, read-only availability check. The booking route re-checks atomically. */
export async function GET(req: Request) {
  const u = new URL(req.url);
  const slug = u.searchParams.get('slug') ?? '', size = u.searchParams.get('size') ?? '', start = u.searchParams.get('start') ?? '', end = u.searchParams.get('end') ?? '';
  const db = readDb();
  const item = db.rentals.find((r) => r.slug === slug && r.status === 'active');
  if (!item) return fail('Rental item not found.', 404);
  if (!item.sizes.includes(size)) return fail('Choose a size.', 422);
  if (!isIsoDate(start) || !isIsoDate(end)) return fail('Choose valid start and end dates.', 422);
  if (start < todayIso()) return fail('The start date cannot be in the past.', 422);
  if (end < start) return fail('The end date must be on or after the start date.', 422);
  const days = daysBetweenInclusive(start, end);
  if (days < item.minDays || days > item.maxDays) return fail(`Rentals run from ${item.minDays} to ${item.maxDays} days.`, 422);
  const unit = findFreeUnit(db.bookings, item, size, start, end);
  return json({ ok: true, available: !!unit, days, fee: item.fee, deposit: item.deposit });
}
