import { fail, guardUser, json, readJson } from '@/lib/api';
import { mutate, newId, newRef, nowIso, queueEmail } from '@/lib/db';
import { HOLD_HOURS, findFreeUnit } from '@/lib/rentals';
import { daysBetweenInclusive, isIsoDate, str, todayIso } from '@/lib/validation';

export async function POST(req: Request) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  const b = await readJson(req);
  const slug = str(b?.slug, 100), size = str(b?.size, 20), start = str(b?.start, 10), end = str(b?.end, 10);
  if (b?.acceptTerms !== true) return fail('Please accept the rental terms to continue.', 422);
  if (!isIsoDate(start) || !isIsoDate(end) || start < todayIso() || end < start) return fail('Choose valid rental dates.', 422);
  try {
    const out = await mutate((db) => {
      // Server-side, atomic availability check + insert (no client-side trust).
      const now = Date.now();
      for (const x of db.bookings) if (x.status === 'Requested' && Date.parse(x.holdExpiresAt) < now) { x.status = 'Expired'; x.updatedAt = nowIso(); }
      const item = db.rentals.find((r) => r.slug === slug && r.status === 'active');
      if (!item || !item.sizes.includes(size)) throw new Error('This rental is not available.');
      const days = daysBetweenInclusive(start, end);
      if (days < item.minDays || days > item.maxDays) throw new Error(`Rentals run from ${item.minDays} to ${item.maxDays} days.`);
      const unitId = findFreeUnit(db.bookings, item, size, start, end);
      if (!unitId) throw new Error('Sorry, that size is not available for the whole period. Please try other dates.');
      const t = nowIso();
      const booking = {
        id: newId(), ref: newRef('RNT'), userId: g.user.id, itemId: item.id, itemName: item.name, unitId, size, start, end,
        fee: item.fee, deposit: item.deposit, status: 'Requested' as const, depositStatus: 'Not collected (payments disabled)' as const,
        holdExpiresAt: new Date(now + HOLD_HOURS * 3600_000).toISOString(), adminNotes: '', createdAt: t, updatedAt: t,
      };
      db.bookings.push(booking);
      queueEmail(db, g.user.email, `Rental request ${booking.ref} received`, `Dates are held for ${HOLD_HOURS} hours while we review.`);
      return booking;
    });
    return json({ ok: true, ref: out.ref });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Could not create the booking.', 409);
  }
}
