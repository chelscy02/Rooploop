import { fail, guardUser, json } from '@/lib/api';
import { mutate, newId, newRef, nowIso, queueEmail } from '@/lib/db';
import { saveUploads, validateUploads } from '@/lib/uploads';
import { EMAIL_RE, normalisePhone, str } from '@/lib/validation';

export async function POST(req: Request) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  let form: FormData;
  try { form = await req.formData(); } catch { return fail('Invalid form submission.'); }
  const v = (k: string, max = 2000) => str(form.get(k), max);
  const d = {
    fullName: v('fullName', 120), email: v('email', 200).toLowerCase(), phone: v('phone', 30), category: v('category', 80), condition: v('condition', 80),
    transformation: v('transformation'), stylePreferences: v('stylePreferences'), colourPreferences: v('colourPreferences', 300),
    budget: v('budget', 80), instructions: v('instructions'), fulfilment: v('fulfilment', 120),
  };
  const fields: Record<string, string> = {};
  if (d.fullName.length < 2) fields.fullName = 'Enter your full name.';
  if (!EMAIL_RE.test(d.email)) fields.email = 'Enter a valid email address.';
  const phone = normalisePhone(d.phone);
  if (!phone) fields.phone = 'Enter a valid phone number.';
  if (!d.category) fields.category = 'Choose a garment category.';
  if (!d.condition) fields.condition = 'Describe the garment condition.';
  if (d.transformation.length < 10) fields.transformation = 'Tell us a little more about the transformation you want.';
  if (!d.budget) fields.budget = 'Choose a budget range.';
  if (Object.keys(fields).length) return fail('Please correct the highlighted fields.', 422, fields);

  const up = await validateUploads(form.getAll('photos').filter((x): x is File => x instanceof File));
  if ('error' in up) return json({ ok: false, error: 'Please check your photos.', fileError: up.error }, 422);
  const fileIds = await saveUploads(g.user.id, up.files);

  const ref = newRef('RWK');
  await mutate((db) => {
    const now = nowIso();
    db.reworks.push({ id: newId(), ref, userId: g.user.id, ...d, phone: phone!, fileIds, status: 'Submitted', quote: null, adminNotes: '', createdAt: now, updatedAt: now });
    queueEmail(db, d.email, `Rework request ${ref} received`, 'We have received your rework request and will send a quotation after review.');
  });
  return json({ ok: true, ref });
}
