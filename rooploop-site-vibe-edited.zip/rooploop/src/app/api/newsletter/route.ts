import { fail, json, readJson } from '@/lib/api';
import { sameOrigin } from '@/lib/auth';
import { mutate, newId, nowIso } from '@/lib/db';
import { EMAIL_RE, str } from '@/lib/validation';

export async function POST(req: Request) {
  if (!(await sameOrigin())) return fail('Cross-origin request blocked.', 403);
  const body = await readJson(req);
  const email = str(body?.email, 200).toLowerCase();
  if (!EMAIL_RE.test(email)) return fail('Please enter a valid email address.', 422, { email: 'Invalid email' });
  await mutate((db) => {
    if (!db.subscribers.some((s) => s.email === email)) db.subscribers.push({ id: newId(), email, createdAt: nowIso() });
  });
  // No mailing-list provider is connected: the address is stored, no confirmation email is sent.
  return json({ ok: true, message: 'Thank you. You are on the list.' });
}
