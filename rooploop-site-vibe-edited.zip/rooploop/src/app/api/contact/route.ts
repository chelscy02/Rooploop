import { fail, json, readJson } from '@/lib/api';
import { sameOrigin } from '@/lib/auth';
import { mutate, newId, nowIso } from '@/lib/db';
import { EMAIL_RE, str } from '@/lib/validation';

export async function POST(req: Request) {
  if (!(await sameOrigin())) return fail('Cross-origin request blocked.', 403);
  const b = await readJson(req);
  const name = str(b?.name, 100), email = str(b?.email, 200).toLowerCase(), message = str(b?.message, 4000);
  const fields: Record<string, string> = {};
  if (name.length < 2) fields.name = 'Enter your name.';
  if (!EMAIL_RE.test(email)) fields.email = 'Enter a valid email address.';
  if (message.length < 5) fields.message = 'Write a short message.';
  if (Object.keys(fields).length) return fail('Please correct the highlighted fields.', 422, fields);
  await mutate((db) => { db.enquiries.push({ id: newId(), name, email, message, createdAt: nowIso(), handled: false }); });
  return json({ ok: true });
}
