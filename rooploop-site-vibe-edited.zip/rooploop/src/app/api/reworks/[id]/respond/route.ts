import { fail, guardUser, json, readJson } from '@/lib/api';
import { mutate, nowIso } from '@/lib/db';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  const b = await readJson(req);
  const action = b?.action;
  if (action !== 'accept' && action !== 'decline') return fail('Invalid action.');
  const id = (await params).id;
  try {
    await mutate((db) => {
      const r = db.reworks.find((x) => x.id === id && x.userId === g.user.id); // owner only
      if (!r) throw new Error('Request not found.');
      if (r.status !== 'Quote Sent' || !r.quote || r.quote.customerResponse !== 'pending') throw new Error('There is no open quotation to respond to.');
      r.quote.customerResponse = action === 'accept' ? 'accepted' : 'declined';
      r.quote.respondedAt = nowIso();
      r.status = action === 'accept' ? 'Approved' : 'Cancelled';
      r.updatedAt = nowIso();
    });
    return json({ ok: true });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Could not record your response.', 409);
  }
}
