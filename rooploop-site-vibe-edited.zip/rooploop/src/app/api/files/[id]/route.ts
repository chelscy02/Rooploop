import fs from 'node:fs';
import path from 'node:path';
import { NextResponse } from 'next/server';
import { getUser } from '@/lib/auth';
import { readDb, UPLOAD_DIR } from '@/lib/db';

/** Uploaded photos are private: only the owner or an admin may read them. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUser();
  if (!user) return new NextResponse('Unauthorised', { status: 401 });
  const { id } = await params;
  const f = readDb().files.find((x) => x.id === id);
  if (!f || (f.ownerId !== user.id && user.role !== 'admin')) return new NextResponse('Not found', { status: 404 });
  const full = path.join(UPLOAD_DIR, path.basename(f.path));
  if (!fs.existsSync(full)) return new NextResponse('Not found', { status: 404 });
  return new NextResponse(new Uint8Array(fs.readFileSync(full)), {
    headers: { 'Content-Type': f.mime, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline' },
  });
}
