import { fail, guardUser, json, readJson } from '@/lib/api';
import { mutate, nowIso, queueEmail } from '@/lib/db';
import { verifyRazorpaySignature } from '@/lib/payments';
import { str } from '@/lib/validation';

export async function POST(req: Request) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  const b = await readJson(req);
  const orderId = str(b?.razorpay_order_id, 80), paymentId = str(b?.razorpay_payment_id, 80), sig = str(b?.razorpay_signature, 200);
  if (!orderId || !paymentId || !sig) return fail('Missing payment details.');
  if (!verifyRazorpaySignature(orderId, paymentId, sig)) return fail('Payment could not be verified.', 400);
  try {
    const out = await mutate((db) => {
      const o = db.orders.find((x) => x.razorpayOrderId === orderId && x.userId === g.user.id);
      if (!o) throw new Error('Order not found.');
      if (o.status === 'Paid' || o.stockCommitted) return o; // retry-safe
      for (const i of o.items) {
        const p = db.products.find((x) => x.id === i.productId);
        if (!p || (p.stock[i.size] ?? 0) < i.qty) {
          o.status = 'Payment Failed'; o.updatedAt = nowIso();
          o.razorpayPaymentId = paymentId;
          throw new Error('Payment was received but an item sold out. We will contact you about a refund.');
        }
      }
      for (const i of o.items) { const p = db.products.find((x) => x.id === i.productId)!; p.stock[i.size] -= i.qty; }
      o.status = 'Paid'; o.stockCommitted = true; o.razorpayPaymentId = paymentId; o.updatedAt = nowIso();
      queueEmail(db, o.email, `Order ${o.ref} confirmed`, `Thank you. Payment ${paymentId} verified.`);
      return o;
    });
    return json({ ok: true, ref: out.ref });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Verification failed.', 409);
  }
}
