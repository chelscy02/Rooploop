import { fail, guardUser, json, readJson } from '@/lib/api';
import { mutate, newId, newRef, nowIso, readDb, queueEmail, type OrderItem } from '@/lib/db';
import { createRazorpayOrder, paymentsMode } from '@/lib/payments';
import { normalisePhone, str } from '@/lib/validation';

export async function POST(req: Request) {
  const g = await guardUser();
  if ('res' in g) return g.res;
  const mode = paymentsMode();
  if (mode === 'off') return fail('Checkout is not enabled yet. Payments have not been configured.', 503);

  const body = await readJson(req);
  if (!body) return fail('Invalid request.');
  const name = str(body.name, 120);
  const phone = normalisePhone(str(body.phone, 30));
  const address = str(body.address, 600);
  const key = str(body.idempotencyKey, 80);
  const raw = Array.isArray(body.items) ? body.items : [];
  const fields: Record<string, string> = {};
  if (name.length < 2) fields.name = 'Enter your full name.';
  if (!phone) fields.phone = 'Enter a valid phone number.';
  if (address.length < 10) fields.address = 'Enter your full delivery address.';
  if (key.length < 8) return fail('Missing request key. Please reload and try again.');
  if (raw.length === 0 || raw.length > 20) return fail('Your bag is empty.');
  if (Object.keys(fields).length) return fail('Please correct the highlighted fields.', 422, fields);

  // Duplicate-submission protection: same key returns the same order.
  const existing = readDb().orders.find((o) => o.idempotencyKey === key && o.userId === g.user.id);
  if (existing) return json({ ok: true, orderId: existing.id, ref: existing.ref, mode: existing.paymentMode, razorpayOrderId: existing.razorpayOrderId, amount: existing.total, duplicate: true });

  try {
    const result = await mutate((db) => {
      const items: OrderItem[] = [];
      let draft = false;
      for (const r of raw as Record<string, unknown>[]) {
        const p = db.products.find((x) => x.id === r.productId && x.status === 'available');
        const size = str(r.size, 20);
        const qty = Math.floor(Number(r.qty));
        if (!p || !p.sizes.includes(size) || !(qty >= 1 && qty <= 10)) throw new Error('One of the items in your bag is no longer available.');
        if (p.price === null) throw new Error(`"${p.name}" has no confirmed price yet.`);
        if ((p.stock[size] ?? 0) < qty) throw new Error(`Only ${p.stock[size] ?? 0} of "${p.name}" in size ${size} left.`);
        if (p.draft) draft = true;
        const same = items.find((i) => i.productId === p.id && i.size === size);
        if (same) same.qty += qty; else items.push({ productId: p.id, slug: p.slug, name: p.name, size, qty, unitPrice: p.price });
      }
      for (const i of items) {
        const p = db.products.find((x) => x.id === i.productId)!;
        if ((p.stock[i.size] ?? 0) < i.qty) throw new Error(`Only ${p.stock[i.size] ?? 0} of "${p.name}" in size ${i.size} left.`);
      }
      if (draft && mode === 'razorpay') throw new Error('Sample (draft) catalogue items cannot be bought with real payments.');
      const total = items.reduce((n, i) => n + i.unitPrice * i.qty, 0);
      const now = nowIso();
      const order = {
        id: newId(), ref: newRef('ORD'), userId: g.user.id, name, email: g.user.email, phone: phone!, address, items, total,
        currency: 'INR' as const, status: 'Pending Payment' as const, paymentMode: mode === 'test' ? ('test' as const) : ('razorpay' as const),
        idempotencyKey: key, stockCommitted: false, draftCatalogue: draft, createdAt: now, updatedAt: now,
      };
      if (mode === 'test') {
        // TEST MODE: no payment is taken. Stock is committed so the flow can be exercised end to end.
        for (const i of items) { const p = db.products.find((x) => x.id === i.productId)!; p.stock[i.size] -= i.qty; }
        (order as { status: string }).status = 'Processing'; // no payment was taken, so never 'Paid'
        order.stockCommitted = true;
        queueEmail(db, g.user.email, `Order ${order.ref} (TEST ORDER, no payment taken)`, `Items: ${items.map((i) => `${i.name} (${i.size}) x${i.qty}`).join(', ')}`);
      }
      db.orders.push(order);
      return order;
    });

    if (mode === 'razorpay') {
      const rp = await createRazorpayOrder(result.total, result.ref);
      if ('error' in rp) {
        await mutate((db) => { const o = db.orders.find((x) => x.id === result.id); if (o) { o.status = 'Payment Failed'; o.updatedAt = nowIso(); } });
        return fail(rp.error, 502);
      }
      await mutate((db) => { const o = db.orders.find((x) => x.id === result.id); if (o) o.razorpayOrderId = rp.id; });
      return json({ ok: true, orderId: result.id, ref: result.ref, mode, razorpayOrderId: rp.id, amount: result.total, keyId: process.env.RAZORPAY_KEY_ID });
    }
    return json({ ok: true, orderId: result.id, ref: result.ref, mode, amount: result.total });
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'Could not place the order.', 409);
  }
}
