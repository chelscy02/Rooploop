import type { Metadata } from 'next';
import { PolicyPage } from '@/components/Prose';
export const metadata: Metadata = { title: 'Rental Policy' };
export default function Page() {
  return (
    <PolicyPage title="Rental Policy" intro="Placeholder structure. Fees, deposits and penalties are to be confirmed by ROOPLOOP.">
      <div><h2>Booking</h2><p>A booking request holds your dates for a limited time while we review it. A booking is confirmed only once we confirm it. Overlapping bookings for the same garment are not accepted.</p></div>
      <div><h2>Return</h2><p>The outfit is due back on the end date of your booking. Delivery and return arrangements are to be confirmed.</p></div>
      <div><h2>Late returns</h2><p>Late-return charges: to be confirmed.</p></div>
      <div><h2>Damage</h2><p>Damage assessment and charges: to be confirmed.</p></div>
      <div><h2>Deposit</h2><p>Security deposit amount, collection and refund timing: to be confirmed. Online deposit handling is not enabled yet.</p></div>
    </PolicyPage>
  );
}
