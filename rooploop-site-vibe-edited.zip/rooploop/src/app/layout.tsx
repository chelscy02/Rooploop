import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Providers } from '@/components/Providers';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Logo } from '@/components/Logo';
import { getUser } from '@/lib/auth';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'),
  title: { default: 'ROOPLOOP | A Circular Fashion House', template: '%s | ROOPLOOP' },
  description: 'Old stories. New forms. Rework your wardrobe, shop one-of-a-kind redesigned pieces, rent the look, and give clothing another life.',
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#581E2A' };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Manrope:wght@400;500;600;700&display=swap"
        />
      </head>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:bg-maroon focus:px-4 focus:py-2 focus:text-ivory">Skip to content</a>
        <Providers>
          <div className="bg-maroon text-ivory text-center py-2.5 px-4 label on-dark" role="note">
            Old stories. New forms. <span aria-hidden="true">—</span> A circular fashion house
          </div>
          <Header logo={<Logo />} signedIn={!!user} isAdmin={user?.role === 'admin'} />
          <main id="main">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
