import type { Metadata } from 'next';
import { ServiceForm, type FieldDef } from '@/components/ServiceForm';
import { getUser } from '@/lib/auth';

export const metadata: Metadata = { title: 'Rework My Wardrobe', description: 'Submit a garment you own and receive a custom redesign quotation from ROOPLOOP.' };
export const dynamic = 'force-dynamic';

const fields: FieldDef[] = [
  { name: 'fullName', label: 'Full name', required: true },
  { name: 'email', label: 'Email', type: 'email', required: true },
  { name: 'phone', label: 'Phone number', type: 'tel', required: true },
  { name: 'category', label: 'Garment category', type: 'select', required: true, options: ['Saree', 'Lehenga', 'Kurta / Kurti', 'Shirt', 'Denim', 'Dress', 'Jacket / Outerwear', 'Trousers / Skirt', 'Dupatta / Textile', 'Other'] },
  { name: 'condition', label: 'Garment condition', type: 'select', required: true, options: ['Like new', 'Good, lightly worn', 'Worn, some wear', 'Damaged or stained'] },
  { name: 'budget', label: 'Budget range', type: 'select', required: true, options: ['Under ₹3,000', '₹3,000 to ₹6,000', '₹6,000 to ₹12,000', 'Above ₹12,000', 'Not sure yet'], hint: 'Guidance only. Final pricing is a quotation.' },
  { name: 'transformation', label: 'Desired transformation', type: 'textarea', required: true, placeholder: 'What would you like this garment to become?' },
  { name: 'stylePreferences', label: 'Style preferences', type: 'textarea' },
  { name: 'colourPreferences', label: 'Colour preferences' },
  { name: 'fulfilment', label: 'Shipping or pickup preference', type: 'select', options: ['I will ship it to ROOPLOOP', 'I would like to arrange pickup', 'I will drop it off', 'Undecided'], hint: 'Options available will be confirmed in your quotation.' },
  { name: 'instructions', label: 'Additional instructions', type: 'textarea' },
];

export default async function Rework() {
  const user = await getUser();
  return (
    <div className="container-x py-12 sm:py-20">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr] lg:gap-20">
        <div>
          <p className="label text-maroon">Your clothes. Our creativity.</p>
          <h1 className="mt-3 text-5xl sm:text-6xl">Rework my wardrobe</h1>
          <p className="mt-5 text-charcoal/90">Tell us about a garment you already own and what you would like it to become. We review your photos and send a quotation with a proposed design, price and timeline.</p>
          <ol className="mt-8 space-y-3 text-[0.95rem]">
            {['Submit photos and your idea', 'We review and send a quotation', 'You accept or decline', 'Production starts only after you accept'].map((s, i) => (
              <li key={s} className="flex gap-3"><span className="font-serif text-2xl text-gold leading-none">{i + 1}</span><span>{s}</span></li>
            ))}
          </ol>
          <p className="mt-6 text-[0.9rem] text-charcoal/80">You are not charged when you submit.</p>
        </div>
        <ServiceForm
          endpoint="/api/rework" fields={fields} signedIn={!!user} loginNext="/rework"
          defaults={{ fullName: user?.name ?? '', email: user?.email ?? '', phone: user?.phone ?? '' }}
          photoLabel="Garment photos" submitLabel="Submit rework request"
          success={{ title: 'Request received', body: 'We will review your garment and send a quotation. You can follow its status in your account. Email notifications are not yet connected, so please check your dashboard.', dashboard: '/account/reworks', dashboardLabel: 'View my reworks' }}
        />
      </div>
    </div>
  );
}
