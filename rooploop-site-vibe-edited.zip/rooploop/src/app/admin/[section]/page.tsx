import { notFound } from 'next/navigation';
import { readDb, reworkStatuses, giveBackStatuses, giveBackOutcomes, orderStatuses, bookingStatuses } from '@/lib/db';
import { AdminForm } from '@/components/AdminForm';
import { ProductImageUpload } from '@/components/ProductImageUpload';
import { productCategories } from '@/data/products';
import { fmtDate, inr } from '@/lib/format';
import { unitFree } from '@/lib/rentals';

export const dynamic = 'force-dynamic';
const Badge = ({ children }: { children: React.ReactNode }) => <span className="inline-block bg-sand px-3 py-1 label">{children}</span>;
const Card = ({ children }: { children: React.ReactNode }) => <article className="border border-sand p-5">{children}</article>;
const Photos = ({ ids }: { ids: string[] }) => (
  <ul className="mt-3 flex flex-wrap gap-2">{ids.map((f, i) => <li key={f}><a href={`/api/files/${f}`} target="_blank" rel="noreferrer">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={`/api/files/${f}`} alt={`Customer photo ${i + 1}`} className="h-24 w-24 object-cover" /></a></li>)}</ul>
);

export default async function AdminSection({ params, searchParams }: { params: Promise<{ section: string }>; searchParams: Promise<{ q?: string }> }) {
  const { section } = await params;
  const q = ((await searchParams).q ?? '').toLowerCase();
  const db = readDb();
  const userName = (id: string) => db.users.find((u) => u.id === id)?.email ?? 'unknown';

  if (section === 'orders') {
    const rows = db.orders.filter((o) => !q || `${o.ref} ${o.name} ${o.email}`.toLowerCase().includes(q)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">Orders</h2>
        <form className="flex gap-3" role="search"><label className="sr-only" htmlFor="oq">Search orders</label><input id="oq" name="q" defaultValue={q} className="field max-w-sm" placeholder="Ref, name or email" /><button className="btn-primary">Search</button></form>
        {rows.length === 0 && <p>No orders.</p>}
        {rows.map((o) => (
          <Card key={o.id}>
            <div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{o.ref} · {o.name}</p><Badge>{o.status}</Badge></div>
            <p className="text-[0.9rem]">{o.email} · {o.phone} · {fmtDate(o.createdAt)} · {o.paymentMode === 'test' ? 'TEST (no payment)' : 'Razorpay'}{o.draftCatalogue && ' · draft catalogue'}</p>
            <p className="mt-1 text-[0.9rem] whitespace-pre-line">{o.address}</p>
            <ul className="mt-2 text-[0.95rem]">{o.items.map((i) => <li key={i.productId + i.size}>{i.name} ({i.size}) × {i.qty}</li>)}</ul>
            <p className="mt-2 font-medium">{inr(o.total)}</p>
            <div className="mt-4"><AdminForm action="order.status" id={o.id} submit="Update status" fields={[{ name: 'status', label: 'Status', type: 'select', options: orderStatuses, value: o.status }]} /></div>
          </Card>))}
      </div>
    );
  }

  if (section === 'products') {
    const fieldsFor = (p?: (typeof db.products)[number]) => [
      { name: 'name', label: 'Name', value: p?.name ?? '' },
      { name: 'category', label: 'Category', type: 'select' as const, options: productCategories, value: p?.category ?? productCategories[0] },
      { name: 'colour', label: 'Colour', value: p?.colour ?? '' },
      { name: 'price', label: 'Price (INR, blank = not confirmed)', type: 'number' as const, value: p?.price ?? '' },
      { name: 'sizes', label: 'Sizes and stock', value: p ? p.sizes.map((s) => `${s}:${p.stock[s] ?? 0}`).join(', ') : '', hint: 'Format: S:2, M:1, L:0', wide: true },
      { name: 'status', label: 'Status', type: 'select' as const, options: ['available', 'sold_out', 'archived'], value: p?.status ?? 'available' },
      { name: 'description', label: 'Description', type: 'textarea' as const, value: p?.description ?? '' },
      { name: 'materials', label: 'Materials', value: p?.materials ?? '' },
      { name: 'craftNotes', label: 'Craft notes', value: p?.craftNotes ?? '' },
      { name: 'care', label: 'Care instructions', value: p?.care ?? '', wide: true },
      { name: 'featured', label: 'Featured on homepage', type: 'checkbox' as const, value: p?.featured ?? false },
      { name: 'draft', label: 'Draft / sample listing (shows a DRAFT badge)', type: 'checkbox' as const, value: p?.draft ?? true },
    ];
    return (
      <div className="space-y-5"><h2 className="text-3xl">Products</h2>
        <details className="border border-maroon p-5"><summary className="label cursor-pointer text-maroon">Add product</summary><div className="mt-5"><AdminForm action="product.save" submit="Create product" fields={fieldsFor()} /></div></details>
        {db.products.map((p) => (
          <Card key={p.id}>
            <div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{p.name}</p><Badge>{p.status}</Badge></div>
            <p className="text-[0.9rem]">{p.category} · {inr(p.price)} · stock {p.sizes.map((s) => `${s}:${p.stock[s] ?? 0}`).join(' ')}{p.draft && ' · DRAFT'}</p>
            <details className="mt-3"><summary className="label cursor-pointer text-maroon">Edit</summary><div className="mt-4 space-y-5"><AdminForm action="product.save" id={p.id} fields={fieldsFor(p)} />
              <div><p className="field-label">Images</p><ProductImageUpload id={p.id} /><p className="mt-2 text-[0.8rem]">Uploaded images replace the manifest images for this product.</p></div>
              <AdminForm action="product.archive" id={p.id} submit={p.status === 'archived' ? 'Restore' : 'Archive'} danger fields={[{ name: 'restore', label: 'Restore (untick to archive)', type: 'checkbox', value: p.status === 'archived' }]} /></div></details>
          </Card>))}
      </div>
    );
  }

  if (section === 'reworks') {
    const rows = [...db.reworks].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">Rework requests</h2>{rows.length === 0 && <p>No requests.</p>}
        {rows.map((r) => (
          <Card key={r.id}>
            <div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{r.ref} · {r.fullName} · {r.category}</p><Badge>{r.status}</Badge></div>
            <p className="text-[0.9rem]">{r.email} · {r.phone} · account {userName(r.userId)} · {fmtDate(r.createdAt)}</p>
            <dl className="mt-3 grid gap-1 text-[0.9rem] sm:grid-cols-[150px_1fr]">
              {([['Condition', r.condition], ['Transformation', r.transformation], ['Style', r.stylePreferences], ['Colours', r.colourPreferences], ['Budget', r.budget], ['Fulfilment', r.fulfilment], ['Instructions', r.instructions]] as [string, string][]).map(([k, v]) => <div key={k} className="contents"><dt className="label">{k}</dt><dd>{v || '-'}</dd></div>)}
            </dl>
            <Photos ids={r.fileIds} />
            {r.quote && <p className="mt-3 bg-sand/50 p-3 text-[0.9rem]">Quote sent {fmtDate(r.quote.sentAt)}: {inr(r.quote.price)}, {r.quote.timeline}. Customer response: <strong>{r.quote.customerResponse}</strong></p>}
            <details className="mt-4"><summary className="label cursor-pointer text-maroon">Review, quote and status</summary>
              <div className="mt-4"><AdminForm action="rework.update" id={r.id} fields={[
                { name: 'design', label: 'Proposed design', type: 'textarea', value: r.quote?.design ?? '' },
                { name: 'price', label: 'Quoted price (INR)', type: 'number', value: r.quote?.price ?? '' },
                { name: 'timeline', label: 'Estimated timeline', value: r.quote?.timeline ?? '' },
                { name: 'quoteNotes', label: 'Notes to customer', type: 'textarea', value: r.quote?.notes ?? '' },
                { name: 'status', label: 'Status', type: 'select', options: reworkStatuses, value: r.status },
                { name: 'adminNotes', label: 'Internal notes', type: 'textarea', value: r.adminNotes },
              ]} submit="Save" /></div>
              {r.status === 'Quote Sent' && r.quote?.customerResponse === 'pending' && <div className="mt-4"><AdminForm action="rework.recordApproval" id={r.id} submit="Record customer approval (given offline)" fields={[]} /></div>}
            </details>
          </Card>))}
      </div>
    );
  }

  if (section === 'rentals') {
    const rows = [...db.bookings].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-8">
        <div className="space-y-5"><h2 className="text-3xl">Rental bookings</h2>{rows.length === 0 && <p>No bookings.</p>}
          {rows.map((k) => {
            const free = unitFree(db.bookings, k.unitId, k.start, k.end, k.id);
            return (
              <Card key={k.id}>
                <div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{k.ref} · {k.itemName} ({k.size}) · unit {k.unitId}</p><Badge>{k.status}</Badge></div>
                <p className="text-[0.9rem]">{userName(k.userId)} · {fmtDate(k.start)} to {fmtDate(k.end)} · {inr(k.fee)} + {inr(k.deposit)} deposit ({k.depositStatus})</p>
                <p className={`mt-1 text-[0.9rem] ${free ? '' : 'text-[#8a1c1c] font-semibold'}`}>{free ? 'No conflicts with other active bookings.' : 'CONFLICT: overlaps another active booking for this garment.'}</p>
                <details className="mt-3"><summary className="label cursor-pointer text-maroon">Update</summary><div className="mt-4"><AdminForm action="booking.update" id={k.id} fields={[
                  { name: 'status', label: 'Status', type: 'select', options: bookingStatuses, value: k.status },
                  { name: 'depositStatus', label: 'Deposit status', type: 'select', options: ['Not collected (payments disabled)', 'Held', 'Refunded', 'Partially retained', 'Retained'], value: k.depositStatus },
                  { name: 'adminNotes', label: 'Internal notes', type: 'textarea', value: k.adminNotes },
                ]} /></div></details>
              </Card>);
          })}
        </div>
        <div className="space-y-5"><h2 className="text-3xl">Rental inventory</h2>
          {db.rentals.map((r) => (
            <Card key={r.id}><p className="font-semibold">{r.name}</p><p className="text-[0.9rem]">{r.units.length} unit(s): {r.units.map((u) => u.size).join(', ')}</p>
              <details className="mt-3"><summary className="label cursor-pointer text-maroon">Edit</summary><div className="mt-4"><AdminForm action="rental.save" id={r.id} fields={[
                { name: 'name', label: 'Name', value: r.name }, { name: 'fee', label: 'Rental fee (INR)', type: 'number', value: r.fee }, { name: 'deposit', label: 'Deposit (INR)', type: 'number', value: r.deposit },
                { name: 'description', label: 'Description', type: 'textarea', value: r.description },
                { name: 'draft', label: 'Draft / sample listing', type: 'checkbox', value: r.draft }, { name: 'archived', label: 'Archived (hidden from site)', type: 'checkbox', value: r.status === 'archived' },
              ]} /></div></details></Card>))}
        </div>
      </div>
    );
  }

  if (section === 'give-back') {
    const rows = [...db.giveBacks].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">Give Back submissions</h2>{rows.length === 0 && <p>No submissions.</p>}
        {rows.map((g) => (
          <Card key={g.id}>
            <div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{g.ref} · {g.fullName} · {g.count} item(s)</p><Badge>{g.status}</Badge></div>
            <p className="text-[0.9rem]">{g.email} · {g.phone} · {g.category} · {g.logistics} · preference: {g.preference || 'none'}</p>
            <p className="mt-1 text-[0.9rem]">Condition: {g.condition}</p>{g.address && <p className="text-[0.9rem] whitespace-pre-line">Address: {g.address}</p>}{g.notes && <p className="text-[0.9rem]">Notes: {g.notes}</p>}
            <Photos ids={g.fileIds} />
            <details className="mt-3"><summary className="label cursor-pointer text-maroon">Assess and update</summary><div className="mt-4"><AdminForm action="giveback.update" id={g.id} fields={[
              { name: 'status', label: 'Status', type: 'select', options: giveBackStatuses, value: g.status },
              { name: 'outcome', label: 'Assessment outcome', type: 'select', options: [...giveBackOutcomes], value: g.outcome },
              { name: 'adminNotes', label: 'Internal notes', type: 'textarea', value: g.adminNotes },
            ]} /></div></details>
          </Card>))}
      </div>
    );
  }

  if (section === 'enquiries') {
    const rows = [...db.enquiries].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <div className="space-y-5"><h2 className="text-3xl">Enquiries</h2>{rows.length === 0 && <p>No enquiries.</p>}
        {rows.map((e) => (
          <Card key={e.id}><div className="flex flex-wrap justify-between gap-3"><p className="font-semibold">{e.name} · {e.email}</p><Badge>{e.handled ? 'Handled' : 'New'}</Badge></div>
            <p className="text-[0.85rem]">{fmtDate(e.createdAt)}</p><p className="mt-2 whitespace-pre-line">{e.message}</p>
            <div className="mt-3"><AdminForm action="enquiry.handled" id={e.id} submit="Save" fields={[{ name: 'handled', label: 'Handled', type: 'checkbox', value: e.handled }]} /></div></Card>))}
        <h2 className="pt-6 text-3xl">Newsletter subscribers ({db.subscribers.length})</h2>
        <ul className="text-[0.95rem]">{db.subscribers.map((s) => <li key={s.id}>{s.email} · {fmtDate(s.createdAt)}</li>)}</ul>
      </div>
    );
  }
  notFound();
}
