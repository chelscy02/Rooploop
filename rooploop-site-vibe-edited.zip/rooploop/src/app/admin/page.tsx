import Link from 'next/link';
import { readDb } from '@/lib/db';
import { paymentsMode } from '@/lib/payments';

export const dynamic = 'force-dynamic';
export default function Overview() {
  const db = readDb();
  const cards: [string, string, number][] = [
    ['Orders', 'orders', db.orders.length],
    ['Rework requests to review', 'reworks', db.reworks.filter((r) => ['Submitted', 'Under Review'].includes(r.status)).length],
    ['Rental requests', 'rentals', db.bookings.filter((b) => b.status === 'Requested').length],
    ['Give Back to assess', 'give-back', db.giveBacks.filter((g) => ['Submitted', 'Under Assessment'].includes(g.status)).length],
    ['Unhandled enquiries', 'enquiries', db.enquiries.filter((e) => !e.handled).length],
    ['Newsletter subscribers', 'enquiries', db.subscribers.length],
  ];
  return (
    <div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map(([t, h, n]) => <Link key={t} href={`/admin/${h}`} className="border border-sand p-6 hover:bg-sand/40"><p className="font-serif text-5xl text-maroon">{n}</p><p className="label mt-2">{t}</p></Link>)}
      </div>
      <div className="mt-8 border border-sand bg-sand/40 p-5 text-[0.9rem] space-y-1">
        <p><strong>Data store:</strong> local development file (.data/db.json). Not a production database.</p>
        <p><strong>Payments mode:</strong> {paymentsMode()}</p>
        <p><strong>Email notifications:</strong> not connected. {db.outbox.length} message(s) queued, none sent.</p>
      </div>
    </div>
  );
}
