import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import type { ReactNode } from 'react';
import { getUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Admin', robots: { index: false, follow: false } };
const nav = [['', 'Overview'], ['orders', 'Orders'], ['products', 'Products'], ['reworks', 'Reworks'], ['rentals', 'Rentals'], ['give-back', 'Give Back'], ['enquiries', 'Enquiries']] as const;

export default async function AdminLayout({ children }: { children: ReactNode }) {
  // Server-side gate: no admin markup or data is rendered for anyone else.
  const user = await getUser();
  if (!user) redirect('/account/login?next=/admin');
  if (user.role !== 'admin') notFound();
  return (
    <div className="container-x py-10">
      <p className="label text-maroon">Admin</p>
      <h1 className="mt-2 text-4xl">ROOPLOOP dashboard</h1>
      <nav aria-label="Admin" className="mt-6 flex flex-wrap gap-2 border-b border-sand pb-4">
        {nav.map(([s, l]) => <Link key={s} href={`/admin${s ? '/' + s : ''}`} className="label border border-sand px-4 py-2.5 hover:bg-sand/60">{l}</Link>)}
      </nav>
      <div className="mt-8">{children}</div>
    </div>
  );
}
