'use client';
import { useShop } from './Providers';

export function WishlistButton({ slug, name, className = '' }: { slug: string; name: string; className?: string }) {
  const { wishlist, toggleWish } = useShop();
  const on = wishlist.includes(slug);
  return (
    <button
      type="button"
      onClick={() => toggleWish(slug)}
      aria-pressed={on}
      aria-label={on ? `Remove ${name} from wishlist` : `Save ${name} to wishlist`}
      className={`grid h-10 w-10 place-items-center bg-ivory/90 text-maroon hover:bg-ivory ${className}`}
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill={on ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
        <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" />
      </svg>
    </button>
  );
}
