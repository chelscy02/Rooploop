import Image from 'next/image';
import Link from 'next/link';
import { getImage } from '@/lib/images';

/**
 * The supplied logo is a photographed wordmark on paper. It is shown unedited,
 * blended onto the page with CSS multiply so the paper tone does not form a box.
 * Swap in a transparent PNG/SVG by changing the 'logo-primary' entry in siteImages.ts.
 */
export function Logo({ className = '', plate = false }: { className?: string; plate?: boolean }) {
  const img = getImage('logo-primary');
  return (
    <Link href="/" aria-label="ROOPLOOP, a circular fashion house. Home" className={`inline-block ${className}`}>
      {img.src ? (
        <span className={plate ? 'block bg-[#E1D5C7] p-2' : 'block'}>
          <Image
            src={img.src}
            alt={img.alt}
            width={1300}
            height={590}
            priority
            style={{ mixBlendMode: plate ? 'normal' : 'multiply', height: 'auto', width: '100%' }}
          />
        </span>
      ) : (
        <span className="label text-maroon">ROOPLOOP logo slot</span>
      )}
    </Link>
  );
}
