'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useShop } from './Providers';

const NAV = [
  { href: '/', label: 'Home' },
  { href: '/rework', label: 'Rework' },
  { href: '/shop', label: 'Shop' },
  { href: '/rent', label: 'Rent' },
  { href: '/give-back', label: 'Give Back' },
  { href: '/our-story', label: 'Our Story' },
];

const icon = 'h-[22px] w-[22px]';
const Svg = ({ children }: { children: React.ReactNode }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={icon} aria-hidden="true">{children}</svg>
);

export function Header({ logo, signedIn, isAdmin }: { logo: React.ReactNode; signedIn: boolean; isAdmin: boolean }) {
  const path = usePathname();
  const router = useRouter();
  const { count, wishlist } = useShop();
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [q, setQ] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setOpen(false); setSearching(false); }, [path]);
  useEffect(() => { if (searching) searchRef.current?.focus(); }, [searching]);
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(false); setSearching(false); } };
    window.addEventListener('keydown', onKey);
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open]);

  const active = (href: string) => (href === '/' ? path === '/' : path.startsWith(href));
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    router.push(term ? `/shop?q=${encodeURIComponent(term)}` : '/shop');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-sand bg-ivory/95 backdrop-blur">
      <div className="container-x flex items-center justify-between gap-4 py-2.5">
        <button className="lg:hidden -ml-2 p-2 text-maroon" aria-label="Open menu" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(true)}>
          <Svg><path d="M3 7h18M3 12h18M3 17h18" /></Svg>
        </button>

        <div className="w-[130px] sm:w-[170px] lg:w-[190px] shrink-0">{logo}</div>

        <nav aria-label="Primary" className="hidden lg:flex items-center gap-9">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} aria-current={active(n.href) ? 'page' : undefined}
              className={`label py-2 border-b transition-colors ${active(n.href) ? 'border-maroon text-maroon' : 'border-transparent text-charcoal hover:text-maroon hover:border-gold'}`}>
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-0.5 sm:gap-2 text-maroon">
          <button className="p-2" aria-label="Search" aria-expanded={searching} onClick={() => setSearching((s) => !s)}>
            <Svg><circle cx="11" cy="11" r="6.5" /><path d="m20 20-4.2-4.2" /></Svg>
          </button>
          <Link className="p-2 hidden sm:block" href={signedIn ? (isAdmin ? '/admin' : '/account') : '/account/login'} aria-label={signedIn ? 'My account' : 'Sign in'}>
            <Svg><circle cx="12" cy="8" r="4" /><path d="M4 20c1.2-3.6 4.2-5.5 8-5.5s6.8 1.9 8 5.5" /></Svg>
          </Link>
          <Link className="p-2 relative" href="/wishlist" aria-label={`Wishlist, ${wishlist.length} saved`}>
            <Svg><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" /></Svg>
            {wishlist.length > 0 && <span className="absolute top-0.5 right-0 grid h-4 min-w-4 place-items-center bg-maroon px-1 text-[10px] text-ivory">{wishlist.length}</span>}
          </Link>
          <Link className="p-2 relative" href="/cart" aria-label={`Shopping bag, ${count} items`}>
            <Svg><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" /></Svg>
            {count > 0 && <span className="absolute top-0.5 right-0 grid h-4 min-w-4 place-items-center bg-maroon px-1 text-[10px] text-ivory">{count}</span>}
          </Link>
        </div>
      </div>

      {searching && (
        <form role="search" onSubmit={submit} className="border-t border-sand bg-ivory">
          <div className="container-x flex items-center gap-3 py-3">
            <label htmlFor="site-search" className="sr-only">Search the shop</label>
            <input id="site-search" ref={searchRef} value={q} onChange={(e) => setQ(e.target.value)} className="field" placeholder="Search pieces, categories, colours" />
            <button className="btn-primary shrink-0" type="submit">Search</button>
          </div>
        </form>
      )}

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" id="mobile-menu" role="dialog" aria-modal="true" aria-label="Menu">
          <button className="absolute inset-0 bg-charcoal/50" aria-label="Close menu" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 flex h-full w-[84%] max-w-[360px] flex-col bg-ivory p-6 overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="w-[150px]">{logo}</div>
              <button className="p-2 -mr-2 text-maroon" aria-label="Close menu" onClick={() => setOpen(false)}>
                <Svg><path d="M5 5l14 14M19 5 5 19" /></Svg>
              </button>
            </div>
            <nav aria-label="Mobile" className="mt-8 flex flex-col">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href} className="font-serif text-3xl text-maroon py-3 border-b border-sand" aria-current={active(n.href) ? 'page' : undefined}>{n.label}</Link>
              ))}
            </nav>
            <div className="mt-8 flex flex-col gap-3">
              <Link className="btn-outline" href={signedIn ? (isAdmin ? '/admin' : '/account') : '/account/login'}>{signedIn ? 'My account' : 'Sign in / Register'}</Link>
              <Link className="btn-outline" href="/wishlist">Wishlist ({wishlist.length})</Link>
              <Link className="btn-primary" href="/cart">Shopping bag ({count})</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
