'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';

export interface FieldDef {
  name: string; label: string; type?: 'text' | 'email' | 'tel' | 'number' | 'select' | 'textarea'; options?: string[];
  required?: boolean; hint?: string; placeholder?: string; wide?: boolean; min?: number; max?: number;
}
const MAX_BYTES = 8 * 1024 * 1024, MAX_FILES = 6, OK = ['image/jpeg', 'image/png', 'image/webp'];

export function ServiceForm({ endpoint, fields, defaults, signedIn, loginNext, photoLabel, submitLabel, success }: {
  endpoint: string; fields: FieldDef[]; defaults: Record<string, string>; signedIn: boolean; loginNext: string;
  photoLabel: string; submitLabel: string; success: { title: string; body: string; dashboard: string; dashboardLabel: string };
}) {
  const [files, setFiles] = useState<File[]>([]);
  const [fileErr, setFileErr] = useState('');
  const [fe, setFe] = useState<Record<string, string>>({});
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const previews = useMemo(() => files.map((f) => URL.createObjectURL(f)), [files]);
  useEffect(() => () => previews.forEach((u) => URL.revokeObjectURL(u)), [previews]);

  function pick(list: FileList | null) {
    if (!list) return;
    const next = [...files];
    let e = '';
    for (const f of Array.from(list)) {
      if (!OK.includes(f.type)) { e = `"${f.name}" is not a JPG, PNG or WebP image.`; continue; }
      if (f.size > MAX_BYTES) { e = `"${f.name}" is larger than 8 MB.`; continue; }
      if (next.length >= MAX_FILES) { e = `You can upload up to ${MAX_FILES} photos.`; break; }
      next.push(f);
    }
    setFiles(next); setFileErr(e);
    if (inputRef.current) inputRef.current.value = '';
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    setErr(''); setFe({});
    const form = new FormData(e.currentTarget);
    const local: Record<string, string> = {};
    for (const f of fields) if (f.required && !String(form.get(f.name) ?? '').trim()) local[f.name] = 'This field is required.';
    if (files.length === 0) setFileErr('Please upload at least one photo.');
    if (Object.keys(local).length || files.length === 0) { setFe(local); setErr('Please complete the highlighted fields.'); return; }
    form.delete('photos');
    files.forEach((f) => form.append('photos', f));
    setBusy(true);
    try {
      const r = await fetch(endpoint, { method: 'POST', body: form });
      const d = await r.json();
      if (!r.ok) { setErr(d.error ?? 'Submission failed.'); setFe(d.fields ?? {}); if (d.fileError) setFileErr(d.fileError); setBusy(false); return; }
      setDone(d.ref); setBusy(false);
    } catch {
      setErr('Could not reach the server. Your details were not submitted. Please try again.'); setBusy(false);
    }
  }

  if (done) return (
    <div role="status" className="border border-sand bg-sand/40 p-8">
      <h2 className="text-4xl">{success.title}</h2>
      <p className="mt-4">Your reference: <strong className="tracking-wider">{done}</strong></p>
      <p className="mt-2 max-w-lg">{success.body}</p>
      <Link href={success.dashboard} className="btn-primary mt-6">{success.dashboardLabel}</Link>
    </div>
  );

  return (
    <form onSubmit={submit} noValidate encType="multipart/form-data" className="space-y-6">
      {!signedIn && (
        <div role="note" className="border border-maroon bg-sand/50 p-4 text-[0.95rem]">
          Please <Link href={`/account/login?next=${encodeURIComponent(loginNext)}`} className="underline font-semibold">sign in or create an account</Link> before submitting, so you can track your request.
        </div>
      )}
      <div className="grid gap-6 sm:grid-cols-2">
        {fields.map((f) => {
          const id = `f-${f.name}`;
          const common = { id, name: f.name, defaultValue: defaults[f.name] ?? '', className: 'field', 'aria-invalid': !!fe[f.name], 'aria-describedby': fe[f.name] ? `${id}-e` : f.hint ? `${id}-h` : undefined } as const;
          return (
            <div key={f.name} className={f.wide || f.type === 'textarea' ? 'sm:col-span-2' : ''}>
              <label htmlFor={id} className="field-label">{f.label}{f.required && <span aria-hidden="true"> *</span>}</label>
              {f.type === 'select' ? (
                <select {...common} required={f.required}><option value="">Select…</option>{f.options?.map((o) => <option key={o}>{o}</option>)}</select>
              ) : f.type === 'textarea' ? (
                <textarea {...common} rows={4} placeholder={f.placeholder} required={f.required} />
              ) : (
                <input {...common} type={f.type ?? 'text'} min={f.min} max={f.max} placeholder={f.placeholder} required={f.required} />
              )}
              {f.hint && !fe[f.name] && <p id={`${id}-h`} className="mt-1.5 text-[0.82rem] text-charcoal/75">{f.hint}</p>}
              {fe[f.name] && <p id={`${id}-e`} className="field-error">{fe[f.name]}</p>}
            </div>
          );
        })}
      </div>

      <div>
        <label htmlFor="photos" className="field-label">{photoLabel} *</label>
        <input ref={inputRef} id="photos" type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => pick(e.target.files)} className="field file:mr-4 file:border-0 file:bg-maroon file:px-4 file:py-2 file:text-ivory file:uppercase file:text-xs" aria-describedby="photos-h" />
        <p id="photos-h" className="mt-1.5 text-[0.82rem] text-charcoal/75">Up to 6 photos. JPG, PNG or WebP, 8 MB each. Clear, well-lit photos help.</p>
        {fileErr && <p role="alert" className="field-error">{fileErr}</p>}
        {files.length > 0 && (
          <ul className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-6">
            {files.map((f, i) => (
              <li key={f.name + i} className="relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={previews[i]} alt={`Selected photo ${i + 1}: ${f.name}`} className="aspect-square w-full object-cover" />
                <button type="button" aria-label={`Remove ${f.name}`} onClick={() => setFiles(files.filter((_, j) => j !== i))} className="absolute right-1 top-1 grid h-7 w-7 place-items-center bg-ivory text-maroon">×</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {err && <p role="alert" className="field-error">{err}</p>}
      <button className="btn-primary w-full sm:w-auto" type="submit" disabled={busy || !signedIn}>{busy ? 'Submitting…' : submitLabel}</button>
    </form>
  );
}
