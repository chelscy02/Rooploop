'use client';
import { useState } from 'react';

export function NewsletterForm({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  const [email, setEmail] = useState('');
  const [state, setState] = useState<'idle' | 'busy' | 'ok' | 'error'>('idle');
  const [msg, setMsg] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState('busy'); setMsg('');
    try {
      const r = await fetch('/api/newsletter', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) });
      const d = await r.json();
      if (!r.ok || !d.ok) { setState('error'); setMsg(d.error ?? 'Something went wrong. Please try again.'); return; }
      setState('ok'); setMsg(d.message); setEmail('');
    } catch {
      setState('error'); setMsg('Could not reach the server. Please try again.');
    }
  }
  const dark = tone === 'dark';
  return (
    <form onSubmit={submit} noValidate aria-label="Newsletter signup">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <label htmlFor={`nl-${tone}`} className="sr-only">Email address</label>
          <input id={`nl-${tone}`} type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address" className="field" aria-invalid={state === 'error'} aria-describedby={`nl-msg-${tone}`} />
        </div>
        <button disabled={state === 'busy'} className={dark ? 'btn-light' : 'btn-primary'} type="submit">{state === 'busy' ? 'Joining…' : 'Subscribe'}</button>
      </div>
      <p id={`nl-msg-${tone}`} role="status" aria-live="polite" className={`mt-2 text-[0.85rem] min-h-[1.25rem] ${state === 'error' ? (dark ? 'text-[#ffd0d0]' : 'text-[#8a1c1c]') : dark ? 'text-ivory' : 'text-maroon'}`}>{msg}</p>
    </form>
  );
}
