'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export interface AField { name: string; label: string; type?: 'text' | 'number' | 'select' | 'textarea' | 'checkbox'; options?: string[]; value?: string | boolean | number | null; wide?: boolean; hint?: string }

export function AdminForm({ action, id, fields, submit = 'Save', danger, reload = true }: {
  action: string; id?: string; fields: AField[]; submit?: string; danger?: boolean; reload?: boolean;
}) {
  const router = useRouter();
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [busy, setBusy] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    const fd = new FormData(e.currentTarget);
    const body: Record<string, unknown> = { action, id };
    for (const f of fields) body[f.name] = f.type === 'checkbox' ? fd.get(f.name) === 'on' : String(fd.get(f.name) ?? '');
    try {
      const r = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = await r.json();
      if (!r.ok) setMsg({ ok: false, t: d.error ?? 'Failed.' }); else { setMsg({ ok: true, t: 'Saved.' }); if (reload) router.refresh(); }
    } catch { setMsg({ ok: false, t: 'Could not reach the server.' }); }
    setBusy(false);
  }
  return (
    <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
      {fields.map((f) => {
        const k = `${action}-${id ?? 'new'}-${f.name}`;
        const wide = f.wide || f.type === 'textarea';
        return (
          <div key={f.name} className={wide ? 'sm:col-span-2' : ''}>
            {f.type === 'checkbox' ? (
              <label className="flex items-center gap-3 text-[0.95rem]"><input type="checkbox" name={f.name} defaultChecked={!!f.value} className="h-5 w-5 accent-[#581E2A]" />{f.label}</label>
            ) : (
              <>
                <label className="field-label" htmlFor={k}>{f.label}</label>
                {f.type === 'select' ? <select id={k} name={f.name} defaultValue={String(f.value ?? '')} className="field">{f.options?.map((o) => <option key={o}>{o}</option>)}</select>
                  : f.type === 'textarea' ? <textarea id={k} name={f.name} rows={3} defaultValue={String(f.value ?? '')} className="field" />
                  : <input id={k} name={f.name} type={f.type === 'number' ? 'number' : 'text'} defaultValue={String(f.value ?? '')} className="field" />}
                {f.hint && <p className="mt-1 text-[0.8rem] text-charcoal/70">{f.hint}</p>}
              </>
            )}
          </div>
        );
      })}
      <div className="sm:col-span-2 flex flex-wrap items-center gap-4">
        <button className={danger ? 'btn-outline' : 'btn-primary'} disabled={busy} type="submit">{busy ? 'Saving…' : submit}</button>
        {msg && <p role={msg.ok ? 'status' : 'alert'} className={msg.ok ? 'text-maroon text-[0.9rem]' : 'field-error'}>{msg.t}</p>}
      </div>
    </form>
  );
}
