import Image from 'next/image';
import type { ResolvedImage } from '@/lib/images';

/**
 * Renders a supplied photograph without recolouring or filtering it.
 * fit="cover" crops to the slot using the manifest focal point.
 * fit="contain" shows the whole photo on a sand background (nothing cropped).
 * When a slot has no file, a clearly labelled empty slot is shown instead.
 */
export function Img({
  image, fit = 'cover', sizes = '(min-width: 1024px) 40vw, 90vw', priority = false, className = '', ratio,
}: {
  image: ResolvedImage; fit?: 'cover' | 'contain'; sizes?: string; priority?: boolean; className?: string; ratio?: string;
}) {
  const aspect = (ratio ?? image.aspect).replace('/', ' / ');
  if (!image.src) {
    return (
      <div
        role="img"
        aria-label={`Empty image slot: ${image.alt}`}
        style={{ aspectRatio: aspect }}
        className={`flex items-center justify-center border border-dashed border-charcoal/40 bg-sand p-4 text-center ${className}`}
      >
        <span className="label text-charcoal/70 break-words">Image slot<br />{image.slotLabel}</span>
      </div>
    );
  }
  return (
    <div style={{ aspectRatio: aspect }} className={`relative overflow-hidden bg-sand ${className}`}>
      <Image
        src={image.src}
        alt={image.alt}
        fill
        sizes={sizes}
        priority={priority}
        quality={90}
        style={{ objectFit: fit, objectPosition: image.focal }}
      />
    </div>
  );
}
