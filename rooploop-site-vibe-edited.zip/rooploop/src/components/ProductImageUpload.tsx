'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export function ProductImageUpload({ id }: { id: string }) {
  const router = useRouter();
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg('');
    const fd = new FormData(e.currentTarget); fd.set('id', id);
    try {
      const r = await fetch('/api/admin/upload', { method: 'POST', body: fd }); const d = await r.json();
      setMsg(r.ok ? `Uploaded ${d.saved.length} image(s).` : d.error ?? 'Upload failed.'); if (r.ok) router.refresh();
    } catch { setMsg('Could not reach the server.'); }
    setBusy(false);
  }
  return (
    <form onSubmit={onSubmit} className="flex flex-wrap items-center gap-3">
      <label className="sr-only" htmlFor={`up-${id}`}>Product images</label>
      <input id={`up-${id}`} name="images" type="file" accept="image/jpeg,image/png,image/webp" multiple className="field max-w-xs" />
      <button className="btn-outline" disabled={busy} type="submit">{busy ? 'Uploading…' : 'Upload images'}</button>
      {msg && <p role="status" className="text-[0.9rem]">{msg}</p>}
    </form>
  );
}
