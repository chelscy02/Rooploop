'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

/** POSTs JSON to an endpoint then refreshes server data. Shows the server's error text. */
export function ActionButton({ url, body, label, busyLabel = 'Working…', variant = 'outline', confirm }: {
  url: string; body?: Record<string, unknown>; label: string; busyLabel?: string; variant?: 'primary' | 'outline'; confirm?: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function go() {
    if (confirm && !window.confirm(confirm)) return;
    setBusy(true); setErr('');
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body ?? {}) });
      const d = await r.json();
      if (!r.ok) setErr(d.error ?? 'Failed.'); else router.refresh();
    } catch { setErr('Could not reach the server.'); }
    setBusy(false);
  }
  return (
    <span className="inline-flex flex-col items-start">
      <button type="button" onClick={go} disabled={busy} className={variant === 'primary' ? 'btn-primary' : 'btn-outline'}>{busy ? busyLabel : label}</button>
      {err && <span role="alert" className="field-error">{err}</span>}
    </span>
  );
}
