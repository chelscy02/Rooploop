import Link from 'next/link';
import { inr } from '@/lib/format';
import type { RentalItem } from '@/data/rentals';

export function RentalCard({ r }: { r: RentalItem }) {
  return (
    <article className="relative border-t border-sand pt-5">
      <p className="label text-charcoal/75">{r.occasion}</p>
      {r.draft && <span className="mt-3 inline-block bg-sand px-2 py-1 label text-charcoal">Draft listing</span>}
      <h3 className="mt-4 font-serif text-[1.55rem] leading-tight"><Link href={`/rent/${r.slug}`} className="hover:underline">{r.name}</Link></h3>
      <p className="mt-2 text-[0.95rem]">{inr(r.fee)} rental{r.draft && <span className="text-charcoal/70"> (draft)</span>} · {inr(r.deposit)} refundable deposit</p>
      <p className="mt-1 text-[0.85rem] text-charcoal/80">Sizes: {r.sizes.join(', ')}</p>
      <p className="mt-3 text-[0.9rem] text-charcoal/85">{r.description}</p>
      <Link href={`/rent/${r.slug}`} className="mt-4 inline-block label text-maroon border-b border-maroon pb-0.5">Check dates</Link>
    </article>
  );
}
