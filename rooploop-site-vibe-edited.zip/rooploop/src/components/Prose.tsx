import type { ReactNode } from 'react';

export function PolicyPage({ title, intro, children }: { title: string; intro?: string; children: ReactNode }) {
  return (
    <div className="container-x py-12 sm:py-20 max-w-3xl">
      <h1 className="text-5xl sm:text-6xl">{title}</h1>
      <p role="note" className="mt-6 border border-terracotta bg-sand/60 p-4 text-[0.9rem]">
        Draft content. ROOPLOOP has not yet confirmed these terms. Review and replace with the final business and legal wording before launch.
      </p>
      {intro && <p className="mt-6 text-charcoal/90">{intro}</p>}
      <div className="mt-8 space-y-8 [&_h2]:text-3xl [&_h2]:mb-2 [&_p]:text-charcoal/90 [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:space-y-1">{children}</div>
    </div>
  );
}
