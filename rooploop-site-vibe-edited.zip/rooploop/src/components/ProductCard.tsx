import Link from 'next/link';
import { WishlistButton } from './WishlistButton';
import { inr } from '@/lib/format';
import type { Product } from '@/data/products';
import { isAvailable } from '@/lib/catalog';

export function ProductCard({ p }: { p: Product }) {
  const avail = isAvailable(p);
  return (
    <article className="group relative border-t border-sand pt-5">
      <div className="flex items-start justify-between gap-3">
        <p className="label text-charcoal/75">{p.category}</p>
        <WishlistButton slug={p.slug} name={p.name} className="shrink-0" />
      </div>
      {p.draft && <span className="mt-3 inline-block bg-sand px-2 py-1 label text-charcoal">Draft listing</span>}
      <h3 className="mt-4 font-serif text-[1.55rem] leading-tight"><Link href={`/shop/${p.slug}`} className="hover:underline">{p.name}</Link></h3>
      <p className="mt-2 text-[0.95rem]">{inr(p.price)}{p.draft && <span className="text-charcoal/70"> (draft price)</span>}</p>
      <p className="mt-1 text-[0.85rem] text-charcoal/80">{avail ? `Sizes: ${p.sizes.filter((s) => (p.stock[s] ?? 0) > 0).join(', ')}` : 'Sold out'}</p>
      <p className="mt-3 text-[0.9rem] text-charcoal/85">{p.description}</p>
      <Link href={`/shop/${p.slug}`} className="mt-4 inline-block label text-maroon border-b border-maroon pb-0.5">{avail ? 'View and buy' : 'View details'}</Link>
    </article>
  );
}
