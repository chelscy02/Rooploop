'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export interface CartLine {
  productId: string; slug: string; name: string; size: string; qty: number; price: number | null; image: string | null; max: number;
}
interface Ctx {
  lines: CartLine[];
  count: number;
  subtotal: number;
  add: (l: Omit<CartLine, 'qty'>, qty?: number) => string | null;
  setQty: (productId: string, size: string, qty: number) => void;
  remove: (productId: string, size: string) => void;
  clear: () => void;
  wishlist: string[];
  toggleWish: (slug: string) => void;
  ready: boolean;
}
const C = createContext<Ctx | null>(null);
const CART_KEY = 'rooploop.cart.v1';
const WISH_KEY = 'rooploop.wishlist.v1';

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, v: unknown) {
  try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* storage unavailable */ }
}

export function Providers({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setLines(read<CartLine[]>(CART_KEY, []));
    setWishlist(read<string[]>(WISH_KEY, []));
    setReady(true);
  }, []);
  useEffect(() => { if (ready) write(CART_KEY, lines); }, [lines, ready]);
  useEffect(() => { if (ready) write(WISH_KEY, wishlist); }, [wishlist, ready]);

  const add = useCallback<Ctx['add']>((l, qty = 1) => {
    let err: string | null = null;
    setLines((cur) => {
      const i = cur.findIndex((x) => x.productId === l.productId && x.size === l.size);
      if (i >= 0) {
        const next = [...cur];
        const q = next[i].qty + qty;
        if (q > l.max) { err = `Only ${l.max} available in size ${l.size}.`; return cur; }
        next[i] = { ...next[i], qty: q, max: l.max };
        return next;
      }
      if (qty > l.max) { err = `Only ${l.max} available in size ${l.size}.`; return cur; }
      return [...cur, { ...l, qty }];
    });
    return err;
  }, []);
  const setQty = useCallback((productId: string, size: string, qty: number) =>
    setLines((cur) => cur.map((x) => x.productId === productId && x.size === size ? { ...x, qty: Math.max(1, Math.min(qty, x.max)) } : x)), []);
  const remove = useCallback((productId: string, size: string) =>
    setLines((cur) => cur.filter((x) => !(x.productId === productId && x.size === size))), []);
  const clear = useCallback(() => setLines([]), []);
  const toggleWish = useCallback((slug: string) =>
    setWishlist((cur) => cur.includes(slug) ? cur.filter((s) => s !== slug) : [...cur, slug]), []);

  const value = useMemo<Ctx>(() => ({
    lines, count: lines.reduce((n, l) => n + l.qty, 0),
    subtotal: lines.reduce((n, l) => n + (l.price ?? 0) * l.qty, 0),
    add, setQty, remove, clear, wishlist, toggleWish, ready,
  }), [lines, wishlist, add, setQty, remove, clear, toggleWish, ready]);
  return <C.Provider value={value}>{children}</C.Provider>;
}

export function useShop(): Ctx {
  const c = useContext(C);
  if (!c) throw new Error('useShop must be used inside Providers');
  return c;
}
