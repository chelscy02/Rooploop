import Link from 'next/link';
import { Logo } from './Logo';
import { NewsletterForm } from './NewsletterForm';

const cols = [
  { title: 'Explore', links: [['Rework', '/rework'], ['Shop', '/shop'], ['Rent', '/rent'], ['Give Back', '/give-back'], ['Our Story', '/our-story']] },
  { title: 'Help', links: [['Contact', '/contact'], ['FAQs', '/faqs'], ['Shipping and Returns', '/shipping-returns'], ['Rental Policy', '/rental-policy']] },
  { title: 'Legal', links: [['Privacy Policy', '/privacy'], ['Terms and Conditions', '/terms']] },
];

export function Footer() {
  return (
    <footer className="on-dark bg-maroon text-ivory">
      <div className="container-x py-14 sm:py-20 grid gap-12 lg:grid-cols-[1.2fr_2fr]">
        <div>
          <div className="w-[220px]"><Logo plate /></div>
          <p className="mt-6 max-w-sm text-[0.95rem] text-ivory/90">Old stories. New forms.</p>
          <div className="mt-8 max-w-sm">
            <p className="label text-ivory mb-3">Join the loop</p>
            <NewsletterForm tone="dark" />
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-10">
          {cols.map((c) => (
            <nav key={c.title} aria-label={c.title}>
              <p className="label text-ivory/80 mb-4">{c.title}</p>
              <ul className="space-y-3">
                {c.links.map(([l, h]) => (
                  <li key={h}><Link href={h} className="text-[0.95rem] text-ivory hover:underline">{l}</Link></li>
                ))}
              </ul>
            </nav>
          ))}
          <div className="col-span-2 sm:col-span-3 border-t border-ivory/25 pt-6">
            <p className="label text-ivory/80 mb-2">Social channels</p>
            <p className="text-[0.9rem] text-ivory/85">Links to be added once ROOPLOOP&apos;s social accounts are confirmed.</p>
          </div>
        </div>
      </div>
      <div className="border-t border-ivory/20">
        <div className="container-x py-5 text-[0.8rem] text-ivory/80">© {new Date().getFullYear()} ROOPLOOP. A Circular Fashion House.</div>
      </div>
    </footer>
  );
}
