'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useShop } from './Providers';
import { inr } from '@/lib/format';

export function AddToBag({ p }: { p: { id: string; slug: string; name: string; price: number | null; sizes: string[]; stock: Record<string, number>; available: boolean; image: string | null; draft: boolean } }) {
  const { add } = useShop();
  const [size, setSize] = useState<string>('');
  const [msg, setMsg] = useState<{ t: 'ok' | 'err'; s: string } | null>(null);
  const avail = size ? p.stock[size] ?? 0 : null;

  function onAdd() {
    if (!size) { setMsg({ t: 'err', s: 'Please select a size.' }); return; }
    const max = p.stock[size] ?? 0;
    if (max < 1) { setMsg({ t: 'err', s: `Size ${size} is sold out.` }); return; }
    const err = add({ productId: p.id, slug: p.slug, name: p.name, size, price: p.price, image: p.image, max });
    setMsg(err ? { t: 'err', s: err } : { t: 'ok', s: 'Added to your bag.' });
  }

  return (
    <div>
      <fieldset>
        <legend className="field-label">Size</legend>
        <div className="flex flex-wrap gap-2">
          {p.sizes.map((s) => {
            const out = (p.stock[s] ?? 0) < 1;
            return (
              <button key={s} type="button" disabled={out} aria-pressed={size === s} onClick={() => { setSize(s); setMsg(null); }}
                className={`min-w-[52px] border px-4 py-3 text-sm ${size === s ? 'border-maroon bg-maroon text-ivory' : 'border-charcoal/40 hover:border-maroon'} ${out ? 'opacity-40 line-through cursor-not-allowed' : ''}`}>
                {s}
              </button>
            );
          })}
        </div>
      </fieldset>
      <p className="mt-3 text-[0.9rem] text-charcoal/85" aria-live="polite">
        {avail === null ? 'Select a size to see availability.' : avail > 0 ? `${avail} available in size ${size}.` : `Size ${size} is sold out.`}
      </p>
      <button type="button" className="btn-primary mt-5 w-full sm:w-auto sm:min-w-[260px]" disabled={!p.available || p.price === null} onClick={onAdd}>
        {p.available ? `Add to bag${p.price !== null ? ' · ' + inr(p.price) : ''}` : 'Sold out'}
      </button>
      {p.price === null && <p className="mt-2 text-sm">Price to be confirmed. This piece cannot be bought yet.</p>}
      <p role="status" aria-live="polite" className={`mt-3 text-[0.9rem] ${msg?.t === 'err' ? 'text-[#8a1c1c]' : 'text-maroon'}`}>
        {msg?.s} {msg?.t === 'ok' && <Link href="/cart" className="underline">View bag</Link>}
      </p>
    </div>
  );
}
