import 'server-only';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { cookies, headers } from 'next/headers';
import { readDb, mutate, newId, nowIso, type User, type Role } from './db';

const COOKIE = 'rl_session';
const SESSION_DAYS = 14;

function secret(): string {
  const env = process.env.SESSION_SECRET;
  if (env && env.length >= 32) return env;
  if (process.env.NODE_ENV === 'production') {
    throw new Error('SESSION_SECRET (>= 32 chars) is required in production.');
  }
  // Development only: persist a random secret so sessions survive restarts.
  const dir = path.join(process.cwd(), '.data');
  const file = path.join(dir, 'dev-session-secret');
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  return fs.readFileSync(file, 'utf8');
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, saltHex, hashHex] = stored.split('$');
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(expected, actual);
}

function sign(payload: string): string {
  return crypto.createHmac('sha256', secret()).update(payload).digest('base64url');
}

function makeToken(uid: string): string {
  const payload = Buffer.from(JSON.stringify({ uid, exp: Date.now() + SESSION_DAYS * 864e5 })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

function parseToken(token: string | undefined): string | null {
  if (!token) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const { uid, exp } = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { uid: string; exp: number };
    if (typeof uid !== 'string' || typeof exp !== 'number' || exp < Date.now()) return null;
    return uid;
  } catch {
    return null;
  }
}

export interface SessionUser {
  id: string; email: string; name: string; phone: string; role: Role;
}

function toSession(u: User): SessionUser {
  return { id: u.id, email: u.email, name: u.name, phone: u.phone, role: u.role };
}

/** Resolve the signed-in user from the session cookie (server-side only). */
export async function getUser(): Promise<SessionUser | null> {
  await ensureAdminSeed();
  const jar = await cookies();
  const uid = parseToken(jar.get(COOKIE)?.value);
  if (!uid) return null;
  const u = readDb().users.find((x) => x.id === uid);
  return u ? toSession(u) : null;
}

export async function requireUser(): Promise<SessionUser | null> {
  return getUser();
}

export async function requireAdmin(): Promise<SessionUser | null> {
  const u = await getUser();
  return u && u.role === 'admin' ? u : null;
}

export async function startSession(uid: string) {
  const jar = await cookies();
  jar.set(COOKIE, makeToken(uid), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: SESSION_DAYS * 86400,
  });
}

export async function endSession() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

let seeded = false;
/** Dev store only: create the admin account named in env on first use. */
async function ensureAdminSeed() {
  if (seeded) return;
  seeded = true;
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 10) return;
  if (readDb().users.some((u) => u.email === email)) return;
  await mutate((db) => {
    db.users.push({
      id: newId(), email, name: 'ROOPLOOP Admin', phone: '', passwordHash: hashPassword(password),
      role: 'admin', createdAt: nowIso(),
    });
  });
}

/** Same-origin check for state-changing requests (CSRF defence in depth). */
export async function sameOrigin(): Promise<boolean> {
  const h = await headers();
  const origin = h.get('origin');
  const host = h.get('x-forwarded-host') ?? h.get('host');
  if (!origin) return true; // non-browser / same-origin form posts without Origin
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

// ---- Naive in-memory login throttle (per process) -------------------------
const attempts = new Map<string, { n: number; first: number }>();
export function throttled(key: string, max = 8, windowMs = 10 * 60_000): boolean {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || now - rec.first > windowMs) {
    attempts.set(key, { n: 1, first: now });
    return false;
  }
  rec.n += 1;
  return rec.n > max;
}
