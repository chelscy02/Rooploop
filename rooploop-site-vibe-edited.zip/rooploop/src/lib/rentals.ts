import 'server-only';
import type { RentalBooking } from './db';
import type { RentalItem } from '@/data/rentals';

export const HOLD_HOURS = 72; // draft policy: a requested booking holds the dates this long unless confirmed

const BLOCKING = new Set(['Requested', 'Confirmed', 'Out for Rental', 'Returned']);

export function blocks(b: RentalBooking, now = Date.now()): boolean {
  if (!BLOCKING.has(b.status)) return false;
  if (b.status === 'Requested' && Date.parse(b.holdExpiresAt) < now) return false; // abandoned hold released
  return true;
}

export function overlaps(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  return aStart <= bEnd && aEnd >= bStart;
}

export function unitFree(bookings: readonly RentalBooking[], unitId: string, start: string, end: string, ignoreId?: string): boolean {
  return !bookings.some((b) => b.unitId === unitId && b.id !== ignoreId && blocks(b) && overlaps(start, end, b.start, b.end));
}

/** First physical unit of the requested size that is free for the whole period. */
export function findFreeUnit(bookings: readonly RentalBooking[], item: RentalItem, size: string, start: string, end: string): string | null {
  for (const u of item.units) if (u.size === size && unitFree(bookings, u.unitId, start, end)) return u.unitId;
  return null;
}
