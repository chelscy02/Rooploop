import 'server-only';
import crypto from 'node:crypto';

export type PaymentsMode = 'off' | 'test' | 'razorpay';

export function paymentsMode(): PaymentsMode {
  const m = process.env.PAYMENTS_MODE;
  if (m === 'razorpay' && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) return 'razorpay';
  // "test" places orders WITHOUT charging anyone. Never allowed in production.
  if (m === 'test' && process.env.NODE_ENV !== 'production') return 'test';
  return 'off';
}

export async function createRazorpayOrder(amountInr: number, receipt: string): Promise<{ id: string } | { error: string }> {
  const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');
  try {
    const r = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Basic ${auth}` },
      body: JSON.stringify({ amount: Math.round(amountInr * 100), currency: 'INR', receipt: receipt.slice(0, 40) }),
    });
    const d = (await r.json()) as { id?: string; error?: { description?: string } };
    if (!r.ok || !d.id) return { error: d.error?.description ?? 'Payment provider rejected the order.' };
    return { id: d.id };
  } catch {
    return { error: 'Could not reach the payment provider.' };
  }
}

/** Server-side signature check. The browser's "success" callback alone is never trusted. */
export function verifyRazorpaySignature(orderId: string, paymentId: string, signature: string): boolean {
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET ?? '').update(`${orderId}|${paymentId}`).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
