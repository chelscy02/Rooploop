export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
// Accepts Indian mobile numbers with optional +91 / 0 prefix, and general international numbers.
export function normalisePhone(v: string): string | null {
  const digits = v.replace(/[\s\-().]/g, '');
  if (/^(\+91|91|0)?[6-9]\d{9}$/.test(digits)) return '+91' + digits.slice(-10);
  if (/^\+\d{8,15}$/.test(digits)) return digits;
  return null;
}

export type FieldErrors = Record<string, string>;

export function str(v: unknown, max = 2000): string {
  return typeof v === 'string' ? v.trim().slice(0, max) : '';
}

export const MAX_FILE_BYTES = 8 * 1024 * 1024;
export const MAX_FILES = 6;
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'] as const;

/** Detect image type from magic bytes, not from the client-supplied MIME. */
export function sniffImage(buf: Buffer): (typeof ALLOWED_IMAGE_TYPES)[number] | null {
  if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length > 12 && buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
  return null;
}

export function isIsoDate(v: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(v + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}

export function daysBetweenInclusive(start: string, end: string): number {
  const a = Date.parse(start + 'T00:00:00Z');
  const b = Date.parse(end + 'T00:00:00Z');
  return Math.round((b - a) / 864e5) + 1;
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}
