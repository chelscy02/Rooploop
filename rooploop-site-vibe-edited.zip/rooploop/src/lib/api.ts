import 'server-only';
import { NextResponse } from 'next/server';
import { getUser, sameOrigin, requireAdmin, type SessionUser } from './auth';

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
}
export const fail = (error: string, status = 400, fields?: Record<string, string>) =>
  json({ ok: false, error, fields }, status);

/** Guard for state-changing customer routes. */
export async function guardUser(): Promise<{ user: SessionUser } | { res: ReturnType<typeof json> }> {
  if (!(await sameOrigin())) return { res: fail('Cross-origin request blocked.', 403) };
  const user = await getUser();
  if (!user) return { res: fail('Please sign in to continue.', 401) };
  return { user };
}
/** Guard for admin routes: real server-side role check on every request. */
export async function guardAdmin(): Promise<{ user: SessionUser } | { res: ReturnType<typeof json> }> {
  if (!(await sameOrigin())) return { res: fail('Cross-origin request blocked.', 403) };
  const user = await requireAdmin();
  if (!user) return { res: fail('Not authorised.', 403) };
  return { user };
}
export async function readJson(req: Request): Promise<Record<string, unknown> | null> {
  try {
    const b = await req.json();
    return b && typeof b === 'object' ? (b as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}
