import 'server-only';
import { readDb } from './db';
import type { Product } from '@/data/products';
import type { RentalItem } from '@/data/rentals';

export function listProducts(): Product[] {
  return readDb().products.filter((p) => p.status !== 'archived');
}
export function getProduct(slug: string): Product | undefined {
  return listProducts().find((p) => p.slug === slug);
}
export function totalStock(p: Product): number {
  return p.sizes.reduce((n, s) => n + (p.stock[s] ?? 0), 0);
}
export function isAvailable(p: Product): boolean {
  return p.status === 'available' && totalStock(p) > 0;
}
export function listRentals(): RentalItem[] {
  return readDb().rentals.filter((r) => r.status !== 'archived');
}
export function getRental(slug: string): RentalItem | undefined {
  return listRentals().find((r) => r.slug === slug);
}
