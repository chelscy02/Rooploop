import 'server-only';
import fs from 'node:fs';
import path from 'node:path';
import { siteImages, productImageFiles, type SiteImageKey } from '@/data/siteImages';

export interface ResolvedImage {
  /** Public URL, or null when the slot is empty / file missing. */
  src: string | null;
  alt: string;
  focal: string;
  aspect: string;
  /** Human label shown inside an empty slot. */
  slotLabel: string;
  kind: string;
}

/** Read width/height from a JPEG/PNG/WebP header without extra dependencies. */
function dims(folder: string, file: string): { w: number; h: number } | null {
  try {
    const b = fs.readFileSync(path.join(process.cwd(), 'public', 'assets', folder, file));
    if (b[0] === 0x89 && b.toString('ascii', 1, 4) === 'PNG') return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
    if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') {
      const t = b.toString('ascii', 12, 16);
      if (t === 'VP8X') return { w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3) };
      if (t === 'VP8 ') return { w: b.readUInt16LE(26) & 0x3fff, h: b.readUInt16LE(28) & 0x3fff };
      if (t === 'VP8L') { const v = b.readUInt32LE(21); return { w: (v & 0x3fff) + 1, h: ((v >> 14) & 0x3fff) + 1 }; }
    }
    if (b[0] === 0xff && b[1] === 0xd8) {
      let i = 2;
      while (i < b.length) {
        if (b[i] !== 0xff) { i++; continue; }
        const m = b[i + 1];
        if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { h: b.readUInt16BE(i + 5), w: b.readUInt16BE(i + 7) };
        i += 2 + b.readUInt16BE(i + 2);
      }
    }
  } catch { /* fall through */ }
  return null;
}

function exists(folder: string, file: string): boolean {
  try {
    return fs.existsSync(path.join(process.cwd(), 'public', 'assets', folder, file));
  } catch {
    return false;
  }
}

export function getImage(key: SiteImageKey): ResolvedImage {
  const slot = siteImages[key];
  const ok = slot.file !== null && exists(slot.folder, slot.file);
  return {
    src: ok ? `/assets/${slot.folder}/${encodeURIComponent(slot.file as string)}` : null,
    alt: slot.alt,
    focal: slot.focal,
    aspect: slot.aspect,
    slotLabel: `${key}  ·  ${slot.section}`,
    kind: slot.kind,
  };
}

export function getProductImages(slug: string, name: string, extra?: string[]): ResolvedImage[] {
  // Admin-uploaded files win; if they are missing on disk fall back to the manifest.
  const uploaded = (extra ?? []).filter((f) => exists('products', f));
  const files = uploaded.length ? uploaded : (productImageFiles[slug] ?? []).filter((f) => exists('products', f));
  if (files.length === 0) {
    return [
      {
        src: null,
        alt: name,
        focal: '50% 30%',
        aspect: '4/5',
        slotLabel: `product photo: ${slug}`,
        kind: 'product',
      },
    ];
  }
  return files.map((f, i) => {
    const d = dims('products', f);
    return {
    src: `/assets/products/${encodeURIComponent(f)}`,
    alt: `${name}, view ${i + 1}`,
    focal: '50% 30%',
    aspect: d ? `${d.w}/${d.h}` : '4/5',
    slotLabel: slug,
    kind: 'product',
    };
  });
}
