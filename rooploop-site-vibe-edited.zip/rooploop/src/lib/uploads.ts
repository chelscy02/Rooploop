import 'server-only';
import fs from 'node:fs';
import path from 'node:path';
import { UPLOAD_DIR, mutate, newId, nowIso } from './db';
import { MAX_FILE_BYTES, MAX_FILES, sniffImage } from './validation';

const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

export interface ValidatedUpload { buf: Buffer; mime: string; name: string; }

/** Validate uploaded garment photos. Returns error text or the validated buffers. */
export async function validateUploads(
  files: File[],
  { min = 1 }: { min?: number } = {},
): Promise<{ error: string } | { files: ValidatedUpload[] }> {
  const real = files.filter((f) => f && f.size > 0);
  if (real.length < min) return { error: `Please upload at least ${min} photo${min > 1 ? 's' : ''}.` };
  if (real.length > MAX_FILES) return { error: `Please upload at most ${MAX_FILES} photos.` };
  const out: ValidatedUpload[] = [];
  for (const f of real) {
    if (f.size > MAX_FILE_BYTES) return { error: `"${f.name}" is larger than ${MAX_FILE_BYTES / 1024 / 1024} MB.` };
    const buf = Buffer.from(await f.arrayBuffer());
    const mime = sniffImage(buf);
    if (!mime) return { error: `"${f.name}" is not a JPG, PNG or WebP image.` };
    out.push({ buf, mime, name: f.name.replace(/[^\w.\- ]+/g, '_').slice(0, 80) || 'photo' });
  }
  return { files: out };
}

/** Write validated uploads to disk and register them. Call only after validation. */
export async function saveUploads(ownerId: string, files: ValidatedUpload[]): Promise<string[]> {
  const ids: string[] = [];
  const written: string[] = [];
  try {
    await mutate((db) => {
      for (const f of files) {
        const id = newId();
        const rel = `${id}.${EXT[f.mime]}`;
        fs.writeFileSync(path.join(UPLOAD_DIR, rel), f.buf, { mode: 0o600 });
        written.push(rel);
        db.files.push({ id, ownerId, name: f.name, mime: f.mime, size: f.buf.length, path: rel, createdAt: nowIso() });
        ids.push(id);
      }
    });
  } catch (e) {
    for (const rel of written) fs.rmSync(path.join(UPLOAD_DIR, rel), { force: true });
    throw e;
  }
  return ids;
}
