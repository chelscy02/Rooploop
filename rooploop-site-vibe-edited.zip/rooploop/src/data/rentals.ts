/**
 * Rental inventory. Owned by ROOPLOOP only; customers cannot list garments.
 * Everything with `draft: true` is SAMPLE data (names, fees, deposits), not
 * confirmed. Each entry has physical `units`; availability is checked per unit,
 * server-side, so two bookings can never overlap on the same physical garment.
 */
export interface RentalItem {
  id: string;
  slug: string;
  name: string;
  description: string;
  occasion: string;
  sizes: string[];
  /** Rental fee for the whole rental period, in INR (draft). */
  fee: number;
  /** Refundable security deposit in INR (draft). */
  deposit: number;
  /** Physical garments: one per size/unit. id is the unit identifier. */
  units: { unitId: string; size: string }[];
  status: 'active' | 'archived';
  /** Rental period limits in days (draft policy). */
  minDays: number;
  maxDays: number;
  draft: boolean;
}

export const sampleRentals: RentalItem[] = [
  {
    id: 'r-001', slug: 'gold-embroidered-mini-skirt', name: 'Gold Embroidered Mirror-Work Mini Skirt',
    description: 'Mini skirt in gold fabric with mirror work, floral embroidery and a lattice embroidered border. Draft copy: replace with the final description.',
    occasion: 'Festive / evening', sizes: ['S', 'M'], fee: 3500, deposit: 3000,
    units: [{ unitId: 'r-001-S', size: 'S' }, { unitId: 'r-001-M', size: 'M' }],
    status: 'active', minDays: 2, maxDays: 7, draft: true,
  },
  {
    id: 'r-002', slug: 'denim-patchwork-saree-set', name: 'Denim Patchwork Saree Set',
    description: 'Saree-style drape in panelled light and dark denim, with a denim blouse and skirt. Draft copy: replace with the final description.',
    occasion: 'Wedding / cocktail', sizes: ['S', 'M'], fee: 6000, deposit: 6000,
    units: [{ unitId: 'r-002-S', size: 'S' }, { unitId: 'r-002-M', size: 'M' }],
    status: 'active', minDays: 2, maxDays: 7, draft: true,
  },
];
