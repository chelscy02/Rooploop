/**
 * Product catalogue.
 *
 * IMPORTANT: everything in this file marked `draft: true` is SAMPLE DATA used to
 * exercise the shop. Names, prices and stock are placeholders, not confirmed
 * ROOPLOOP inventory. Replace with the real catalogue (or move to the database
 * via the admin dashboard) before launch.
 */
export type ProductCategory =
  | 'Reworked Denim'
  | 'Patchwork Tops'
  | 'Corsets and Statement Pieces'
  | 'Reconstructed Shirts'
  | 'Trousers and Bottoms'
  | 'Accessories'
  | 'Limited Editions';

export const productCategories: ProductCategory[] = [
  'Reworked Denim',
  'Patchwork Tops',
  'Corsets and Statement Pieces',
  'Reconstructed Shirts',
  'Trousers and Bottoms',
  'Accessories',
  'Limited Editions',
];

export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: ProductCategory;
  colour: string;
  /** Price in INR (whole rupees). null = not yet confirmed. */
  price: number | null;
  currency: 'INR';
  sizes: string[];
  /** Stock per size. */
  stock: Record<string, number>;
  status: 'available' | 'sold_out' | 'archived';
  productType: 'ready-to-buy';
  materials: string;
  craftNotes: string;
  care: string;
  featured: boolean;
  /** Filenames in public/assets/products/, managed from the admin dashboard. Falls back to src/data/siteImages.ts. */
  images?: string[];
  /** true = sample placeholder, shown with a DRAFT badge. */
  draft: boolean;
}

const care =
  'Draft care note: spot clean or gentle hand wash in cold water, dry in shade. Final care instructions to be confirmed per piece.';

export const sampleProducts: Product[] = [
  {
    id: 'p-001', slug: 'patchwork-kantha-corset', name: 'Patchwork Kantha Corset',
    description: 'Strapless corset built from vertical panels of mixed printed fabrics, joined with visible kantha-style running stitch. Draft copy: replace with the final product description.',
    category: 'Corsets and Statement Pieces', colour: 'Multi', price: 6200, currency: 'INR',
    sizes: ['XS', 'S', 'M'], stock: { XS: 1, S: 1, M: 0 }, status: 'available', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Panelled patchwork with hand-stitched kantha detail (to be confirmed).', care, featured: true, draft: true,
  },
  {
    id: 'p-002', slug: 'denim-patchwork-vest', name: 'Denim Vest with Embroidered Patchwork Back',
    description: 'Cropped denim vest with an embroidered patchwork panel, mirror work and a shell-disc fringe across the shoulders and hem. Draft copy: replace with the final product description.',
    category: 'Reworked Denim', colour: 'Indigo', price: 4500, currency: 'INR',
    sizes: ['S', 'M'], stock: { S: 1, M: 1 }, status: 'available', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Embroidered textile patches, mirror work and shell fringe (to be confirmed).', care, featured: true, draft: true,
  },
  {
    id: 'p-003', slug: 'blockprint-patchwork-shirt', name: 'Block-Print Patchwork Shirt',
    description: 'Boxy shirt assembled from mixed block-print and ikat fabrics with an appliqued Devanagari word across the back. Draft copy: replace with the final product description.',
    category: 'Reconstructed Shirts', colour: 'Multi', price: 3400, currency: 'INR',
    sizes: ['M', 'L', 'XL'], stock: { M: 1, L: 2, XL: 0 }, status: 'available', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Patchwork of printed cottons with applique lettering (to be confirmed).', care, featured: true, draft: true,
  },
  {
    id: 'p-004', slug: 'brown-mirrorwork-trousers', name: 'Brown Mirror-Work Lace-Up Trousers',
    description: 'Low-rise flared trousers with all-over mirror work and embroidery, and lace-up detailing down the side seam. Draft copy: replace with the final product description.',
    category: 'Trousers and Bottoms', colour: 'Brown', price: 5200, currency: 'INR',
    sizes: ['S', 'M'], stock: { S: 1, M: 1 }, status: 'available', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Mirror work and embroidery with side lacing (to be confirmed).', care, featured: true, draft: true,
  },
  {
    id: 'p-005', slug: 'olive-corduroy-trousers', name: 'Olive Corduroy Trousers with Woven Inserts',
    description: 'Wide-leg olive corduroy trousers with woven pattern inserts running down the legs. Draft copy: replace with the final product description.',
    category: 'Trousers and Bottoms', colour: 'Olive', price: 3900, currency: 'INR',
    sizes: ['M', 'L'], stock: { M: 0, L: 0 }, status: 'sold_out', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Woven inserts set into the leg seams (to be confirmed).', care, featured: false, draft: true,
  },
  {
    id: 'p-006', slug: 'patchwork-embroidered-boots', name: 'Patchwork Embroidered Boots',
    description: 'Pointed knee-high boots covered in patchwork embroidery, sequins and beadwork. Draft copy: replace with the final product description.',
    category: 'Accessories', colour: 'Multi', price: 7800, currency: 'INR',
    sizes: ['37', '38', '39'], stock: { '37': 1, '38': 1, '39': 1 }, status: 'available', productType: 'ready-to-buy',
    materials: 'To be confirmed', craftNotes: 'Embroidered and sequinned textile patchwork (to be confirmed).', care, featured: false, draft: true,
  },
];
