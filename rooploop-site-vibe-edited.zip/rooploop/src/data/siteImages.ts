/**
 * ROOPLOOP central image manifest.
 *
 * Every image on the site is referenced by KEY from here. To place or replace a
 * photograph, drop the file into public/assets/<folder>/ and set `file` below.
 * No component needs editing.
 *
 * While `file` is null (or the file is missing on disk) the site renders a
 * clearly labelled empty slot. It never substitutes stock or generated imagery.
 *
 * kind:
 *   brand       official logo / wordmark files
 *   product     official ROOPLOOP product photography
 *   campaign    editorial / lifestyle photography supplied by the brand
 *   inspiration reference only. Never presented as a ROOPLOOP product.
 */
export type ImageKind = 'brand' | 'product' | 'campaign' | 'inspiration';

export interface ImageSlot {
  /** Filename inside public/assets/<folder>/ , or null until supplied. */
  file: string | null;
  folder: 'brand' | 'products' | 'sections' | 'inspiration';
  kind: ImageKind;
  /** Where on the site the slot is used. */
  section: string;
  /** Desktop / mobile usage note. */
  usage: string;
  /** CSS object-position focal point, e.g. "50% 20%". */
  focal: string;
  /** Intended aspect ratio of the slot (width / height). Photos are never stretched. */
  aspect: string;
  alt: string;
}

export const siteImages = {
  // ---- Brand ------------------------------------------------------------
  'logo-primary': {
    file: 'logo-wordmark-crop.png', folder: 'brand', kind: 'brand',
    section: 'Header, footer, mobile drawer',
    usage: 'Desktop and mobile. Original proportions preserved.',
    focal: '50% 50%', aspect: '1300/590',
    alt: 'ROOPLOOP, a circular fashion house',
  },
  'logo-light': {
    file: null, folder: 'brand', kind: 'brand',
    section: 'Footer and any dark maroon backgrounds',
    usage: 'Light-on-dark variant of the official logo, if supplied.',
    focal: '50% 50%', aspect: '4/1',
    alt: 'ROOPLOOP, a circular fashion house',
  },

  // ---- Homepage ---------------------------------------------------------
  'hero-main': {
    file: 'buttonwork-white-top-front.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Hero',
    usage: 'Desktop: right half. Mobile: full width above headline.',
    focal: '50% 35%', aspect: '4/3',
    alt: 'Inspiration: white ribbed top embellished with colourful vintage buttons',
  },
  'vertical-rework': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Home / Four verticals / Rework My Wardrobe',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 45%', aspect: '4/5',
    alt: 'Denim vest with an embroidered, mirror-work and shell-fringe patchwork back panel',
  },
  'vertical-shop': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Home / Four verticals / Shop the Loop',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 40%', aspect: '4/5',
    alt: 'Brown flared trousers with mirror work and side lace-up detail',
  },
  'vertical-rent': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Home / Four verticals / Rent the Look',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 55%', aspect: '4/5',
    alt: 'Denim patchwork saree drape with a denim blouse and skirt',
  },
  'vertical-giveback': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Home / Four verticals / Give It Another Life',
    usage: 'Card image, desktop and mobile.',
    focal: '50% 40%', aspect: '4/5',
    alt: 'Olive corduroy wide-leg trousers with woven pattern inserts',
  },

  // ---- Transformations (genuine before/after pairs only) ---------------
  'transformation-1-before': {
    file: null, folder: 'sections', kind: 'product',
    section: 'Home / Transformations / Pair 1 (before)',
    usage: 'Only fill with a genuine "before" photo.',
    focal: '50% 50%', aspect: '4/5', alt: 'Original garment before rework',
  },
  'transformation-1-after': {
    file: null, folder: 'sections', kind: 'product',
    section: 'Home / Transformations / Pair 1 (after)',
    usage: 'Only fill with the matching finished piece.',
    focal: '50% 50%', aspect: '4/5', alt: 'The same garment after rework',
  },
  'inspiration-1': {
    file: 'buttonwork-white-top-front.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Inspiration: white ribbed top embellished with colourful vintage buttons',
  },
  'inspiration-2': {
    file: 'buttonwork-process.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Inspiration: arranging colourful buttons on a white ribbed top',
  },
  'inspiration-3': {
    file: 'buttonwork-white-top-side.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Inspiration: white ribbed top with colourful button embellishments',
  },
  'inspiration-4': {
    file: 'buttonwork-styling-look.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Button-embellished white top styled with a plaid asymmetric skirt',
  },
  'inspiration-5': {
    file: 'gold-skirt-detail.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Close-up of a gold embroidered skirt with metallic floral details',
  },
  'inspiration-6': {
    file: 'gold-skirt-look.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Gold embroidered mini skirt styled with a white top',
  },
  'inspiration-7': {
    file: 'white-offshoulder-gold-skirt.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'White off-shoulder top with draped sleeves and a gold embroidered skirt',
  },
  'inspiration-8': {
    file: 'gold-skirt-editorial.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Transformations / Inspiration gallery',
    usage: 'Reference imagery. Labelled as inspiration, not as a product.',
    focal: '50% 50%', aspect: '4/3', alt: 'Editorial look featuring a gold embroidered skirt and flowing white sleeves',
  },

  // ---- Craft stories ----------------------------------------------------
  'craft-embroidery': {
    file: 'white-offshoulder-gold-skirt.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Craft stories / Embroidery',
    usage: 'Close-up textile detail. Do not crop away stitching.',
    focal: '50% 40%', aspect: '4/5', alt: 'Knee-high boots covered in patchwork embroidery, sequins and beadwork',
  },
  'craft-patchwork': {
    file: 'buttonwork-white-top-side.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Craft stories / Patchwork',
    usage: 'Close-up textile detail.',
    focal: '25% 50%', aspect: '1/1', alt: 'Inspiration: colourful vintage buttons arranged on a white ribbed top',
  },
  'craft-stitching': {
    file: 'buttonwork-process.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Home / Craft stories / Stitching',
    usage: 'Close-up textile detail.',
    focal: '50% 55%', aspect: '1/1', alt: 'Inspiration: buttonwork and styling details on a white top',
  },

  // ---- Our Story / service pages ---------------------------------------
  'story-main': {
    file: 'gold-skirt-editorial.jpeg', folder: 'inspiration', kind: 'inspiration',
    section: 'Our Story / Header image',
    usage: 'Desktop wide, mobile cropped to focal point.',
    focal: '50% 55%', aspect: '16/9', alt: 'Design inspiration: gold embroidered skirt styled with a white top',
  },
  'rework-header': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Rework page / Header image',
    usage: 'Side image next to intro copy.',
    focal: '50% 45%', aspect: '4/5', alt: 'Denim vest reworked with embroidered patchwork',
  },
  'giveback-header': {
    file: null, folder: 'sections', kind: 'inspiration',
    section: 'Give Back page / Header image',
    usage: 'Side image next to intro copy.',
    focal: '50% 40%', aspect: '4/5', alt: 'Olive corduroy trousers with woven inserts',
  },
} satisfies Record<string, ImageSlot>;

export type SiteImageKey = keyof typeof siteImages;

/**
 * Product / rental photographs. Keyed by product slug. Add filenames in
 * public/assets/products/. First entry is the main image.
 * Leave empty until real photographs are supplied.
 */
export const productImageFiles: Record<string, string[]> = {
  // Intentionally empty: the supplied photographs are inspiration/editorial references,
  // not confirmed product or rental listing photography. Add real inventory photos later.
};
