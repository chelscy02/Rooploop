import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        maroon: { DEFAULT: '#581E2A', dark: '#411620' },
        gold: '#B08A4A',
        ivory: '#F6F0E6',
        sand: '#E5D7C6',
        lavender: '#C9B6C9',
        terracotta: '#B96F57',
        charcoal: '#282421',
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'Times New Roman', 'serif'],
        sans: ['Manrope', 'Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      letterSpacing: { label: '0.18em' },
    },
  },
  plugins: [],
};
export default config;
