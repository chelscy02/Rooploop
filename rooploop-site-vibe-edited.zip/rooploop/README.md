# ROOPLOOP: A Circular Fashion House

Next.js 15 (App Router) · React 19 · TypeScript · Tailwind. Rework, Shop, Rent, Give Back, accounts and an admin dashboard.

## Run locally
```bash
npm install
cp .env.example .env.local        # then fill in values
# .env.local (development):
#   ADMIN_EMAIL=you@example.com
#   ADMIN_PASSWORD=<10+ characters>
#   PAYMENTS_MODE=test            # optional: test orders, NO payment taken
npm run dev                       # http://localhost:3000
```
Checks: `npm run typecheck`, `npm run lint`, `npm run build`.

The admin account named in `ADMIN_EMAIL` / `ADMIN_PASSWORD` is created on first request. Sign in at `/account/login`, then open `/admin`.

## Images (the important part)
All images are referenced by key from **`src/data/siteImages.ts`** (the manifest: file, section, desktop/mobile usage, focal point, kind).
To replace a photo: put the file in `public/assets/<folder>/` and change `file:` for that key. Product and rental photos map by slug in `productImageFiles` (same file) or can be uploaded per product in the admin.
Originals (with screenshot buttons) are kept in `public/assets/originals/`; the site uses trimmed copies in `public/assets/products/`. Photos are never recoloured or filtered; they are shown whole (`object-fit: contain`) unless a slot matches the photo's own shape.
Empty slots render as a labelled dashed box, never as stock imagery.

## What is real vs. not yet
| Area | Status |
|---|---|
| Pages, navigation, responsive layout, forms, validation | Built and tested |
| Auth (scrypt passwords, signed httpOnly cookie sessions), roles | Built and tested (dev store) |
| Rework: upload, request ID, admin quote, customer accept/decline, no production before acceptance | Built and tested |
| Give Back: upload, assessment outcomes, admin statuses | Built and tested |
| Rent: server-side availability + atomic booking, no overlaps | Built and tested (incl. 6 parallel requests) |
| Shop: filters, sort, cart, stock checks, checkout in TEST mode | Built and tested |
| Admin: orders, products (create/edit/archive/upload), reworks, rentals, give back, enquiries | Built and tested |
| **Persistence** | Local JSON file `.data/db.json`. **Not production-grade.** Supabase schema + RLS is in `supabase/migrations/0001_init.sql`; `src/lib/db.ts` still has to be replaced by a Supabase implementation |
| **Payments** | Razorpay order creation + server-side signature verification are coded but **untested against Razorpay** (no credentials). Default is OFF; checkout is blocked. `PAYMENTS_MODE=test` is refused in production |
| **Email / notifications** | Not connected. Messages are queued in the store's outbox, never sent. Customers see quotes in their dashboard |
| Rental deposits, refunds, late fees | Not implemented (disabled until policy and payments exist) |
| Account settings editing, password reset | Not built |
| Social links, policy text (shipping, returns, rental, privacy, terms) | Placeholders marked DRAFT |
| Newsletter | Stored in the store; no mailing-list provider |
| Wishlist | Per device (localStorage), not synced to account |

Sample products, prices, stock, rental fees and deposits are **draft placeholders** (badged "Draft listing"). Replace via `/admin` or the data files before launch.

## Production / deployment checklist
1. Set `SESSION_SECRET` (32+ random chars). The app refuses to start sessions without it in production.
2. Create a Supabase project, run `supabase/migrations/0001_init.sql`, create the storage buckets described at its end, and replace `src/lib/db.ts` (same exported functions) with a Supabase-backed version. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only. Schedule the hold-expiry job noted in the SQL.
3. Move uploads (`.data/uploads`, `public/assets/products` admin uploads) to Supabase Storage. Serverless hosts (e.g. Vercel) have no persistent disk, so the dev store will lose data there.
4. Razorpay: set `PAYMENTS_MODE=razorpay`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`; test in Razorpay test mode; add a webhook for reliability (not yet built).
5. Add a real email provider, then send the outbox messages.
6. Add rate limiting at the edge (current login throttle is per-process memory).
7. Replace draft policies with reviewed legal text; supply real catalogue and photos.
8. Deploy (e.g. `vercel` or any Node host with `npm run build && npm start`). Nothing has been deployed from this session.

## Testing checklist (manual)
Navigation links · shop filters/sort/search · product page sizes + add to bag · cart quantities · checkout (test mode) · rework with 0/1/6+ photos, bad file types, >8 MB · give back (collection needs address) · rental overlapping dates and different sizes · customer cannot see another customer's data or files · `/admin` and `/api/admin` as anonymous and as a customer · quote accept/decline · mobile 390px layout.
