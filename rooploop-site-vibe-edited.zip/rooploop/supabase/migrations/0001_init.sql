-- ROOPLOOP schema for Supabase (Postgres). NOT yet wired to the app: the app currently
-- runs on a local dev store (src/lib/db.ts). Apply this when you replace that module.
create extension if not exists "pgcrypto";
create extension if not exists btree_gist;

-- ---------- profiles / roles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone) values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'phone',''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Prevent customers promoting themselves: role can only change via service role / admin.
create or replace function public.guard_profile_role() returns trigger language plpgsql as $$
begin
  if new.role is distinct from old.role and not public.is_admin() and auth.role() <> 'service_role' then
    raise exception 'role cannot be changed';
  end if;
  return new;
end $$;
create trigger guard_role before update on public.profiles for each row execute function public.guard_profile_role();

-- ---------- catalogue ----------
create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  description text not null default '',
  category text not null,
  colour text not null default '',
  price_inr integer check (price_inr is null or price_inr >= 0),   -- null = not confirmed
  currency text not null default 'INR' check (currency = 'INR'),
  sizes jsonb not null default '{}'::jsonb,                         -- {"S": 2, "M": 0}
  status text not null default 'available' check (status in ('available','sold_out','archived')),
  product_type text not null default 'ready-to-buy',
  materials text not null default '', craft_notes text not null default '', care text not null default '',
  featured boolean not null default false,
  is_draft boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on public.products (status, category);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  storage_path text not null, position integer not null default 0, created_at timestamptz not null default now()
);
create index on public.product_images (product_id, position);

create table public.rental_items (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique, name text not null, description text not null default '', occasion text not null default '',
  fee_inr integer not null check (fee_inr >= 0), deposit_inr integer not null default 0 check (deposit_inr >= 0),
  min_days integer not null default 2 check (min_days >= 1), max_days integer not null default 7 check (max_days >= min_days),
  status text not null default 'active' check (status in ('active','archived')),
  is_draft boolean not null default true, created_at timestamptz not null default now()
);
-- One row per physical garment. Bookings attach to a unit.
create table public.rental_units (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.rental_items(id) on delete cascade,
  size text not null, label text not null default ''
);
create index on public.rental_units (item_id, size);

-- ---------- orders ----------
create table public.orders (
  id uuid primary key default gen_random_uuid(), ref text not null unique,
  user_id uuid not null references public.profiles(id),
  name text not null, email text not null, phone text not null, address text not null,
  total_inr integer not null check (total_inr >= 0),
  status text not null default 'Pending Payment' check (status in ('Pending Payment','Paid','Processing','Shipped','Delivered','Cancelled','Payment Failed')),
  payment_mode text not null check (payment_mode in ('test','razorpay')),
  razorpay_order_id text unique, razorpay_payment_id text unique,
  idempotency_key text not null, stock_committed boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  size text not null, qty integer not null check (qty > 0), unit_price_inr integer not null check (unit_price_inr >= 0)
);
create index on public.orders (user_id, created_at desc);
create index on public.order_items (order_id);

-- ---------- rework (quote-based) ----------
create table public.rework_requests (
  id uuid primary key default gen_random_uuid(), ref text not null unique,
  user_id uuid not null references public.profiles(id),
  full_name text not null, email text not null, phone text not null,
  category text not null, condition text not null, transformation text not null,
  style_preferences text not null default '', colour_preferences text not null default '',
  budget text not null default '', instructions text not null default '', fulfilment text not null default '',
  photo_paths text[] not null default '{}',
  status text not null default 'Submitted' check (status in ('Submitted','Under Review','Quote Sent','Approved','In Production','Ready to Ship','Completed','Cancelled')),
  admin_notes text not null default '',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.rework_quotes (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.rework_requests(id) on delete cascade,
  design text not null, price_inr integer not null check (price_inr > 0), timeline text not null, notes text not null default '',
  customer_response text not null default 'pending' check (customer_response in ('pending','accepted','declined')),
  sent_at timestamptz not null default now(), responded_at timestamptz
);
create index on public.rework_requests (user_id, created_at desc);
create index on public.rework_quotes (request_id);

-- ---------- rental bookings: overlap prevention enforced BY THE DATABASE ----------
create table public.rental_bookings (
  id uuid primary key default gen_random_uuid(), ref text not null unique,
  user_id uuid not null references public.profiles(id),
  item_id uuid not null references public.rental_items(id),
  unit_id uuid not null references public.rental_units(id),
  size text not null, start_date date not null, end_date date not null check (end_date >= start_date),
  fee_inr integer not null, deposit_inr integer not null,
  status text not null default 'Requested' check (status in ('Requested','Confirmed','Out for Rental','Returned','Completed','Cancelled','Expired')),
  deposit_status text not null default 'Not collected (payments disabled)',
  hold_expires_at timestamptz not null, admin_notes text not null default '',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  -- No two blocking bookings may overlap on the same physical unit.
  constraint no_overlap exclude using gist (unit_id with =, daterange(start_date, end_date, '[]') with &&)
    where (status in ('Requested','Confirmed','Out for Rental','Returned'))
);
create index on public.rental_bookings (user_id, created_at desc);
-- NOTE: abandoned 'Requested' holds must be flipped to 'Expired' by a scheduled job
-- (pg_cron: update ... set status='Expired' where status='Requested' and hold_expires_at < now()) so the constraint releases them.

-- ---------- give back ----------
create table public.giveback_submissions (
  id uuid primary key default gen_random_uuid(), ref text not null unique,
  user_id uuid not null references public.profiles(id),
  full_name text not null, email text not null, phone text not null, category text not null, condition text not null,
  item_count integer not null check (item_count between 1 and 50),
  logistics text not null, address text not null default '', preference text not null default '', notes text not null default '',
  photo_paths text[] not null default '{}',
  status text not null default 'Submitted' check (status in ('Submitted','Under Assessment','Accepted','Collection Scheduled','Received','Routed for Reuse/Donation/Recycling','Completed','Not Accepted')),
  outcome text not null default 'Not yet assessed' check (outcome in ('Not yet assessed','Suitable for donation','Suitable for redesign or reuse','Suitable for resale','Suitable for textile recycling','Not accepted')),
  admin_notes text not null default '',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on public.giveback_submissions (user_id, created_at desc);

create table public.wishlist_items (
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(), primary key (user_id, product_id)
);
create table public.newsletter_subscribers (id uuid primary key default gen_random_uuid(), email text not null unique, created_at timestamptz not null default now());
create table public.enquiries (id uuid primary key default gen_random_uuid(), name text not null, email text not null, message text not null, handled boolean not null default false, created_at timestamptz not null default now());

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.rental_items enable row level security;
alter table public.rental_units enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.rework_requests enable row level security;
alter table public.rework_quotes enable row level security;
alter table public.rental_bookings enable row level security;
alter table public.giveback_submissions enable row level security;
alter table public.wishlist_items enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.enquiries enable row level security;

-- profiles: own row read/update; admins read all
create policy profiles_self_read on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy profiles_self_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- public catalogue: anyone reads non-archived; only admins write
create policy products_read on public.products for select using (status <> 'archived' or public.is_admin());
create policy products_admin on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy pimg_read on public.product_images for select using (true);
create policy pimg_admin on public.product_images for all using (public.is_admin()) with check (public.is_admin());
create policy ritems_read on public.rental_items for select using (status = 'active' or public.is_admin());
create policy ritems_admin on public.rental_items for all using (public.is_admin()) with check (public.is_admin());
create policy runits_read on public.rental_units for select using (true);
create policy runits_admin on public.rental_units for all using (public.is_admin()) with check (public.is_admin());

-- customer-owned data: customers see only their rows; admins see all.
-- Customer INSERT/UPDATE of orders, bookings and quote responses should go through server routes using
-- the service role (which re-validates price, stock and dates). These policies only allow safe reads.
create policy orders_read on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy orders_admin on public.orders for update using (public.is_admin());
create policy oitems_read on public.order_items for select using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));

create policy rework_read on public.rework_requests for select using (user_id = auth.uid() or public.is_admin());
create policy rework_insert on public.rework_requests for insert with check (user_id = auth.uid() and status = 'Submitted');
create policy rework_admin on public.rework_requests for update using (public.is_admin());
create policy quotes_read on public.rework_quotes for select using (exists (select 1 from public.rework_requests r where r.id = request_id and (r.user_id = auth.uid() or public.is_admin())));
create policy quotes_admin on public.rework_quotes for all using (public.is_admin()) with check (public.is_admin());

create policy bookings_read on public.rental_bookings for select using (user_id = auth.uid() or public.is_admin());
create policy bookings_admin on public.rental_bookings for update using (public.is_admin());

create policy giveback_read on public.giveback_submissions for select using (user_id = auth.uid() or public.is_admin());
create policy giveback_insert on public.giveback_submissions for insert with check (user_id = auth.uid() and status = 'Submitted' and outcome = 'Not yet assessed');
create policy giveback_admin on public.giveback_submissions for update using (public.is_admin());

create policy wishlist_own on public.wishlist_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy newsletter_insert on public.newsletter_subscribers for insert with check (true);
create policy newsletter_admin on public.newsletter_subscribers for select using (public.is_admin());
create policy enquiries_insert on public.enquiries for insert with check (true);
create policy enquiries_admin on public.enquiries for all using (public.is_admin()) with check (public.is_admin());

-- ---------- Storage (create in dashboard or via API) ----------
-- Bucket "customer-photos": PRIVATE. Path convention: {user_id}/{request_ref}/{file}.
--   policy: select/insert where (storage.foldername(name))[1] = auth.uid()::text, or public.is_admin().
-- Bucket "product-images": PUBLIC read; insert/update/delete only public.is_admin().
-- Make your first admin AFTER signup:  update public.profiles set role='admin' where id = '<auth user id>';
