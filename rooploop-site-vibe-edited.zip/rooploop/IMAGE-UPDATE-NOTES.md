# ROOPLOOP image update

- The eight photographs supplied for this revision are stored in `public/assets/inspiration/`.
- They are used only for editorial inspiration, the homepage hero, and craft/story moodboard areas. They are explicitly labelled as inspiration and not as products.
- Product and rental cards/details are text-only until confirmed inventory photography is supplied. No inspiration image is used as a product or rental photo.
- Rework and Give Back submission pages no longer display product imagery.
- To add genuine listing photos later, update the product/rental components and catalogue intentionally after the real inventory is confirmed.
